package com.glide.share;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.WindowManager;
import android.webkit.MimeTypeMap;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.OutputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Saves received files straight into Downloads/Glide (visible in the Files app and Gallery)
 * using MediaStore, and can keep the screen on while a transfer session is active.
 */
@CapacitorPlugin(name = "GlideSaver")
public class GlideSaverPlugin extends Plugin {

    private static class Entry {
        Uri uri;
        OutputStream out;
        String name;
    }

    private final Map<String, Entry> entries = new HashMap<>();

    private static String mimeOf(String name) {
        int dot = name.lastIndexOf('.');
        if (dot >= 0 && dot < name.length() - 1) {
            String ext = name.substring(dot + 1).toLowerCase(Locale.ROOT);
            String mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
            if (mime != null) return mime;
        }
        return "application/octet-stream";
    }

    @PluginMethod
    public void begin(PluginCall call) {
        String name = call.getString("name", "file");
        try {
            ContentResolver cr = getContext().getContentResolver();
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, mimeOf(name));
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Glide");
            v.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (uri == null) {
                call.reject("Could not create the file");
                return;
            }
            OutputStream out = cr.openOutputStream(uri, "w");
            if (out == null) {
                call.reject("Could not open the file");
                return;
            }

            // Android may rename to "name (1).ext" if it already exists. Read back the real name.
            String finalName = name;
            Cursor c = cr.query(uri, new String[]{MediaStore.MediaColumns.DISPLAY_NAME}, null, null, null);
            if (c != null) {
                try {
                    if (c.moveToFirst()) finalName = c.getString(0);
                } finally {
                    c.close();
                }
            }

            Entry e = new Entry();
            e.uri = uri;
            e.out = out;
            e.name = finalName;
            String id = UUID.randomUUID().toString();
            synchronized (entries) {
                entries.put(id, e);
            }
            JSObject res = new JSObject();
            res.put("id", id);
            res.put("name", finalName);
            call.resolve(res);
        } catch (Exception ex) {
            call.reject(String.valueOf(ex.getMessage()));
        }
    }

    @PluginMethod
    public void write(PluginCall call) {
        Entry e;
        synchronized (entries) {
            e = entries.get(call.getString("id", ""));
        }
        if (e == null) {
            call.reject("Unknown file");
            return;
        }
        try {
            byte[] bytes = Base64.decode(call.getString("data", ""), Base64.DEFAULT);
            e.out.write(bytes);
            call.resolve();
        } catch (Exception ex) {
            call.reject(String.valueOf(ex.getMessage()));
        }
    }

    @PluginMethod
    public void finish(PluginCall call) {
        Entry e;
        synchronized (entries) {
            e = entries.remove(call.getString("id", ""));
        }
        if (e == null) {
            call.reject("Unknown file");
            return;
        }
        try {
            e.out.flush();
            e.out.close();
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.IS_PENDING, 0);
            getContext().getContentResolver().update(e.uri, v, null, null);
            JSObject res = new JSObject();
            res.put("path", "Downloads/Glide/" + e.name);
            call.resolve(res);
        } catch (Exception ex) {
            call.reject(String.valueOf(ex.getMessage()));
        }
    }

    @PluginMethod
    public void keepAwake(PluginCall call) {
        final boolean on = Boolean.TRUE.equals(call.getBoolean("on", false));
        getActivity().runOnUiThread(() -> {
            if (on) {
                getActivity().getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            } else {
                getActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            }
        });
        call.resolve();
    }

    @Override
    protected void handleOnDestroy() {
        synchronized (entries) {
            for (Entry e : entries.values()) {
                try {
                    e.out.close();
                } catch (Exception ignored) {
                }
            }
            entries.clear();
        }
        super.handleOnDestroy();
    }
}
