// Builds the Android project from the shared renderer.
//   node scripts/android.js setup   -> creates/updates mobile/android (open it in Android Studio)
//   node scripts/android.js apk     -> setup + builds a debug APK
const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const root = path.join(__dirname, '..');
const www = path.join(root, 'www');
const androidDir = path.join(root, 'android');
const pkg = 'com.glide.share';
const javaDir = path.join(androidDir, 'app', 'src', 'main', 'java', ...pkg.split('.'));

function run(cmd, cwd = root) {
  console.log(`\n> ${cmd}`);
  const r = spawnSync(cmd, { cwd, stdio: 'inherit', shell: true });
  if (r.status !== 0) { console.error(`\nFailed: ${cmd}`); process.exit(r.status || 1); }
}

function buildWeb() {
  fs.rmSync(www, { recursive: true, force: true });
  fs.cpSync(path.join(root, '..', 'renderer'), www, { recursive: true });
  // The Capacitor page origin is http://localhost, so allow 'self' for its own bridge.
  const f = path.join(www, 'index.html');
  const html = fs.readFileSync(f, 'utf8').replace('connect-src ws: wss:', "connect-src 'self' ws: wss: blob:");
  fs.writeFileSync(f, html);
}

function patchAndroid() {
  // 1) native plugin that saves into Downloads/Glide and keeps the screen awake
  fs.mkdirSync(javaDir, { recursive: true });
  fs.copyFileSync(path.join(root, 'native', 'GlideSaverPlugin.java'), path.join(javaDir, 'GlideSaverPlugin.java'));
  fs.writeFileSync(path.join(javaDir, 'MainActivity.java'),
`package ${pkg};

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(GlideSaverPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
`);

  // 2) allow ws:// to a PC on the same Wi-Fi
  const mf = path.join(androidDir, 'app', 'src', 'main', 'AndroidManifest.xml');
  let m = fs.readFileSync(mf, 'utf8');
  if (!m.includes('usesCleartextTraffic')) m = m.replace('<application', '<application android:usesCleartextTraffic="true"');
  fs.writeFileSync(mf, m);

  // 3) saving to Downloads through MediaStore needs Android 10+
  const vf = path.join(androidDir, 'variables.gradle');
  if (fs.existsSync(vf)) {
    fs.writeFileSync(vf, fs.readFileSync(vf, 'utf8').replace(/minSdkVersion\s*=\s*\d+/, 'minSdkVersion = 29'));
  }
}

function setup() {
  buildWeb();
  if (!fs.existsSync(path.join(root, 'node_modules'))) run('npm install');
  if (!fs.existsSync(androidDir)) run('npx cap add android');
  patchAndroid();
  run('npx cap sync android');
}

const cmd = process.argv[2];
if (cmd === 'setup') {
  setup();
  console.log('\nDone. Open the "mobile/android" folder in Android Studio, or run: npm run apk');
} else if (cmd === 'apk') {
  setup();
  run(process.platform === 'win32' ? 'gradlew.bat assembleDebug' : './gradlew assembleDebug', androidDir);
  const apk = path.join(androidDir, 'app', 'build', 'outputs', 'apk', 'debug', 'app-debug.apk');
  console.log(`\nAPK ready: ${apk}`);
} else {
  console.log('Usage: node scripts/android.js setup|apk');
  process.exit(1);
}
