'use strict';
const $ = (s) => document.querySelector(s);
// Bigger chunks + a deep send buffer keep the data channel saturated (much faster on LAN).
// 256 KB is the largest message size every Chromium-based WebRTC stack accepts.
// Chromium closes a channel whose send queue passes ~16 MB, so stay well under that.
const CHUNK = 256 * 1024;
const MAX_BUFFER = 8 * 1024 * 1024;
const LOW_BUFFER = 2 * 1024 * 1024;
const ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
const COLORS = ['#8f7cf5', '#f2907a', '#4fbfd0', '#e77fb0', '#6fbf8f', '#e8b04f'];

const state = {
  staged: [],
  peers: [],
  transfers: new Map(),
  incoming: [],
  room: { code: '', ws: null, pc: null, dc: null, status: 'idle' },
};

/* ---------- helpers ---------- */
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
function fmt(b) {
  if (b < 1024) return `${b} B`;
  const u = ['KB', 'MB', 'GB', 'TB'];
  let i = -1;
  do { b /= 1024; i++; } while (b >= 1024 && i < u.length - 1);
  return `${b.toFixed(b >= 100 ? 0 : 1)} ${u[i]}`;
}
function colorFor(s) {
  let h = 0;
  for (const c of s) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  return COLORS[h % COLORS.length];
}
let toastTimer;
function toast(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (t.hidden = true), 3200);
}
function load(key, fallback) { try { return localStorage.getItem(key) || fallback; } catch { return fallback; } }
function store(key, val) { try { localStorage.setItem(key, val); } catch {} }

/* ---------- navigation ---------- */
document.querySelectorAll('nav button').forEach((b) => {
  b.onclick = () => showView(b.dataset.view);
});
function showView(v) {
  document.querySelectorAll('nav button').forEach((b) => b.classList.toggle('on', b.dataset.view === v));
  ['nearby', 'online', 'transfers'].forEach((n) => ($('#v-' + n).hidden = n !== v));
}

/* ---------- staged files ---------- */
async function addFiles(list) {
  for (const f of list) {
    if (f && !state.staged.some((s) => s.path === f.path)) state.staged.push(f);
  }
  renderStaged();
}
function renderStaged() {
  const n = state.staged.length;
  $('#drop-title').textContent = n ? `${n} file${n > 1 ? 's' : ''} ready` : 'Drop files to send';
  $('#drop-sub').textContent = n
    ? (state.room.status === 'live' && !$('#v-online').hidden ? 'Press Send files to share them.' : 'Pick who should get them.')
    : 'Anything, any size.';
  $('#chips').innerHTML = state.staged
    .map((f, i) => `<div class="chip"><span>${esc(f.name)}</span><small>${fmt(f.size)}</small><button data-i="${i}" aria-label="Remove ${esc(f.name)}">×</button></div>`)
    .join('');
  $('#chips').querySelectorAll('button').forEach((b) => {
    b.onclick = () => { state.staged.splice(Number(b.dataset.i), 1); renderStaged(); };
  });
}
$('#choose').onclick = async () => addFiles(await api.pickFiles());

const drop = $('#drop');
window.addEventListener('dragover', (e) => { e.preventDefault(); drop.classList.add('over'); });
window.addEventListener('dragleave', (e) => { if (!e.relatedTarget) drop.classList.remove('over'); });
window.addEventListener('drop', async (e) => {
  e.preventDefault();
  drop.classList.remove('over');
  const out = [];
  for (const f of e.dataTransfer.files) {
    const info = await api.statFile(api.pathOf(f));
    if (info) out.push(info);
  }
  if (out.length) addFiles(out);
  else toast('Folders are not supported yet. Drop files instead.');
});

/* ---------- nearby ---------- */
api.onPeers((list) => { state.peers = list; renderPeers(); });
function renderPeers() {
  const box = $('#peers');
  $('#radar').hidden = state.peers.length > 0;
  box.innerHTML = state.peers
    .map((p) => `<button class="peer" data-id="${esc(p.id)}">
        <div class="avatar" style="background:${colorFor(p.id)}">${esc((p.name[0] || '?').toUpperCase())}</div>
        <b>${esc(p.name)}</b><small>${esc(p.ip)}</small></button>`)
    .join('');
  box.querySelectorAll('.peer').forEach((b) => (b.onclick = () => sendNearby(b.dataset.id)));
}
async function sendNearby(peerId) {
  if (!state.staged.length) addFiles(await api.pickFiles());
  if (!state.staged.length) return;
  const files = state.staged.splice(0);
  renderStaged();
  toast(`Sending ${files.length} file${files.length > 1 ? 's' : ''}…`);
  for (const f of files) await api.lanSend(peerId, f.path);
}

/* ---------- incoming requests (both nearby and online) ---------- */
api.onIncoming((r) => askIncoming({ ...r, cb: (ok) => api.respond(r.id, ok) }));
api.onIncomingCancel((id) => { state.incoming = state.incoming.filter((r) => r.id !== id); renderModal(); });
function askIncoming(r) { state.incoming.push(r); renderModal(); }
function renderModal() {
  const r = state.incoming[0];
  $('#scrim').hidden = !r;
  if (!r) return;
  $('#m-title').textContent = `${r.from} wants to send you a file`;
  $('#m-sub').textContent = `${r.name} (${fmt(r.size)})`;
}
$('#m-yes').onclick = () => answer(true);
$('#m-no').onclick = () => answer(false);
function answer(ok) {
  const r = state.incoming.shift();
  if (r) r.cb(ok);
  renderModal();
}

/* ---------- transfers ---------- */
api.onTransfer((t) => setTransfer(t));
function setTransfer(t) {
  state.transfers.set(t.id, { ...(state.transfers.get(t.id) || {}), ...t });
  scheduleRender();
}
let raf = 0;
function scheduleRender() { if (!raf) raf = requestAnimationFrame(() => { raf = 0; renderTransfers(); }); }
const LABEL = {
  waiting: 'Waiting for a reply', sending: 'Sending', receiving: 'Receiving',
  done: 'Done', declined: 'Declined', failed: 'Failed',
};
function renderTransfers() {
  const all = [...state.transfers.values()].reverse();
  const active = all.filter((t) => ['waiting', 'sending', 'receiving'].includes(t.status)).length;
  const badge = $('#badge');
  badge.hidden = !active;
  badge.textContent = active;
  $('#tlist').innerHTML = all.length
    ? all.map((t) => {
        const pct = t.size ? Math.min(100, Math.round(((t.done || 0) / t.size) * 100)) : (t.status === 'done' ? 100 : 0);
        const who = t.dir === 'out' ? `to ${esc(t.peer)}` : `from ${esc(t.peer)}`;
        const extra = t.status === 'sending' || t.status === 'receiving' ? ` ${pct}%` : '';
        const open = t.status === 'done' && t.path ? `<button class="link" data-p="${esc(t.path)}">Show in folder</button>` : '';
        return `<div class="t ${t.status}">
          <div class="t-top"><b>${esc(t.name)}</b><span>${fmt(t.size)}</span></div>
          <div class="bar"><i style="width:${pct}%"></i></div>
          <div class="t-meta"><span>${LABEL[t.status] || t.status}${extra} · ${who}</span>${open}</div></div>`;
      }).join('')
    : '<div class="empty">Nothing sent or received yet.</div>';
  $('#tlist').querySelectorAll('[data-p]').forEach((b) => (b.onclick = () => api.showInFolder(b.dataset.p)));
}

/* ---------- online sharing (WebRTC) ---------- */
const room = state.room;
function makeCode() {
  const a = crypto.getRandomValues(new Uint8Array(6));
  const s = [...a].map((x) => ALPHABET[x % ALPHABET.length]).join('');
  return s.slice(0, 3) + '-' + s.slice(3);
}
const cleanCode = (c) => c.toUpperCase().replace(/[^A-Z0-9]/g, '');
function setRoomStatus(s) {
  room.status = s;
  if (api.setBusy) api.setBusy(s !== 'idle'); // Android: keep the screen on during a session
  $('#on-idle').hidden = s !== 'idle';
  $('#on-wait').hidden = !(s === 'waiting' || s === 'connecting');
  $('#on-live').hidden = s !== 'live';
  renderStaged();
}
function closeRoom(silent) {
  try { room.dc && room.dc.close(); } catch {}
  try { room.pc && room.pc.close(); } catch {}
  try { room.ws && room.ws.close(); } catch {}
  room.dc = room.pc = room.ws = null;
  for (const [, w] of waiters) w(false);
  waiters.clear();
  curIn = null;
  if (!silent) setRoomStatus('idle');
}
const IS_DESKTOP = api.platform === 'desktop';
$('#server').value = load('glide.server', IS_DESKTOP ? 'ws://localhost:8080' : '');
$('#server').onchange = () => store('glide.server', $('#server').value.trim());
$('#code-in').oninput = (e) => {
  const c = cleanCode(e.target.value).slice(0, 6);
  e.target.value = c.length > 3 ? c.slice(0, 3) + '-' + c.slice(3) : c;
};
$('#create').onclick = () => startRoom('create', makeCode());
$('#join').onclick = () => {
  const c = cleanCode($('#code-in').value);
  if (c.length !== 6) return toast('Enter the 6-character code.');
  startRoom('join', c.slice(0, 3) + '-' + c.slice(3));
};
$('#cancel').onclick = () => closeRoom();
$('#disconnect').onclick = () => closeRoom();
$('#copy').onclick = async () => { try { await navigator.clipboard.writeText(room.code); toast('Code copied'); } catch { toast('Could not copy. Select the code instead.'); } };
$('#send-online').onclick = async () => {
  if (!state.staged.length) addFiles(await api.pickFiles());
  if (!state.staged.length) return;
  const files = state.staged.splice(0);
  renderStaged();
  for (const f of files) await sendOnline(f);
};

function startRoom(mode, code) {
  closeRoom(true);
  const url = $('#server').value.trim();
  store('glide.server', url);
  if (!/^wss?:\/\//.test(url)) {
    $('#server-details').open = true;
    return toast('Enter the server address first (ws://… or wss://…).');
  }

  room.code = code;
  $('#code-show').textContent = code;
  $('#wait-title').textContent = mode === 'create' ? 'Waiting for the other person' : 'Connecting…';
  $('#wait-sub').textContent = mode === 'create'
    ? 'Share this code. It works once and expires in 15 minutes.'
    : 'Setting up a direct connection.';
  setRoomStatus(mode === 'create' ? 'waiting' : 'connecting');

  const ws = new WebSocket(url);
  const pc = new RTCPeerConnection({ iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] });
  room.ws = ws; room.pc = pc;
  const wsSend = (o) => { if (ws.readyState === 1) ws.send(JSON.stringify(o)); };

  pc.onicecandidate = (e) => { if (e.candidate) wsSend({ type: 'signal', data: { candidate: e.candidate } }); };
  pc.onconnectionstatechange = () => {
    if (['failed', 'closed'].includes(pc.connectionState) && room.pc === pc) { closeRoom(); toast('The connection dropped.'); }
  };
  pc.ondatachannel = (e) => setupChannel(e.channel);

  let chain = Promise.resolve();
  const earlyCandidates = [];
  ws.onopen = () => wsSend({ type: mode, code });
  ws.onerror = () => { if (room.ws === ws) { closeRoom(); toast('Cannot reach the sharing server. Check the server address.'); } };
  ws.onmessage = (ev) => { chain = chain.then(() => onSignal(JSON.parse(ev.data))).catch(() => {}); };

  async function onSignal(m) {
    if (room.ws !== ws) return;
    if (m.type === 'error') { closeRoom(); toast(m.message); }
    else if (m.type === 'joined') { $('#wait-sub').textContent = 'Setting up a direct connection.'; }
    else if (m.type === 'peer-joined') {
      $('#wait-title').textContent = 'Connecting…';
      setupChannel(pc.createDataChannel('files'));
      await pc.setLocalDescription(await pc.createOffer());
      wsSend({ type: 'signal', data: { sdp: pc.localDescription } });
    } else if (m.type === 'signal') {
      const d = m.data;
      if (d.sdp) {
        await pc.setRemoteDescription(d.sdp);
        for (const c of earlyCandidates.splice(0)) await pc.addIceCandidate(c).catch(() => {});
        if (d.sdp.type === 'offer') {
          await pc.setLocalDescription(await pc.createAnswer());
          wsSend({ type: 'signal', data: { sdp: pc.localDescription } });
        }
      } else if (d.candidate) {
        // candidates can overtake the offer/answer; hold them until the description is set
        if (pc.remoteDescription) await pc.addIceCandidate(d.candidate);
        else earlyCandidates.push(d.candidate);
      }
    } else if (m.type === 'peer-left' && room.status !== 'live') {
      closeRoom(); toast('The other person left.');
    }
  }
}

function setupChannel(dc) {
  dc.binaryType = 'arraybuffer';
  dc.bufferedAmountLowThreshold = LOW_BUFFER;
  dc.onopen = () => {
    room.dc = dc;
    setRoomStatus('live');
    try { room.ws && room.ws.close(); } catch {}
    toast('Connected');
  };
  dc.onclose = () => { if (room.dc === dc) { closeRoom(); toast('The other person disconnected.'); } };
  dc.onmessage = onRtcMessage;
}

/* receive */
let curIn = null;
async function onRtcMessage(ev) {
  const dc = room.dc;
  if (typeof ev.data === 'string') {
    const m = JSON.parse(ev.data);
    if (m.t === 'offer') {
      askIncoming({
        id: m.id, name: m.name, size: m.size, from: 'Your online contact',
        cb: async (ok) => {
          if (!ok) return dc.send(JSON.stringify({ t: 'decline', id: m.id }));
          const rid = await api.rtcOpen(m.name);
          curIn = { id: m.id, rid, size: m.size, done: 0, q: Promise.resolve() };
          setTransfer({ id: m.id, name: m.name, size: m.size, dir: 'in', peer: 'online contact', status: 'receiving', done: 0 });
          dc.send(JSON.stringify({ t: 'accept', id: m.id }));
        },
      });
    } else if (m.t === 'accept' || m.t === 'decline') {
      const w = waiters.get(m.id);
      if (w) { waiters.delete(m.id); w(m.t === 'accept'); }
    } else if (m.t === 'end' && curIn && curIn.id === m.id) {
      const cur = curIn; curIn = null;
      cur.q = cur.q.then(async () => {
        const p = await api.rtcClose(cur.rid);
        setTransfer({ id: cur.id, status: 'done', done: cur.size, path: p });
      });
    }
  } else if (curIn) {
    const cur = curIn;
    const chunk = new Uint8Array(ev.data);
    cur.done += chunk.byteLength;
    cur.q = cur.q.then(() => api.rtcWrite(cur.rid, chunk));
    setTransfer({ id: cur.id, done: cur.done });
  }
}

/* send */
const waiters = new Map();
async function sendOnline(file) {
  const dc = room.dc;
  if (!dc || dc.readyState !== 'open') return toast('Not connected.');
  const id = crypto.randomUUID();
  setTransfer({ id, name: file.name, size: file.size, dir: 'out', peer: 'online contact', status: 'waiting', done: 0 });
  dc.send(JSON.stringify({ t: 'offer', id, name: file.name, size: file.size }));
  const ok = await new Promise((r) => waiters.set(id, r));
  if (!ok) return setTransfer({ id, status: 'declined' });

  setTransfer({ id, status: 'sending' });
  const chunk = Math.max(16 * 1024, Math.min(CHUNK, (room.pc && room.pc.sctp && room.pc.sctp.maxMessageSize) || CHUNK));
  const readAt = (o) => (o < file.size ? api.readChunk(file.path, o, Math.min(chunk, file.size - o)) : null);
  let off = 0;
  try {
    let next = readAt(0); // read the next chunk while the current one is being sent
    while (next) {
      const buf = await next;
      if (!buf.byteLength) break;
      next = readAt(off + buf.byteLength);
      if (dc.readyState !== 'open') throw new Error('closed');
      if (dc.bufferedAmount > MAX_BUFFER) {
        await new Promise((r) => { dc.onbufferedamountlow = () => { dc.onbufferedamountlow = null; r(); }; });
      }
      dc.send(buf);
      off += buf.byteLength;
      setTransfer({ id, done: off });
    }
    dc.send(JSON.stringify({ t: 'end', id }));
    setTransfer({ id, status: 'done', done: file.size });
  } catch {
    setTransfer({ id, status: 'failed' });
  } finally {
    api.readClose(file.path);
  }
}

/* ---------- built-in server box (desktop) ---------- */
async function initHostBox() {
  $('#host-box').hidden = false;
  const paint = (s) => {
    $('#host-on').checked = s.enabled;
    const urls = s.urls.length ? s.urls : [];
    $('#host-status').innerHTML = s.error
      ? `Could not start: ${esc(s.error)}`
      : s.running
        ? `Running. This PC: <code>ws://localhost:${s.port}</code>` +
          (urls.length ? `<br>Phones on the same Wi-Fi: ${urls.map((u) => `<button class="link addr" data-u="${esc(u)}">${esc(u)}</button>`).join(' ')}` : '')
        : 'Off. Turn it on, or enter another server address above.';
    $('#host-status').querySelectorAll('.addr').forEach((b) => {
      b.onclick = async () => { try { await navigator.clipboard.writeText(b.dataset.u); toast('Address copied. Type it in the phone app.'); } catch { toast(b.dataset.u); } };
    });
  };
  $('#host-on').onchange = async (e) => paint(await api.setHost(e.target.checked));
  paint(await api.serverInfo());
}

/* ---------- boot ---------- */
(async () => {
  const info = await api.info();
  $('#name').value = info.name;
  $('#name').onchange = async (e) => { e.target.value = await api.setName(e.target.value); };
  $('#open-folder').onclick = () => api.openSaveFolder();

  if (!IS_DESKTOP) {
    document.body.classList.add('mobile');
    document.querySelector('nav [data-view="nearby"]').hidden = true;
    $('#v-nearby').hidden = true;
    showView('online');
  }
  if (api.serverInfo) await initHostBox();
  renderStaged();
  renderPeers();
  renderTransfers();
})();
