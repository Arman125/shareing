'use strict';
// Platform adapter. On the desktop app, preload.js already provides window.api.
// On Android (Capacitor) and in a plain browser this file provides the same API
// using web features plus the small native "GlideSaver" plugin.
(function () {
  if (window.api) return;

  const cap = window.Capacitor;
  const native = !!(cap && cap.isNativePlatform && cap.isNativePlatform());
  const saver = native
    ? (cap.registerPlugin ? cap.registerPlugin('GlideSaver') : cap.Plugins && cap.Plugins.GlideSaver)
    : null;

  const FLUSH = 2 * 1024 * 1024; // write received data to disk in 2 MB batches
  const files = new Map();       // key -> File (kept for sending)
  const writers = new Map();     // id -> { name, parts, bytes, sid }
  const noop = () => {};
  const uid = () => (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random());

  const load = (k, d) => { try { return localStorage.getItem(k) || d; } catch { return d; } };
  const store = (k, v) => { try { localStorage.setItem(k, v); } catch {} };

  function blobToBase64(blob) {
    return new Promise((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => { const s = String(r.result); resolve(s.slice(s.indexOf(',') + 1)); };
      r.onerror = () => reject(r.error);
      r.readAsDataURL(blob);
    });
  }

  async function flush(w) {
    if (!native || !w.parts.length) return;
    const blob = new Blob(w.parts);
    w.parts = []; w.bytes = 0;
    await saver.write({ id: w.sid, data: await blobToBase64(blob) });
  }

  window.api = {
    platform: native ? 'android' : 'web',

    info: async () => ({
      name: load('glide.name', native ? 'My phone' : 'This browser'),
      saveDir: native ? 'Downloads/Glide' : 'your Downloads folder',
    }),
    setName: async (n) => {
      const v = String(n).trim().slice(0, 40) || (native ? 'My phone' : 'This browser');
      store('glide.name', v);
      return v;
    },

    pickFiles: () => new Promise((resolve) => {
      const inp = document.createElement('input');
      inp.type = 'file';
      inp.multiple = true;
      inp.style.display = 'none';
      let done = false;
      const finish = (list) => { if (!done) { done = true; inp.remove(); resolve(list); } };
      inp.onchange = () => {
        const out = [];
        for (const f of inp.files) {
          const key = `${f.name}|${f.size}|${f.lastModified}`;
          files.set(key, f);
          out.push({ path: key, name: f.name, size: f.size });
        }
        finish(out);
      };
      inp.addEventListener('cancel', () => finish([]));
      document.body.appendChild(inp);
      inp.click();
    }),
    pathOf: () => '',
    statFile: async () => null, // drag-and-drop of local paths is desktop only

    // sending: read slices straight from the picked File (no copy, works for huge files)
    readChunk: (key, off, len) => files.get(key).slice(off, off + len).arrayBuffer(),
    readClose: async (key) => { files.delete(key); },

    // receiving
    rtcOpen: async (name) => {
      const id = uid();
      const w = { name: String(name), parts: [], bytes: 0, sid: null };
      if (native) {
        const r = await saver.begin({ name: w.name });
        w.sid = r.id;
        w.name = r.name || w.name;
      }
      writers.set(id, w);
      return id;
    },
    rtcWrite: async (id, data) => {
      const w = writers.get(id);
      if (!w) return;
      w.parts.push(data);
      w.bytes += data.byteLength;
      if (native && w.bytes >= FLUSH) await flush(w);
    },
    rtcClose: async (id) => {
      const w = writers.get(id);
      if (!w) return null;
      writers.delete(id);
      if (native) {
        await flush(w);
        const r = await saver.finish({ id: w.sid });
        return r.path || `Downloads/Glide/${w.name}`;
      }
      // plain browser: hand the finished file to the download manager
      const url = URL.createObjectURL(new Blob(w.parts));
      const a = document.createElement('a');
      a.href = url; a.download = w.name;
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 60000);
      return w.name;
    },

    showInFolder: (p) => { if (typeof toast === 'function') toast(`Saved to ${p}`); },
    openSaveFolder: () => { if (typeof toast === 'function') toast(native ? 'Received files are in Downloads/Glide' : 'Received files go to your Downloads folder'); },
    setBusy: (on) => { if (saver) saver.keepAwake({ on: !!on }).catch(noop); },

    // nearby discovery and incoming LAN requests exist on desktop only
    respond: noop,
    onPeers: noop,
    onIncoming: noop,
    onIncomingCancel: noop,
    onTransfer: noop,
    lanSend: async () => {},
  };
})();
