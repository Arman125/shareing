// Standalone Glide signaling server (for a VPS / hosting service).
// The desktop app already has this built in, so you only need this for internet use.
const { start } = require('./signaling');

const PORT = Number(process.env.PORT) || 8080;

start(PORT)
  .then((s) => console.log(`Glide signaling server listening on port ${s.port}`))
  .catch((e) => { console.error(`Could not start on port ${PORT}: ${e.message}`); process.exit(1); });
