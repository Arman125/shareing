// Glide signaling server core. Only introduces two people. Files never pass through it.
// Used by the desktop app (embedded) and by server.js (standalone).
const { WebSocketServer } = require('ws');

const ROOM_TTL = 15 * 60 * 1000;
const norm = (c) => String(c || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
const reply = (ws, o) => { if (ws.readyState === 1) ws.send(JSON.stringify(o)); };

// start(port) resolves to { port, close() } once listening, rejects if the port can't be used.
function start(port) {
  return new Promise((resolve, reject) => {
    const rooms = new Map(); // code -> { sockets: [], timer }
    const wss = new WebSocketServer({ port, maxPayload: 64 * 1024 });

    const dropRoom = (code) => {
      const r = rooms.get(code);
      if (!r) return;
      clearTimeout(r.timer);
      rooms.delete(code);
    };

    wss.on('connection', (ws) => {
      ws.alive = true;
      ws.on('pong', () => (ws.alive = true));
      ws.on('error', () => {});

      ws.on('message', (raw) => {
        let m;
        try { m = JSON.parse(raw.toString()); } catch { return; }

        if (m.type === 'create') {
          const code = norm(m.code);
          if (code.length !== 6 || rooms.has(code)) return reply(ws, { type: 'error', message: 'That code is taken. Try again.' });
          rooms.set(code, { sockets: [ws], timer: setTimeout(() => dropRoom(code), ROOM_TTL) });
          ws.code = code;
          reply(ws, { type: 'created' });
        } else if (m.type === 'join') {
          const code = norm(m.code);
          const r = rooms.get(code);
          if (!r) return reply(ws, { type: 'error', message: 'Code not found. Check it and try again.' });
          if (r.sockets.length >= 2) return reply(ws, { type: 'error', message: 'That code is already in use.' });
          r.sockets.push(ws);
          ws.code = code;
          reply(ws, { type: 'joined' });
          reply(r.sockets[0], { type: 'peer-joined' });
        } else if (m.type === 'signal') {
          const r = rooms.get(ws.code);
          const other = r && r.sockets.find((s) => s !== ws);
          if (other) reply(other, { type: 'signal', data: m.data });
        }
      });

      ws.on('close', () => {
        const r = rooms.get(ws.code);
        if (!r) return;
        r.sockets = r.sockets.filter((s) => s !== ws);
        r.sockets.forEach((s) => reply(s, { type: 'peer-left' }));
        if (!r.sockets.length) dropRoom(ws.code);
      });
    });

    const beat = setInterval(() => {
      wss.clients.forEach((ws) => {
        if (!ws.alive) return ws.terminate();
        ws.alive = false;
        ws.ping();
      });
    }, 30000);

    wss.once('error', (err) => { clearInterval(beat); reject(err); });
    wss.once('listening', () => {
      wss.on('error', () => {});
      resolve({
        port: wss.address().port,
        close() {
          clearInterval(beat);
          for (const r of rooms.values()) clearTimeout(r.timer);
          rooms.clear();
          wss.clients.forEach((c) => c.terminate());
          wss.close();
        },
      });
    });
  });
}

module.exports = { start };
