# Glide: guide for an AI that works on this code (v44)

Read this file first. It is written so that you do **not** have to re-read the whole project to understand it.
Every statement was checked against the code at v44 unless it says "NOT verified". If the code and this file ever disagree,
the code wins; then fix this file.

Language note: the owner writes in Bengali (sometimes typed in English letters). Reply to them in Bengali. Code, comments and UI text are English.

## 0. RULES FOR EVERY AI THAT TOUCHES THIS PROJECT (read first, obey always)

The owner asked that no AI has to re-read the whole code. This file is the replacement for that. So:

1. **Read this file, then open ONLY the files/functions your task needs.** Use section 14 (code index) and the "Where to change what" table below to jump straight to the right place. Do not re-read `app.js` top to bottom.
2. **Reply to the owner in Bengali** (they sometimes type Bengali in English letters). Code, comments and UI text stay English.
3. **After every change you MUST update this file** (the owner requires it): add a change-log entry in section 10 (newest first, say what was wrong, the cause, the fix, what is NOT verified), fix any sentence in this file that is now false, refresh section 14 (`node tools/make-index.js`), update `README.md`, bump the version label in `renderer/index.html` (`<small class="ver">`), and rebuild the zip `glide-app-vNN.zip` (folder `glide/` inside). If the code and this file disagree, the code wins, then fix this file.
4. Run `node tools/check-compat.js` (must print `compat OK`) and `node --check renderer/*.js` before delivering. Run the Playwright tests in `tools/` if you can (section 11). Say honestly what you could not run.
5. The owner's setup: Windows PC runs the Glide app (host), phones connect to `http://192.168.0.196:8080` in a browser or use the Android app. **A page served by the host app is the app's bundled copy: after any `renderer/` change the EXE/APK must be rebuilt and reinstalled** (or the website redeployed). Always tell the owner this.
6. Owner decisions that must not be undone without asking: *Recognise the host* is **ON by default everywhere** (apps and web; v40). Exactly one device is ever labelled HOST (v38). Idle animation has no motion (invariant 6). Old-browser rules (section 8).

### Where to change what

| Task | Go to |
|---|---|
| Text, buttons, cards, DOM ids | `renderer/index.html` (ids listed in 5.4; drop bar = `#drop`, Options card = `#opt-card`) |
| Look, spacing, sizes, mobile layout | `renderer/styles.css` (`.drop*`, `#opt-card`, `.card`, `.t*`, `.fx-*`, `@media (max-width:760px)`) |
| Staged files, Send/Choose buttons | `app.js`: `addFiles`, `renderStaged`, `#choose`, `#send-top` handler, `sendStagedOnline`, `#send-online` |
| Sending to many devices | `app.js`: `sendMany`, `sendPass` (4.5) |
| Receiving, Accept modal, auto-accept | `app.js`: `askIncoming`, `renderModal`, `answer`, `autoAccept` |
| Transfers list | `app.js`: `setTransfer`, `renderTransfers` |
| Host detection and Options | `app.js`: `hostIdOn`, `hostPeer`, `isHostPeer`, `amHost`, `renderLivePeers`, the `#opt-host`/`#opt-auto` block |
| Connecting (rooms, WebRTC, relay) | `app.js`: `startRoom`, `makePeer`/`addPeer`, `makeLive`, `goRelay`, `makeRelayChannel` |
| Link animation | `renderer/linkfx.js` + `.fx-*` CSS |
| Server protocol | `server/signaling.js` AND `mobile/native/GlideHostPlugin.java` (always both) |
| Platform differences, file read/write | `renderer/platform.js` (browser/Android), `preload.js` + `main.js` (Windows) |

---

## 1. What Glide is

Glide sends files between devices. One shared UI (`renderer/`) runs in three places:

| Target | Runs as | Server part |
|---|---|---|
| Website | `node server/server.js` (Render, Docker, any VPS) | `server/signaling.js` |
| Windows app | Electron: `main.js` + `preload.js` | embeds `server/signaling.js` (port 8080, env `GLIDE_PORT`) |
| Android app | Capacitor WebView showing `renderer/`, plus 4 Java classes | `mobile/native/GlideHostPlugin.java` (own HTTP + WebSocket server, port 8080) |

Two ways of sending:
1. **Online** (this is what most code is about): devices meet in a *room* on a signaling server, then talk over WebRTC data channels. Files never pass through the server, except in **relay mode** (see 4.3).
2. **Nearby** (Windows app and Android app only, no server): UDP broadcast on port 53319 to find each other, plain HTTP on port 53318 to receive files. Code: `main.js` (Windows) and `GlideNearbyPlugin.java` (Android). The web page has no Nearby tab (it is hidden when `api.platform === 'web'`).

Words you will meet:
* **host** = the device that runs the server (its own app, or the machine running `server.js`). Other people open `http://HOST-IP:8080` in a browser; that is the **host page**.
* **home code** = a fixed code every device has (`glide.home` in localStorage, made by `getHome()`). A device that is "always ready" (standby) waits alone in a room named after its home code; others `enter` that room to reach it.
* **room** = set of up to 8 sockets (`MAX_PEERS = 8`) sharing a code. **peer** = another device in my room.

---

## 2. Repository map

```
glide/
  AI-GUIDE.md            this file
  README.md              user-facing docs (features by version, deploy, known limits)
  package.json           Electron app + electron-builder config (win nsis + portable). deps: ws. "web" script = node server/server.js
  main.js                Electron main process: window, IPC handlers, Nearby (UDP 53319 / HTTP 53318), starts signaling on SIGNAL_PORT
  preload.js             exposes window.api (desktop) via contextBridge; list of IPC calls
  server/
    signaling.js         THE server core: HTTP static files + /healthz /lan /ice /logo + WebSocket rooms. exports { start(port, opts) }
    server.js            standalone entry (PORT env, default 8080), serves ../renderer or ./renderer
    package.json         deps: ws
  renderer/              shared UI (copied to mobile/www for the APK; served by signaling.js for the website)
    index.html           all screens; CSP meta tag; script order (see 5.1); version label <small class="ver">
    styles.css           all CSS (glass look). Blocks: base, nav/side, cards, drop zone, transfers (.t*), modal, phone layout (@media 760px, body.mobile), host card, fx-* (link animation), lg-* (logo editor)
    app.js               main logic (about 1090 lines): state, nearby UI, online rooms (WebRTC), sending/receiving, transfers list, host box
    platform.js          builds window.api for browser + Android when preload.js did not (desktop has its own)
    logo.js              custom logo: editor, canvas crop, GET/POST /logo, publishes window.GlideLogoData
    linkfx.js            link animation (web page only): nodes, glow, host panel, transfer animation
    filetypes.js         file extension -> folder name (Video, Image, APK, PDF, ...), also required by main.js
    qr.js                QR code generator (QR.svg(text))
    config.js            window.GLIDE_SERVER = '' (website address baked into apps; empty = type it in the app)
  mobile/
    package.json, capacitor.config.json   Capacitor 7; androidScheme "http", cleartext true; webDir "www"
    scripts/android.js   `setup` / `apk`: copies renderer -> www, copies native/*.java into the Android project, writes MainActivity (registers 3 plugins), patches AndroidManifest (permissions, cleartext, GlideService, share targets), icons
    native/GlideHostPlugin.java    plugin "GlideHost": the phone's own HTTP+WebSocket server (same protocol as signaling.js), /logo, foreground-service helpers, notifications
    native/GlideNearbyPlugin.java  plugin "GlideNearby": Nearby mode (UDP 53319, HTTP 53318)
    native/GlideSaverPlugin.java   plugin "GlideSaver": saves received files (Downloads/Glide/<type>), reads picked files (readUri/closeUri), share sheet, keep-awake
    native/GlideMdns.java          (v44) helper class, not a plugin: answers the name glide.local; started/stopped by GlideHostPlugin
    native/GlideService.java       foreground service (permanent notification, keeps phone ready)
    icons/               launcher icons
  tools/                 dev tests (Playwright), NOT shipped (see 11)
  Dockerfile, render.yaml, .dockerignore   website deploy (Dockerfile copies only server/ and renderer/)
  .github/workflows/android.yml            CI: builds debug APK
  build-*.bat, install-apk.bat, build-apk.ps1   Windows helper scripts
```

Only `main.js, preload.js, renderer/**, server/signaling.js, build/icon.*` go into the Windows app (`package.json > build.files`). `tools/` and this guide are never packaged.

---

## 3. Server: `server/signaling.js`

`start(port, { staticDir, dataDir })` -> Promise of `{ port, close() }`. Listens on `0.0.0.0`.

HTTP (only when `staticDir` is given; otherwise only `/healthz`, `/lan`, and 426 for the rest):

| Path | Behaviour |
|---|---|
| `/healthz` | `200 ok` |
| `/lan` | `{ port, urls: [http://LAN-IP:port,...] }`. URLs only for loopback/private-network callers (a hosted site must not reveal internal IPs) |
| `/ice` | extra ICE servers from env `TURN_URLS`, `TURN_USER`, `TURN_PASS` (JSON array, may be empty) |
| `/logo` | shared logo, contract in 3.2 |
| anything else | static file from `staticDir`; only extensions in `TYPES`; path-traversal checked (`file.startsWith(root + sep)`); `cache-control: no-cache` |

### 3.1 WebSocket protocol (JSON text frames; same in `GlideHostPlugin.java`)

Client -> server: `{type:'create'|'join'|'enter', code}`, `{type:'announce', code, name}`, `{type:'whois'}`, `{type:'signal', to, data}`, `{type:'ping'}`.
Server -> client: `{type:'joined', id, peers:[ids]}`, `{type:'peer-joined', id}`, `{type:'peer-left', id}`, `{type:'signal', from, data}`, `{type:'whois', home, name}`, `{type:'error', message}`.

* `create` = new one-time room (fails if code exists; expires after `ROOM_TTL` 15 min if nobody joins). `join` = must exist. `enter` = create-or-join a permanent room (used for home codes).
* Codes are normalised: uppercase, only `A-Z0-9`, length 1..12.
* Peer ids are small integers (1, 2, ...), reused when free. The device that is already in the room gets `peer-joined`; the **newcomer** gets `joined` with the existing ids and *waits to be called* (the existing device creates the WebRTC offer).
* `announce`: the host device says which home code it waits in (`ws.home`, `ws.hname`). `whois` returns the (last) announcing client's home code and name. Visitors use it to find the host: `probeInfo(url)` / `probeHost(url)` in app.js.
* Binary frames = relay mode (see 4.3). First byte is the target id; the server rewrites it to the sender id.
* Heartbeat: server pings every 30 s and terminates dead sockets.

### 3.2 `/logo` contract (Node and Java must match)

* `GET` -> `200 image/png` or `404 none`. Every response: `X-Can-Edit: 1|0`, `Access-Control-Allow-Origin: *`, `Access-Control-Expose-Headers: x-can-edit`, `Cache-Control: no-store`. `OPTIONS` -> 204 with CORS headers.
* `POST` body is text: `reset` deletes; `data:image/png;base64,...` must decode to a PNG (magic `89 50 4E 47`), max 600 KB, else 400/413. `text/plain` on purpose (a "simple" CORS request, no preflight from the WebView origin `http://localhost` to `http://127.0.0.1:8080`).
* Who may POST: the host itself (loopback or one of the machine's own interface addresses). Anyone else gets `403 {"error":"host-only"}`, except in Node when env `LOGO_KEY` is set: header `x-logo-key` must equal it, else `403 {"error":"key","needKey":true}`.
* If the `Origin` header is present and not `null`, its host must equal the request host, `localhost` or `127.0.0.1`, else 403 (blocks other websites from posting to a local server).
* Storage: Node `opts.dataDir` or env `DATA_DIR` or `server/data` -> `logo.png` (Windows app passes `app.getPath('userData')`; Dockerfile creates `/app/server/data`). Java: `getFilesDir()/logo.png`.

---

## 4. Online sending: how it works (all in `renderer/app.js`)

### 4.1 Globals other scripts rely on (classic scripts, top-level `const` is visible across files)

| Name | Defined in | Meaning |
|---|---|---|
| `api` | preload.js (desktop) or platform.js | platform adapter, `api.platform` is `'desktop' \| 'android' \| 'web'` |
| `state` | app.js | `{ staged[], peers[], transfers: Map, incoming[], room }` |
| `room` | app.js (`= state.room`) | `{ code, ws, status, mode, url, myId, joined, standby, peers: Map<id, peer>, link }` |
| peer object | `addPeer()` | `{ id, name, home, live, relay, sel, dc, pc, early[], curIn, timer, relayTimer }` |
| `setTransfer(patch)` | app.js | create/update a transfer row (`id` required) |
| `toast(msg)`, `showView(v)`, `esc(s)`, `fmt(bytes)` | app.js | helpers |
| `window.GlideLogoData` | logo.js `show()` | current logo as a data URL, `''` when none |

A transfer in `state.transfers`: `{ id, name, size, dir:'out'|'in', peer:<name>, pid:<peer id>, status, done, speed, t0, avg, path, error }`.
`status`: `waiting | sending | receiving | done | declined | failed`. Always set `pid` so animations match by id (names may repeat).

### 4.2 Connect

`startRoom(mode, code, opts)` opens the WebSocket, sends `{type: mode, code}`, then for each peer builds an `RTCPeerConnection` (STUN: Google x2 + Twilio, plus `iceExtra` from `/ice`), a data channel `files`, and trades SDP/ICE through `signal` messages. `unhide()` swaps hidden `.local` mDNS addresses for the server's LAN IP when the server is an IP address (hotspot case). When the data channel opens, `makeLive(p)` sets `p.live = true` and sends **`hello`** `{t:'hello', name, home}`; the receiver stores `p.name` and `p.home`.

**How a visitor knows who the host is (v34):** the host device sends `hello.host = true` (`amHost()`), stored as `peer.isHost`. Fallback for older peers: `hello.home` equals `room.code` (after normalising). Use `isHostPeer(p)`. **This device is the host** when `amHost()` is true (NOT `room.standby`: every always-ready device is standby). `linkfx.js` uses the same.

### 4.3 Relay mode

If the direct link is not up ~6 s after meeting (typical when the phone is the hotspot) `goRelay(p)` replaces the data channel with `makeRelayChannel(ws, peerId)`: same interface, but bytes go through the signaling WebSocket as binary frames (first byte = other device's id). Still local-network speed. `dc.isRelay` is true then.

### 4.4 Data-channel messages (text JSON, plus binary chunks)

`hello {name, home, host}` (`host:true` = this device runs the server the other end is connected to; v34) · `offer {id, name, size}` · `accept {id}` · `decline {id}` · binary chunks (the file) · `end {id}`. A receiver handles one incoming file per peer at a time (`p.curIn`).

### 4.5 Sending one file to many devices (changed in v31, `sendMany` + `sendPass`)

1. `sendMany(file, targets)`: for every connected target create a transfer row (`waiting`), send `offer`, register a waiter (60 s timeout -> answer `null`).
2. Each answer is handled **as it arrives** (no `Promise.all`): `null` -> row `failed` + toast; decline -> `declined`; accept -> the device goes into the `ready` list.
3. Loop: when `ready` is not empty, wait 1 s if some answers are still open (so devices that tap Accept at about the same moment share one pass), take all `ready` devices as a batch, set them `sending`, run `sendPass(file, batch)`.
4. `sendPass`: reads the file **once** per chunk (`api.readChunk(path, offset, len)`, next chunk is prefetched) and writes it to every device of the batch, respecting `dc.bufferedAmount` (`MAX_BUFFER` 8 MB). Chunk = min over the batch of SCTP max message size (cap `CHUNK` 256 KB; 128 KB if any is relay). A device whose channel closes is marked `dead` and fails alone. Ends with `end` per device.
5. A device that accepts while a pass is running waits for the next pass (starts again from byte 0). Passes are sequential on purpose: on Android `GlideSaverPlugin.readUri` keeps ONE sequential stream per file and re-opens + skips whenever the offset differs, so reading one file from two offsets at once would be very slow.
6. `finally` -> `api.readClose(file.path)`. Several staged files are sent one after another (`sendStagedOnline`).

Result: only devices that accept receive the file; nobody waits for someone who has not answered.

### 4.6 Receiving

`offer` -> `askIncoming()` shows the Accept/Decline modal (and a notification on Android). Accept -> `api.rtcOpen(name)` (desktop: file written into Glide/<type> in the save folder; Android: `GlideSaver.begin` writes to Downloads/Glide/<type> in 2 MB batches; plain browser: parts are kept in memory and handed to the browser's download manager when `end` arrives), row `receiving`, reply `accept`. Chunks go to `api.rtcWrite`, `end` -> `api.rtcClose` -> row `done` with `path`.

---

## 5. Client structure

### 5.1 Script order (`index.html`, bottom): `config.js, filetypes.js, platform.js, qr.js, app.js, logo.js, linkfx.js`
`logo.js` and `linkfx.js` run after `app.js`, so they may use its globals. `linkfx.js` returns immediately unless `api.platform === 'web'` (flag `ONLY_WEB`).

### 5.2 CSP (meta tag in index.html)
`default-src 'self'; connect-src 'self' ws: wss: http://127.0.0.1:* http://localhost:*; style-src 'self' 'unsafe-inline'; script-src 'self'; img-src 'self' data: blob:`. No inline scripts allowed. `127.0.0.1/localhost` in connect-src are needed so the Android/Windows app can reach its own `/logo`; `data:`/`blob:` in img-src for the logo and the animation picture.

### 5.3 localStorage keys
`glide.name, glide.home, glide.standby, glide.notif, glide.hostid ('0' = do not recognise host), glide.autoaccept ('1' = accept all files), glide.saved (remembered devices), glide.server.v2, glide.host ('0' = host off on Android), glide.logo (logo data URL), glide.logokey (LOGO_KEY password)`. All access is in try/catch.

### 5.4 Views and DOM ids
Nav buttons `data-view="nearby|online|transfers"`; sections `#v-nearby, #v-online, #v-transfers`. Online has cards `#on-idle` (create/join, host card, home card, saved devices, server address), `#on-wait` (code + QR, contains `#fx-wait`), `#on-live` (connected, `#live-peers`, contains `#fx-live`). Transfers list is `#tlist`; `renderTransfers()` rebuilds it from `state.transfers` (innerHTML, every dynamic value passed through `esc()`).

### 5.5 Phone layout
`html.mobile` / `body.mobile` classes are added at boot for every non-desktop platform. `@media (max-width: 760px)` switches to a single column with a fixed bottom tab bar.

---

## 6. Link animation (`renderer/linkfx.js` + `.fx-*` in styles.css)

Shows in `#fx-wait` and `#fx-live` (web page only). It polls every 300 ms (`tick()`), reads `room`, `state.transfers`, `window.GlideLogoData`, and draws an SVG. It rebuilds the SVG only when its *signature* changes (device list/names/host flag/picture), never for progress; progress only changes classes, text and the ring's `stroke-dasharray`.

**Layout:** "You" at the left, every other device in a column at the right. The **host** is drawn first, bigger, inside a dashed peach "HOST" panel, with the host's profile picture (the shared logo) in a circle; without a logo it shows a server icon. If *this* device is the host (`room.standby`), the panel and picture are on "You" ("YOU · HOST"). Host detection: `peer.isHost` (hello.host) or, for older peers, `peer.home` normalised equals `room.code` normalised; "me" is host when `amHost()`.

**States (CSS classes on each node `g.fx-node`):**

(v36: every non-picture icon also has a shape-following bloom, see 10 > v36.)

| Class | Meaning | Look |
|---|---|---|
| `live` | connected, idle | steady soft glow (radial gradient), green dot, text "Connected", line has a faint glow. **No motion** |
| `connecting` | not connected yet | dim, amber blinking dot, dashed blinking line, "Connecting…" |
| `act` | sending or receiving a file | brighter breathing glow, light running round the outline, progress ring, text "Sending 42%" / "Receiving 70%" / "Sending & receiving" |
| `rcv` (with `act`) | receiving only | teal instead of purple |
| `fin` / `bad` | ended (shown 3.5 s) | ring full green "Done ✓" / red "Failed" |
| `host`, `me` | tags | host = peach glow and border |

Line (`g.fx-link[data-state]`): `idle | connecting | out | in | "out in"`. Dots travel towards the receiver (purple = outgoing, teal = incoming). Only devices with an active transfer animate; `prefers-reduced-motion` stops all motion.

**Rules this file follows (old browsers, about Chrome 70):** no `replaceChildren`, no `?.`/`??`, no CSS `filter` on SVG parts (glow = radial gradients + wide translucent strokes), all shapes are `<path>` with `pathLength=100` (so the running light has equal speed everywhere, and `pathLength` on `<rect>/<circle>` is not relied on), device names set with `textContent` (no HTML injection), picture set with both `href` and `xlink:href`, ids made unique per SVG (`fxa-N`, `fxt-N`, `fxh-N`, `fxc-N-key`).

---

## 7. Custom logo (`renderer/logo.js`)

Tap `#logo` -> editor (photo picker, drag, pinch/slider/wheel zoom, rotate 90) -> Save crops to a 256x256 PNG, stores in `localStorage('glide.logo')`, uploads `POST /logo`. On load and whenever the tab becomes visible `refresh()` asks the host: host has a logo -> show+cache; host has none -> browsers clear it, apps re-upload their cached copy. `X-Can-Edit: 0` -> tapping only shows a toast. Base URL: same-origin `/logo` in a normal browser tab, otherwise `http://127.0.0.1:<port>/logo`. `show()` also sets the favicon and **`window.GlideLogoData`** (used by linkfx.js).

---

## 8. Old-browser rules (the owner tests on an old Android browser)

* In CSS, put a plain declaration **before** every modern one: `bottom: 12px; bottom: max(env(...), 12px)`, `height: 100vh; height: 100dvh`, `width: 420px; width: min(420px, 100%)`, `top/right/bottom/left: 0` before `inset: 0`.
* No `gap` on **flex** containers in new code (ignored before Chrome 84): use margins (`.t-top > * + *`, `.t-actions .link + .link`). Older rules still use flex `gap` (e.g. `.row`, `.me`, `.share`, `.brand`): spacing may collapse on very old browsers. NOT fixed.
* Grid items that hold long text need `grid-template-columns: minmax(0, 1fr)` and `min-width: 0` (this was the v32 overflow bug, see 10).
* JS: no `replaceChildren`, `?.`, `??`, `.at()`, `replaceAll`, `matchAll`, `structuredClone`, `.flat()`, **`Blob.arrayBuffer()` / `Blob.text()` / `Blob.stream()` (Chrome 76; v33 bug, see 10)**. To read a Blob use `blobToBuffer()` in platform.js (FileReader fallback). Run `node tools/check-compat.js` after every JS change: it must print `compat OK`. A guarded use is marked with a `compat-ok` comment on the same line.
* Never build HTML from a device name / file name without `esc()` (innerHTML) or `textContent`.

---

## 9. Android and Windows specifics

* Android plugins are registered in the generated `MainActivity` (written by `mobile/scripts/android.js`): `GlideSaverPlugin, GlideNearbyPlugin, GlideHostPlugin`. `GlideService` is declared in the manifest. JS reaches them through `Capacitor.registerPlugin('GlideSaver'|'GlideNearby'|'GlideHost')` in platform.js.
* `GlideHostPlugin` re-implements `signaling.js` in Java: rooms (`MAX_PEERS` 8, `ROOM_TTL` 15 min), `announce`/`whois`, binary relay, static files from the WebView assets, `/healthz`, `/lan`, `/ice`, `/logo` (`serveLogo`, `isSelf` via `NetworkInterface.getByInetAddress`, `originOk`, `logoReply`). **Any protocol change must be made in both files.**
* Windows: `main.js` IPC handlers are listed in `preload.js`. `read-chunk` uses one file descriptor per path (`readers` map, positional reads, so concurrent reads are safe); `read-close` closes it.
* Ports: 8080 signaling/website (Windows env `GLIDE_PORT`), 53318 Nearby HTTP, 53319 Nearby UDP.

---

## 10. Change log (what each version added; newest first)

* **v44** (this one)
  * *`glide.local` built* (owner asked twice: "try it", then "make glide.local"; PC could not open it before because nothing advertised the name). New `mobile/native/GlideMdns.java`: a tiny mDNS responder (pure Java, no library). Binds UDP 5353 (`MulticastSocket`, reuse address), joins 224.0.0.251 on every up, multicast-capable, non-mobile-data interface (re-joins every 3 s so a hotspot turned on later works), holds a `WifiManager.MulticastLock` (permission `CHANGE_WIFI_MULTICAST_STATE` was already in the manifest list of `mobile/scripts/android.js`). It answers questions for the name `glide.local` of type A or ANY from port 5353 with the phone's IPv4 on the interface/subnet the question came from (answer: id 0, flags 0x8400, class 0x8001, TTL 120); multicast reply, plus unicast if the QU bit is set. `answer()` is a pure static method. Not answered: AAAA, other names, questions not sent from port 5353 (plain `dig`).
  * Wiring: `GlideHostPlugin.startServer()` starts it, `stopServer()` stops it, `infoResult()` adds `mdns: "glide.local"` while it is listening (empty otherwise). It travels through `api.serverInfo()` / `api.setHost()` (platform.js spreads the whole object). app.js (`initHostBox` > `paint`) appends an "Experimental: ... try http://glide.local:8080 (Android browsers cannot open .local names)" sentence to `#hc-note`. `webUrls` and the QR are unchanged (IP only). Only the phone host has it; the Windows app / `signaling.js` do not answer the name. It is not part of the signaling protocol (invariant 1 unaffected).
  * *Limits, tell the owner:* helps Windows 10+/iPhone/Mac visitors; **Android browsers (Chrome) cannot open `.local` names**; the port `:8080` is still needed (an app cannot bind port 80). Two hosts must not use the same name.
  * Verified: `GlideMdns.java` compiles with `javac` against Android stubs; `tools/mdns-test/run.sh` passes 8 logic checks and one real multicast round trip on the build machine (a query sent to 224.0.0.251:5353 was answered with the interface IP). `check-compat.js` OK, `node --check`. NOT verified: on a real phone (Android may refuse the bind, the vendor firmware may drop multicast, hotspot interface behaviour), from a real Windows PC resolver, and `GlideHostPlugin.java` itself was NOT compiled (needs Capacitor); only brace balance was checked. If `glide.local` still fails, ask the owner to run on the PC: `nslookup glide.local` is useless (unicast DNS), use `ping glide.local` and report the text; check that host mode is on and that the phone and PC are on the same Wi-Fi/hotspot.
* **v43**
  * *Send files button cut off, web UI too big* (owner's PC screenshot: "Connected to 2 devices", the buttons were at the bottom edge, partly hidden). Cause: `#on-live` is a `.card` (`overflow:auto`) and the link animation was up to 420 px wide, so the buttons sat below the fold inside a scrolling card. Fix: index.html wraps the animation, device list and hint in `<div class="live-body">`; styles.css (end of file, v43 block): `#on-live` is a flex column, `.live-body` scrolls (`flex:1 1 auto; min-height:0; overflow:auto`) and the `.row` with Send files / Disconnect is `flex:none`, so it is always visible. Animation smaller: `.fx-svg { max-width:300px; max-height:34vh }`. Phone layout keeps the old block layout (`body.mobile #on-live`). Only `#on-live` was changed; `#on-wait` (waiting card) still has the old layout.
  * *Owner says `glide.local` does not work on the PC.* Correct: it was never built in any version, nothing advertises that name (see the v42 entry for why it is hard). Do not tell the owner it should work.
  * Verified: `check-compat.js` OK. NOT verified: no browser run; the new layout was not looked at on a real screen.
* **v42**
  * *Removed everything v41 added.* The owner had asked to TRY the `glide.local` short name, not a bigger QR / Share link button; v41 did the wrong thing. Removed again: `shareAddress()`, `#hc-sharebtn`, `#lan-share`, the bigger `.hostcard .qr`, `api.shareText` (platform.js) and `GlideSaverPlugin.shareText` (Java). The code is back to v40 behaviour; only the version label differs. Lesson: do exactly what the owner names; if you think another idea is better, say so but do not build it unasked.
  * *(built in v44)* *`glide.local` was NOT done in v42.* The owner asked to try it. Reasons it was not built blind: cannot be tested in the sandbox (no phone/Wi-Fi); `NsdManager` advertises a service, not an arbitrary hostname; a custom hostname needs Android 14+ (`NsdServiceInfo.setHostname`); Chrome on Android does not resolve `.local` names, so it would only help Windows/iOS/macOS visitors. If the owner asks again, tell them this, then build it as an experiment and say it is untested.
* **v41** (removed in v42, kept here so nobody re-adds it by mistake)
  * *Easy way to give the host address to other people* (owner: the phone is the host, others use a browser, no VPS). Browsers cannot be pushed a popup/notification without an internet server, so the address is made easy to hand over instead: (1) host card (`#host-card`, Online idle screen) now has a bigger QR (220 px, `.hostcard .qr`) with the line "Scan this with the other phone's camera", and a primary **Share link** button `#hc-sharebtn` next to Copy; (2) the localhost banner has the same button `#lan-share`; (3) `shareAddress(url)` (app.js, before `paintLanBanner`) calls `api.shareText(text)` and falls back to copying the address. `api.shareText` is new in platform.js: Android -> `GlideSaver.shareText` (new `@PluginMethod` in `GlideSaverPlugin.java`, `Intent.ACTION_SEND` text/plain), browsers -> `navigator.share` when it exists (needs a secure context, so on `http://IP:8080` it is usually missing and the address is copied instead), desktop (preload) has no `shareText` -> copy.
  * Verified: `check-compat.js` OK, `node --check renderer/*.js`. NOT verified: the Java was never compiled (invariant: see section 11); nothing was run in a browser or on a phone; the host card is only shown on the Online idle screen, not while a session is waiting/connected (not changed).
  * *Idea NOT done: `glide.local` name.* Not implemented because it could not be tested here and is unreliable: Android's `NsdManager` advertises a service, not a hostname for any name; a custom hostname needs Android 14+ (`NsdServiceInfo.setHostname`); and Chrome on Android does not resolve `.local` names. It would only help Windows/iOS/macOS visitors. Use the QR/Share link instead.
* **v40**
  * *"Send" button in the drop bar* (owner's screenshot of the Transfers page: "1 file ready / Pick who should get them" had no way to send). New `#send-top` (primary button, `hidden` unless `state.staged.length`, shown/hidden in `renderStaged()`), placed with `#choose` inside `<div class="drop-actions">` in the `#drop` card (index.html). Handler (app.js, right after `#send-online`): files staged and room `live` and at least one ticked device -> `sendStagedOnline()`; live but nobody ticked -> `showView('online')` + toast; not connected -> Android: `showView('nearby')` + toast, otherwise `showView('online')` + toast "Connect to a device first". CSS: `.drop-actions` (flex, margin instead of gap), phone layout makes it full width with two equal buttons.
  * *"Recognise the host" is ON by default again, everywhere* (owner's decision; v39's "off on web" is reverted). `hostIdOn()` = `load('glide.hostid','1') !== '0'`: only an explicit untick (`'0'`) turns it off.
  * *Guide reorganised*: new section 0 (rules for every AI, where-to-change table), section 14 (function index made by `tools/make-index.js`).
  * Verified: `check-compat.js` OK, `node --check renderer/app.js`. NOT verified: no browser/Playwright run in this session (Playwright was not available), so the Send button layout and the Options card size (v39) were never looked at on a real screen; the existing `tools/test-*.js` were not re-run. `test-host-detect.js` may assume the old default; if a check about the option default fails, update the test, not the owner's decision.
* **v39**
  * *Options card too big on the PC web page* (owner screenshot): the generic `.card` has `flex:1`, so `#opt-card` stretched to fill the free height. Fix in styles.css: `#opt-card { flex:none; padding:14px 20px; overflow:visible }` plus smaller heading/hint spacing. Not looked at in a real browser by me.
  * *(reverted in v40)* "Recognise the host" default was OFF on the web page for one version; it is ON everywhere again.
* **v38**
  * *Two HOSTs still shown with v37* (owner's Firefox screenshot, page labelled v37: "My phone (host)" and "Android phone (host)"). Cause found by reading `isHostPeer`: when `room.hostHome` was empty, a peer WITH the `host` flag was host only if it had the lowest id, but a second peer WITHOUT the flag still fell through to the third rule (`peer.home === room.code`) and was labelled too. Fix: `hostPeer()` in app.js picks exactly ONE peer: whois match > flagged peers > home-code match, lowest id inside each group; `isHostPeer(p)` = `hostPeer() === p`. Why `hostHome` was empty on the owner's setup is NOT known (whois round trip was never verified end to end).
  * *Options card not visible on the web page* (owner: "shown in the app, not on the web"). Cause: `#opt-card` was inside `#on-idle`, which is hidden whenever the room is waiting or connected, and the web page is usually used while connected. Fix: `#opt-card` is now its own `.glass.card` after `#on-live` in `#v-online`, visible in every state, in the apps and on the web.
  * Tests: `tools/test-host-detect.js` has 12 checks (adds: the exact screenshot case -> one host; options card visible in idle/waiting/live).
* **v37**
  * *Two options* in a new card `#opt-card` (Online page, own card after `#on-live`, always visible; localStorage keys in 5.3): **"Recognise the host"** (`glide.hostid`, default ON, `'0'` = off, helper `hostIdOn()`) and **"Accept all files automatically"** (`glide.autoaccept`, `'1'` = on, default OFF, helper `autoAccept()`).
  * *Auto-accept*: `askIncoming()` (app.js) accepts at once when on: toast "Receiving X from Y", `r.cb(true)`, no modal. Covers online offers AND Nearby requests (both go through `askIncoming`). Turning it on answers requests already waiting. Security note is in the UI text: anyone connected can then send files.
  * *Host recognition is now server-verified*, because the owner still saw two HOST panels: (1) the host app announces its home code to its own server (`announce`) when it is standby OR `amHost()`; (2) a visitor asks `whois` once joined (retries 2x, 3 s apart) and stores `room.hostHome`; (3) `hostPeer()` / `isHostPeer(p)` (app.js, used by linkfx.js and the device list) pick exactly one host, see v38 above. With the option OFF nobody is labelled and the device sends no `host` flag (a standby announce still happens: the hotspot auto-find feature needs it).
  * **Deployment trap (important):** the page that a visitor sees at `http://HOST-IP:8080` is served from the host app's bundled assets (APK `www/` or the Windows app). Visitors run the *host app's* copy of `app.js`. A fix in `renderer/` does nothing for them until the host app (APK / EXE) is rebuilt and reinstalled; the website (Render) needs a redeploy. Ask the owner which one they run before debugging "it did not change".
  * Tests: `tools/test-host-detect.js` now has 10 checks (adds: two devices claim host -> only the whois one wins; no whois -> only one shown; option off -> none; auto-accept on/off).
* **v36**
  * *Neon bloom around the icons* (owner sent a video of a chip icon with a soft white glow that follows the icon's shape). Added `.fx-bloom` inside `icon()` in linkfx.js: for each icon shape, 4 extra `<path>`s (`fx-b1..b4`: three wide translucent strokes in the accent colour + one white inner halo), drawn BEHIND the existing `fx-line`. CSS in styles.css after `.fx-node.rcv .fx-glow`. No CSS `filter` (old-browser rule).
  * Behaviour is unchanged on purpose (owner: icons must work as before, background and colours must not change): `connecting` = no bloom; `live` = steady bloom, no motion (invariant 6 still holds); `act` = bloom breathes (`fx-bloom` keyframes, 1.8 s) together with the running light and ring; colours: accent purple, teal when receiving (`.rcv`), peach on the host. Not added to the host's profile-picture node (`kind === 'pic'`): that icon is a white ring over the photo.
  * No change to icons, sizes, disc, wires, ring, background. `prefers-reduced-motion` still stops it (`.fx-node *`).
* **v35**
  * *Two devices both showed HOST* (owner's screenshot: GOGO and "Android phone" both had the HOST panel and "(host)"). Cause: my v34 `amHost()` also returned true for a browser tab opened on `localhost` (`IS_WEB && ON_LOCALHOST`). The host phone's own Chrome tab (default name "Android phone") therefore claimed host next to the Glide app (GOGO). Fix: `amHost()` = `hostRunning && isLocalAddr(room.url)` only, i.e. only the PC/Android **app** that runs the server. A browser is never host. Test added to `tools/test-host-detect.js` (opens the page on 127.0.0.1).
  * Lesson for future AIs: only ONE device per server may send `host:true`. Do not add other "I am on the host machine" shortcuts.
* **v34**
  * *Host was not recognised* (owner: the page opened at the host app's address showed no HOST; "when run from the app it must recognise the host"). Old rule: a visitor only knew the host if `peer.home === room.code`, i.e. only when the visitor had entered the host's **home room**. In a one-time-code room (create/join, QR) or when "always ready" was off, nobody was marked host. Also `iAmHost` was `room.standby`, which is true for ANY device waiting in its own home room (a plain browser visitor would have called itself host).
  * New rule: **the host says so itself.** `amHost()` in app.js = `hostRunning && isLocalAddr(room.url)`, i.e. this device is an app running the server it is connected to (v35: the earlier extra rule for browser tabs on localhost was wrong and was removed). It is sent in `hello` as `host:true`; the receiver keeps `p.isHost`. The old home-code match is kept as a fallback for peers on older versions. `isHostPeer(p)` (app.js) is the single test; linkfx.js uses `p.isHost || home-match` and `iAmHost = amHost()`.
  * The connected-devices list (`renderLivePeers`) now writes "(host)" after the host's name. This works in the apps too (linkfx animation is still web-only, `ONLY_WEB`).
  * Protocol change: `hello` has a new optional field `host` (boolean). Old clients ignore it. No server change (Node and Java untouched, invariant 1 still holds).
  * `tools/test-host-detect.js` added; `tools/test-fx.js host` now sets `hostRunning`/`room.url` instead of `room.standby`.
* **v33**
  * *Sending failed on old Android browsers* (owner's screenshot: every row `Failed · to <device> · files.get(...).slice(...).arrayBuffer is not a function`, both to the host phone and to a Windows PC). Cause: `platform.js` `api.readChunk` called `Blob.arrayBuffer()`, which only exists from Chrome 76; the owner's browser is older, so the **first chunk read threw**, `sendPass` caught it and marked every device `failed`. This was NOT a network / host-discovery problem: the devices were found and connected (their names are in the rows); the failure is local, before any byte is sent. Fix: `blobToBuffer(blob)` helper (uses `blob.arrayBuffer` if present, else `FileReader.readAsArrayBuffer`) and `readChunk` rejects with a readable error if the File is gone from the `files` map.
  * Added `tools/check-compat.js` (greps `renderer/*.js` for APIs missing in Chrome ~70). Passes at v33. Version label v33.
  * Receiving was not affected: it uses `dc.binaryType = 'arraybuffer'` and `new File(parts, name)`.
* **v32**
  * *Layout bug fixed* (owner's screenshot: page wider than the phone, cards cut at the left, progress bars and "Share… / Show in folder" sticking out). Cause: `.t` (transfer row, `display:grid`) had an implicit `auto` column and `.t-top`/`.t-meta` had no `min-width:0`, so a long file name made the row ~2x as wide as the screen. Fix: `.t { grid-template-columns: minmax(0,1fr); min-width:0 }`, `.t-top b { flex:1 1 auto; min-width:0 }`, size text `white-space:nowrap`, `.t-meta { flex-wrap:wrap }`, `.t-actions { flex:none }`, margins instead of flex `gap`; plus a safety net in the phone media query (`html.mobile, html.mobile body { max-width:100%; overflow-x:hidden }` and `min-width:0; max-width:100%` on `.app, main, .view, .card`).
  * *linkfx.js rewritten*: host drawn separately with profile picture, steady glow while connected, nicer transfer animation (glow gradients, breathing, trailing dots, green/red end ring), every shape is a `<path>`.
  * logo.js sets `window.GlideLogoData`. Version label v32. Added `AI-GUIDE.md` and `tools/`.
* **v31** `sendMany` rewritten: a device that taps Accept gets the file at once; nobody waits for the others (see 4.5). Toast text changed.
* **v30** link animation reworked (light style, per-device), `pid` added to the two `setTransfer` calls in app.js, CSS fallbacks for old browsers, default browser names ("Android phone", ...).
* **v29** first link animation. **v28** custom logo.

---

## 11. Tests and what is NOT verified

Dev tests (Playwright + Chromium, in `tools/`; they need a static server for `renderer/`, e.g. `cd renderer && python3 -m http.server 8123`, and `NODE_PATH` pointing to a folder that contains `playwright`):

| Script | What it checks |
|---|---|
| `tools/test-transfer-overflow.js` | phone viewport, long file name + done/receiving rows: widths of `.t`, `.t-top`, `.t-meta` must be <= `.t`; `innerWidth` must stay 360 (it grew to 724 before the fix) |
| `tools/test-fx.js idle\|xfer\|host` | draws the animation with fake peers: connected glow + host panel with picture, two simultaneous transfers (only the two involved devices animate), "this device is the host"; writes `/tmp/fx-<scenario>.png` |
| `tools/test-host-detect.js` | (12 checks incl. auto-accept, single host, options card visibility) needs the same static server; opens the page as `glide.test` (host-resolver-rules) because a page on `localhost` counts as "on the host itself". Checks: host found in a one-time-code room, fallback by home code, `amHost()` true/false, a browser tab on localhost is not host, "(host)" in the list |
| `tools/mdns-test/run.sh` | compiles `GlideMdns.java` against Android stubs, 8 logic checks + a real multicast round trip (needs `java -m jdk.compiler/...`, no Node) |
| `tools/check-compat.js` | no Node/Playwright needed: `node tools/check-compat.js`. Fails on APIs older browsers lack (list inside the file) |
| `tools/test-fx-8-devices.js` | 320 px width, 8 devices, device name `<img onerror>` must stay text, reduced motion -> animation `none`, no horizontal scroll |

The tests fake peers by filling `room.peers` and calling `setTransfer`; they do not open real WebRTC sessions.

**Verified in v32:** the three tests above pass; `node --check` passes for `renderer/*.js`, `tools/*.js`; every `max()/min()/env()/dvh` declaration in styles.css has a plain fallback before it.

**Verified in v44:** see the v44 entry (Java mDNS class compiled and tested on the build machine; nothing on a real phone).

**Verified in v43:** only `check-compat.js`.

**Verified in v42:** only `check-compat.js` and `node --check` (code is v40 again).

**Verified in v40:** only `check-compat.js` and `node --check` (see the v40 entry). Nothing else was re-run.

**Verified in v38:** `test-host-detect.js` (12 checks), `test-fx.js idle|xfer|host`, `test-fx-8-devices.js`, `test-transfer-overflow.js` pass; `check-compat.js` OK. Still NOT verified: the real whois round trip and anything on a real phone.

**Verified in v37:** `test-host-detect.js` (10 checks), `test-fx.js idle|xfer|host`, `test-fx-8-devices.js`, `test-transfer-overflow.js` pass; the options card was looked at in a phone-size screenshot. The real `whois` round trip (announce -> probeInfo -> room.hostHome) was NOT run end to end; the tests set `room.hostHome` by hand.

**Verified in v36:** `test-fx.js idle|xfer|host`, `test-host-detect.js`, `test-fx-8-devices.js` pass; screenshots `/tmp/fx-idle.png` and `/tmp/fx-xfer.png` were looked at (bloom follows the monitor/phone shape, steady when connected, ring + running light unchanged when sending).

**Verified in v35:** `tools/test-host-detect.js` (5 checks), `test-fx.js idle|host`, `test-fx-8-devices.js`, `test-transfer-overflow.js` pass; `check-compat.js` OK; `node --check` on all JS. These use fake peers, not real WebRTC.

**Verified in v33:** `node --check` passes for every `renderer/*.js` and `tools/*.js`; `node tools/check-compat.js` prints `compat OK`.

**NOT verified (be honest about this):**
* v34 host flag was tested with fake peers only. Not run with a real phone/PC pair. `amHost()` relies on `hostRunning` (set by `api.serverInfo()`/`initHostBox`) and on the app connecting to its own server at `ws://127.0.0.1:PORT` or `localhost`; if the app ever connects to its own LAN IP instead, `isLocalAddr` is false and the flag is not sent.
* The v33 `blobToBuffer` fallback was syntax-checked and reasoned through, but not run in a real old Android browser (none in the sandbox). If sending still fails, ask the owner for the new error text from the Transfers row.
* The Java files were never compiled by anyone so far (no `javac`/Android SDK in the sandbox).
* APK and EXE were not built or run.
* A real multi-device transfer (accept/decline/ignore mix) was not run. The v31 logic was reasoned through and syntax-checked, not exercised end to end.
* The real old Android browser was not available. The Chromium tests only change the user-agent string, which does not change the rendering engine, so they prove the layout logic, not old-engine behaviour.
* `LOGO_KEY` flow on a hosted site, pinch on a real phone, very large photos.

---

## 12. Known issues and ideas (not done)

* Flex `gap` is still used in older CSS rules (see 8).
* Late acceptors wait for the current pass to finish (by design, see 4.5). A smarter scheme would let them join mid-file and fetch the missing head afterwards.
* The animation is web-page only (`ONLY_WEB`); set it to `false` to show it in the apps too (then re-test on Android WebView).
* If the host has no logo, the host node shows a server icon; the *name* shown for the host is its device name from `hello`.
* (fixed in v34) A host with "always ready" off or a one-time-code room used to show no HOST panel; now the host flags itself in `hello`.

---

## 12b. Reading a "Failed" row (quick diagnosis, so you do not have to re-read the code)

The red text in a Transfers row is `setTransfer({error})`. Where it comes from:

| Text | Meaning / where |
|---|---|
| `... is not a function` / `undefined` | a JS API missing in the old browser. Look in platform.js `readChunk`/`rtc*` first, then run `tools/check-compat.js` |
| `closed` | the data channel closed during sending (other device left, or network dropped) -> `sendPass` |
| `File is no longer available...` | the picked File was dropped from `files` in platform.js (`readClose` deletes it after sending): choose it again |
| row stays `waiting`, toast about no answer | receiver did not tap Accept within 60 s (`sendMany`) |
| devices not found / no names in rows | connection problem, not sending: check `/healthz`, the host IP:8080, `whois` (3.1), relay (4.3) |

## 13. Invariants: do not break

1. Node `signaling.js` and Java `GlideHostPlugin.java` must implement the same protocol and the same `/logo` rules.
2. `setTransfer` calls for online transfers must carry `pid`.
3. Only a device that accepted receives file bytes. Never send chunks before `accept`.
4. Only the host device (or someone with `LOGO_KEY`) may change the logo; uploads are PNG-only, <= 600 KB; static files must stay inside `staticDir`.
5. No inline scripts (CSP). No `localStorage` without try/catch.
6. Idle animation = no motion; only devices in an active transfer animate; connected devices glow steadily.
7. Keep the old-browser rules in section 8 and run `node tools/check-compat.js` before delivering.
8. Every release (also see section 0 rule 3): bump the version label (`index.html` `<small class="ver">`), add a change-log entry here, update `README.md`, rebuild the zip.

9. Every change updates this guide (section 0 rule 3). A guide that no longer matches the code defeats its purpose.

---

## 14. Code index (generated by `node tools/make-index.js`, v44; line numbers drift, re-run after edits)

Names of top-level functions and button handlers (`#id` = `$('#id').onclick/onchange = ...`). Jump with `grep -n "name" renderer/app.js`.

```
### renderer/app.js (1149 lines)
2: $
21: esc
22: fmt
29: colorFor
34: uuid
36: copyText
48: toast
55: load
56: store
62: showView
68: addFiles
74: renderStaged
88: #choose
124: renderPeers
134: sendNearby
146: autoAccept
147: askIncoming
155: renderModal
166: #m-yes
167: #m-no
168: answer
177: fmtSpeed
178: fmtMbps
179: fmtEta
186: sample
194: setTransfer
229: scheduleRender
234: renderTransfers
266: makeCode
274: makeHomeCode
282: cleanCode
283: dash
287: getHome
292: standbyOn
293: getSaved
294: putSaved
295: saveDevice
302: renderSaved
313: paintHome
325: setRoomStatus
336: hostIdOn
339: hostPeer
348: isHostPeer
361: renderLivePeers
370: refreshRoomStatus
380: dropPeer
392: closeRoom
409: applyNotif
416: #notif-on
418: ensureStandby
426: probeInfo
438: probeHost
442: keyOf
444: looksLikeName
451: resolveAlias
465: applyServerField
477: autoFind
503: normalizeWs
515: isLocalAddr
518: amHost
521: defaultServer
531: shareUrl
555: paintLanBanner
579: refreshWebLan
594: #server
601: #code-in
602: #code-custom
603: #home-code
604: #home-save
614: #home-on
620: #create
628: #join
637: #cancel
638: #disconnect
639: #copy
640: #copy-link
641: sendStagedOnline
656: #send-online
658: #send-top
673: makeRelayChannel
691: startRoom
890: onPeerMessage
932: sleep
933: sendMany
980: sendPass
1019: initHostBox
### renderer/platform.js (269 lines)
104: pickWeb
### renderer/linkfx.js (255 lines)
### renderer/logo.js (253 lines)
```

---

# v45 work log (read this instead of re-reading the code for v45 features)

Everything below was written WITHOUT a real phone, Java compiler or Android SDK. Only `node --check` was run on the JS files. Treat all of it as untested. Java files that were added/edited and never compiled: `GlideNfcService.java`, `GlideHostPlugin.java` (method `nfcSet`), `GlideSaverPlugin.java` (method `abort`).

## What v45 added (all in `renderer/app.js` unless noted)
1. **Swarm sharing** (Options card, `#opt-swarm`, key `glide.swarm`, off by default). Block "swarm sharing" before `initHostBox`. One device sends a file to 2+ devices that all support it (`p.sw` from `hello`); file cut in 64 KB pieces (`SW_CS`), NO size limit (v45b): a device requests only pieces `next .. next+SW_AHEAD` (64 MB), writes them to disk IN ORDER with `api.rtcWrite` (`swDrain`) and forgets pieces older than `SW_KEEP` (32 MB) behind `next`; forgotten pieces answer `swno`. A plain browser receiver still buffers the whole file (`rtcWrite` on web only appends to memory). Over the existing room data channels (mesh, works through relay too). Messages: `swoffer, swaccept, swdecline, swcancel, swhave {add|all}, swreq {i}, swno {i}`; a piece = JSON `sc {sid,i}` then ONE binary message right after it (receiver keeps `p.swNext`). Functions: `swarmSend` (sender, keeps `s.seed`), `swMsg` (all swarm messages), `swServe`, `swPick` (random missing piece), `swPump` (max `SW_PIPE`=16 requests per peer since v46, counted by `swOut`), `swTick`, `swGot`, `swFinish` (writes pieces in order via `api.rtcOpen/rtcWrite/rtcClose`), `swAbort`. No piece hashes (`crypto.subtle` does not exist on plain http://192.168.x.x). The last pieces are kept 10 min after finishing, to keep sharing. `swhave` also carries `src {deviceId: count}` (who gave me these pieces); `swMark/swFlow` in app.js store the last time two devices exchanged a piece and `renderer/linkfx.js` draws a teal animated line between neighbouring devices from it (`box._seg`). linkfx runs only on the web page (`ONLY_WEB`).
   *How to SEE that swarm works*: the Transfers row shows `Swarm: <device> NN%, <device> NN%` (who delivered the pieces). If a phone shows more than one source, swarm works. Rows of a normal transfer show no `Swarm` text. The sender row also says `Swarm`.
2. **Cancel button** in Transfers (`cancelTransfer`, `cancelHooks`, `outJobs`). Only online transfers have a hook (Nearby UDP/HTTP has none, no button). Messages: `cancel {id}`, `swcancel {sid}`. `setTransfer` ignores any update after status `cancelled`. Half-received file deleted by `api.rtcAbort` (desktop `rtc-abort` in main.js + preload.js, web = drop buffer, Android = `GlideSaver.abort`). The list is rebuilt many times per second, so the click is handled on pointerdown+pointerup of `#tlist` (plain click is lost).
3. **NFC tap-to-connect** (Android, Host card, `#hc-nfc`, key `glide.nfc`): `GlideNfcService` = NFC Type 4 tag emulation (HCE, AID D2760000850101) serving one NDEF URI `http://<ip>:8080/?auto=1`; another phone touching it opens the browser, no app needed. JS calls `api.setNfc(on,url)` -> `GlideHost.nfcSet`. Manifest/service/xml are written by `mobile/scripts/android.js`. Works only with screen on; some makers block HCE.
3b. **Manual Accept reliability (v45b)**: user reports that with "Accept all files automatically" ON everything works, with a manual Accept it does not. Changes: the reply uses the channel as it is at the moment of tapping (`const dc = p.dc` inside `cb`; a captured old channel may be closed/replaced), offers of a device that left are removed from `state.incoming` (`dropPeer`), and the sender now waits 5 min (not 60 s) for Accept. Root cause is NOT confirmed.
4. **Receiver error handling**: `answer()` and the `offer` handler now catch errors. Before, if `api.rtcOpen` threw (no storage permission, old browser) the modal closed but no accept/decline was sent, so the sender showed "Waiting for reply" for ever. Now the receiver sends `decline` and shows a toast with the reason.
5. **Per-device sending with confirmation window** (fix for "second phone never gets the file"): `sendMany` now starts one independent `sendPass(file,[job])` per device the moment it accepts (before: one shared pass, others waited). Receivers send `ack {id,n}` every 512 KB (`hello` has `ack:true`, sender checks `p.ack`); the sender never has more than `ACK_WIN` (2 MB) unconfirmed per device and fails a device after 60 s without progress (`The other device stopped receiving`).
6. `MAX_PEERS` in `server/signaling.js` is now 20 (env `MAX_PEERS`). The Android host (`GlideHostPlugin.java`) still has its own `MAX_PEERS = 8`: NOT changed, change it too if more than 8 devices must join a phone host.

## Known problem and the analysis (user report, with screenshots)
Symptom: PC sends to 2 devices ("You" -> "My phone" (HOST, the phone that runs the server) and "Android phone"). One shows `Sending 3%` and stalls, the other `Waiting for reply`; if one device is switched off/unticked, the other one goes.
Analysis of `GlideHostPlugin.java`: in relay mode ALL data from one device travels over its single WebSocket to the host phone; the host reads it in ONE thread (`readFrame` loop) and `relayBinary` does a BLOCKING `sendFrame(target, ...)`. If one target is slow or paused (background WebView, no one tapped Accept, old browser), that thread blocks, so data for the other targets from the same sender is stuck behind it (head-of-line blocking). Items 4 and 5 above are the fix on the JS side: confirmation window keeps the blocking write small, and errors are no longer silent. The Java relay was NOT changed; if the problem remains, the next step is a per-client outgoing queue with its own writer thread in `GlideHostPlugin.sendFrame`/`relayBinary` (bounded, drop the client when full).
Not yet verified: whether the stall really comes from the relay, or from the phone's saving path (`saver.write` takes base64 through the Capacitor bridge, slow on old phones).

## Rules for the next AI
* Do not remove `swMsg(p, m)` at the top of the string branch of `onPeerMessage` or the `p.swNext` branch for binary data.
* A swarm sender must not call `api.readClose(file.path)` while a swarm runs (the swarm closes it itself in `swarmSend`'s tick).
* If you change message names, update this section and the README v45 note.
* Say clearly in your answer what you could not test.


---

# v46 work log (swarm, round 2; untested on real phones, only `node --check` run)

Why: user's test with PC -> "My phone" + "Android phone": swarm speed looked the same as the normal speed, "Android phone" stuck at 5% / 0 KB/s (sender had sent it only 12 MB, the rest came from the other phone).

1. **Swarm speed meter** (`swStat`, `swCount('up'|'down', q, bytes, fromSeed)`, `swMeterTick`). `swCount` is called in `swServe` (up) and `swGot` (down; `s.sender` = the device that sent the offer). UI: `#swm` box in the Transfers view, `#sw-speed` pill. Shows if pieces really travel device-to-device (red verdict when it is 0%). Stats reset after 20 s without swarm traffic.
2. The normal pill (`setInterval` near `setTransfer`) skips transfers whose `via` starts with `Swarm`.
3. `s.per` counters removed (`per: new Map()` is still created but unused). Requests in flight per device = `swOut(s, pid)` from `s.inflight`. `swGot` always frees its `inflight` slot (also for late/duplicate pieces). `SW_PIPE = 16`, `SW_TIMEOUT = 6000`.
4. ETA only when speed > 20 KB/s.

Not confirmed: the real cause of the Android stall (counter drift is the best guess; background/screen-off of the WebView is the other). Next step if it still stalls: read the Android phone's Swarm speed box (down lines per device) and the `sender` vs device-to-device numbers.

## v47 (was called v46b / v46c while it was built)
* `#speed` and `#sw-speed` pills were removed. `#topspd` (top, sticky) is drawn by the `setInterval` after `setTransfer`: `spd.orig.now` (normal transfers, set in the old meter interval), `spd.sw.now` (set in `swMeterTick`), `spd.all` = sum. Max/min/total reset after 20 s of silence.
* `linkfx.js`: swarm segments are now arcs on the right (`bulge`), states `off` (hidden, swarm option off or one device) / `idle` (dashed) / `out in` (lit). The arc is lit from `swFlow` (`swMark`).
* Top bar meaning (v47): Original = normal transfers + swarm pieces straight from the sender (receiver: `swStat.down` with `e.seed`; sender: its own `swStat.up`). Swarm = device-to-device (receiver: `down` without `seed`; sender: ESTIMATE = receivers' reported intake `swStat.repRate` (from `swhave add` counted in the sender branch of `swMsg`) minus own upload). Total = Original + Swarm. Sender-side swarm number is an estimate (reports come in 250 ms batches).

Version numbering from now on: every new zip gets the next number (v47 is this one, the next is v48, then v49 ...). Name the file `glide-app-vNN.zip` and add a `## vNN` section to README.md and AI-GUIDE.md.

# v48 work log
* `showView('transfers')` removed from `sendStagedOnline` (user wants to stay on the Online page).
* Busy handling: `busyRoom` (room live/connecting/waiting, set in `setRoomStatus`) + `busyXfer` (a transfer is active, set in the 700 ms meter interval) -> `updateBusy()` -> `api.setBusy(on)`. After the transfer ends `applyNotif()` restores the user's notification option.
* platform.js `setBusy`: `saver.keepAwake` (FLAG_KEEP_SCREEN_ON), `host.keepBusy` (Android: `GlideService.hold` = PARTIAL_WAKE_LOCK + WifiLock FULL_HIGH_PERF, starts the foreground service), `webKeep` (browser: wake lock + silent audio + Web Lock).
* android.js: MainActivity overrides `onPause/onStop` and calls `WebView.onResume()/resumeTimers()` while `GlideService.busy`. `capacitor.config.json`: `android.useLegacyBridge: true` (Capacitor docs: fixes plugin results delayed in the background). If the app gets slower for big files, try removing it first.
* Untested: all of it (no phone, no Android SDK here). Java files were only checked for balanced braces.

# v49 work log
* `drained(dc)` (after `sleep`) replaces the 5 ms `sleep` polling in `sendPass` and `swServe`; the ack wait in `sendPass` uses `j.wake`, set by the `ack` handler. Reason: background pages get timers about once a second (and about once a minute after 5 min of "intensive throttling"), which made a screen-off transfer crawl.
* `GlideHostPlugin.bgStatus / bgOpen {kind: battery|autostart|app}` -> `api.bgStatus / api.bgOpen` (platform.js) -> Options row `#bg-row` (`paintBg`) and `bgAsk()` (once, key `glide.bgasked`, called from `updateBusy`).
* `MainActivity` (template in `mobile/scripts/android.js`): `setRendererPriorityPolicy(RENDERER_PRIORITY_IMPORTANT, false)` in onCreate.
* Notification small icon = `R.drawable.ic_stat_glide` (created in `installIcon()`); if the Gradle build says it cannot find `R`, the class is in package `com.glide.share`, so `R` must be that app's R.
* Untested on a phone; Java only checked for balanced braces. If the transfer still stops in the background on Xiaomi, the next idea is a native (Java) sender that does not need the WebView at all.
