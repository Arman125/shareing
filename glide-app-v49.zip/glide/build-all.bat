@echo off
title Glide - build EXE + APK
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build-apk.ps1" -Only all
echo.
pause
