@echo off
title Glide - build APK
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build-apk.ps1" -Only apk
echo.
pause
