# Glide: build the Windows app (EXE) and the Android app (APK) on Windows.
#   build-all.bat -> both      build-exe.bat -> only EXE      build-apk.bat -> only APK
# Results are collected in the "release" folder. Missing JDK 21 / Android SDK are downloaded automatically
# (one time, into %LOCALAPPDATA%\Glide\tools).
param([ValidateSet('all', 'exe', 'apk')][string]$Only = 'all')

$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

function Say($m) { Write-Host ""; Write-Host "== $m" -ForegroundColor Cyan }
function Die($m) { throw $m }

# ---- where is the project? ----
$root = $PSScriptRoot
if (-not (Test-Path (Join-Path $root 'mobile\capacitor.config.json'))) {
  Write-Host "ERROR: put this script in the glide folder (the one that contains 'mobile' and 'package.json')." -ForegroundColor Red
  exit 1
}
$mobile = Join-Path $root 'mobile'
$release = Join-Path $root 'release'
New-Item -ItemType Directory -Force $release | Out-Null
$tools = Join-Path $env:LOCALAPPDATA 'Glide\tools'
New-Item -ItemType Directory -Force $tools | Out-Null

if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
  Write-Host 'ERROR: Node.js is not installed. Install the LTS version from https://nodejs.org and run this again.' -ForegroundColor Red
  exit 1
}

function Get-JavaMajor($jh) {
  if (-not $jh) { return 0 }
  $exe = Join-Path $jh 'bin\java.exe'
  if (-not (Test-Path $exe)) { return 0 }
  $o = cmd /c "`"$exe`" -version 2>&1" | Out-String
  if ($o -match 'version "(\d+)') { return [int]$Matches[1] }
  return 0
}

function Download-Zip($url, $dest) {
  Write-Host "Downloading $url"
  Invoke-WebRequest $url -OutFile $dest -UseBasicParsing -ErrorAction Stop
}

# =====================================================================
#  EXE (Windows app)
# =====================================================================
function Build-Exe {
  Say 'Building the Windows app (EXE)'
  Set-Location $root
  # no code-signing: avoids the "cannot create symbolic link" error on normal Windows accounts
  $env:CSC_IDENTITY_AUTO_DISCOVERY = 'false'
  npm install
  if ($LASTEXITCODE -ne 0) { Die 'npm install failed (root folder).' }
  npm run dist
  if ($LASTEXITCODE -ne 0) { Die 'npm run dist failed. Scroll up and read the first error.' }

  $dist = Join-Path $root 'dist'
  $setup = Get-ChildItem $dist -File -Filter '*Setup*.exe' -ErrorAction SilentlyContinue | Select-Object -First 1
  $portable = Get-ChildItem $dist -File -Filter '*.exe' -ErrorAction SilentlyContinue | Where-Object { $_.Name -notmatch 'Setup|Uninstall' } | Select-Object -First 1
  if (-not $setup -and -not $portable) { Die 'Build finished but no .exe was found in the dist folder.' }
  if ($setup) { Copy-Item $setup.FullName (Join-Path $release 'Glide-Setup.exe') -Force }
  if ($portable) { Copy-Item $portable.FullName (Join-Path $release 'Glide-Portable.exe') -Force }
  Write-Host 'EXE files copied to the release folder.' -ForegroundColor Green
}

# =====================================================================
#  APK (Android app)
# =====================================================================
function Build-Apk {
  # ---- JDK 21 (Android builds need exactly this; newer Java such as 25 breaks Gradle) ----
  Say 'Checking Java 21'
  $cands = @($env:JAVA_HOME,
    "$env:ProgramFiles\Android\Android Studio\jbr",
    "${env:ProgramFiles(x86)}\Android\Android Studio\jbr",
    "$env:LOCALAPPDATA\Programs\Android Studio\jbr",
    (Join-Path $tools 'jdk21'))
  if (Test-Path "$env:ProgramFiles\Eclipse Adoptium") {
    $cands += Get-ChildItem "$env:ProgramFiles\Eclipse Adoptium" -Directory -Filter 'jdk-21*' | ForEach-Object { $_.FullName }
  }
  $jdk = $null
  foreach ($c in $cands) { if ($c -and (Get-JavaMajor $c) -eq 21) { $jdk = $c; break } }

  if (-not $jdk) {
    Say 'Downloading JDK 21 (about 200 MB, one time)'
    $zip = Join-Path $tools 'jdk21.zip'
    $tmp = Join-Path $tools 'jdk21-tmp'
    $dest = Join-Path $tools 'jdk21'
    try {
      Download-Zip 'https://api.adoptium.net/v3/binary/latest/21/ga/windows/x64/jdk/hotspot/normal/eclipse' $zip
      if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
      Write-Host 'Unpacking...'
      Expand-Archive $zip -DestinationPath $tmp -Force
      $inner = Get-ChildItem $tmp -Directory | Select-Object -First 1
      if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }
      Move-Item $inner.FullName $dest
      Remove-Item $tmp -Recurse -Force
      Remove-Item $zip -Force
    } catch { Die "Could not download JDK 21: $($_.Exception.Message). Install Temurin 21 from https://adoptium.net and run this again." }
    $jdk = $dest
    if ((Get-JavaMajor $jdk) -ne 21) { Die 'The downloaded JDK does not look like Java 21.' }
  }
  Write-Host "Using Java 21 at $jdk"
  $env:JAVA_HOME = $jdk

  # ---- Android SDK ----
  Say 'Checking Android SDK'
  $sdkCands = @($env:ANDROID_HOME, $env:ANDROID_SDK_ROOT, "$env:LOCALAPPDATA\Android\Sdk", (Join-Path $tools 'android-sdk'))
  $sdk = $null
  foreach ($c in $sdkCands) {
    if ($c -and (Test-Path (Join-Path $c 'platforms\android-35')) -and (Test-Path (Join-Path $c 'build-tools'))) { $sdk = $c; break }
  }

  if (-not $sdk) {
    Say 'Setting up Android SDK (about 1 GB, one time)'
    $sdk = Join-Path $tools 'android-sdk'
    $sm = Join-Path $sdk 'cmdline-tools\latest\bin\sdkmanager.bat'
    if (-not (Test-Path $sm)) {
      $zip = Join-Path $tools 'cmdline-tools.zip'
      $tmp = Join-Path $tools 'cmdline-tmp'
      try {
        Download-Zip 'https://dl.google.com/android/repository/commandlinetools-win-11076708_latest.zip' $zip
        if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
        Expand-Archive $zip -DestinationPath $tmp -Force
        New-Item -ItemType Directory -Force (Join-Path $sdk 'cmdline-tools') | Out-Null
        Move-Item (Join-Path $tmp 'cmdline-tools') (Join-Path $sdk 'cmdline-tools\latest')
        Remove-Item $tmp -Recurse -Force
        Remove-Item $zip -Force
      } catch { Die "Could not download the Android command-line tools: $($_.Exception.Message)" }
    }
    Write-Host 'Accepting Android licenses...'
    (1..80 | ForEach-Object { 'y' }) | & $sm "--sdk_root=$sdk" --licenses | Out-Null
    Write-Host 'Installing platform-tools, Android 35 platform and build-tools...'
    & $sm "--sdk_root=$sdk" 'platform-tools' 'platforms;android-35' 'build-tools;34.0.0' 'build-tools;35.0.0'
    if ($LASTEXITCODE -ne 0) { Die 'Android SDK install failed. Check your internet connection and run this again.' }
  }
  Write-Host "Using Android SDK at $sdk"
  $env:ANDROID_HOME = $sdk
  $env:ANDROID_SDK_ROOT = $sdk
  $env:Path = "$jdk\bin;$sdk\platform-tools;$env:Path"

  # ---- build ----
  Say 'Building the APK (first time takes 10-20 minutes, please wait)'
  Set-Location $mobile
  $androidDir = Join-Path $mobile 'android'
  if (Test-Path (Join-Path $androidDir 'gradlew.bat')) {
    # stop any old Gradle daemon that was started with the wrong Java
    Push-Location $androidDir
    & .\gradlew.bat --stop 2>&1 | Out-Null
    Pop-Location
  }
  if (-not (Test-Path (Join-Path $mobile 'node_modules'))) {
    npm install
    if ($LASTEXITCODE -ne 0) { Die 'npm install failed (mobile folder).' }
  }
  npm run apk
  if ($LASTEXITCODE -ne 0) { Die 'The APK build failed. Scroll up and read the first error.' }

  $apk = Join-Path $androidDir 'app\build\outputs\apk\debug\app-debug.apk'
  if (-not (Test-Path $apk)) { Die "Build finished but the APK was not found at $apk" }
  Copy-Item $apk (Join-Path $release 'Glide.apk') -Force
  Write-Host 'APK copied to the release folder.' -ForegroundColor Green

  # ---- install on the phone (if connected) ----
  $adb = Join-Path $sdk 'platform-tools\adb.exe'
  if (Test-Path $adb) {
    & $adb start-server 2>&1 | Out-Null
    $devs = & $adb devices | Select-Object -Skip 1 | Where-Object { $_ -match "`tdevice$" }
    if ($devs) {
      Say 'Installing on your phone'
      & $adb install -r (Join-Path $release 'Glide.apk')
      if ($LASTEXITCODE -eq 0) {
        & $adb shell monkey -p com.glide.share -c android.intent.category.LAUNCHER 1 2>&1 | Out-Null
        Write-Host 'Installed and opened on the phone.' -ForegroundColor Green
      } else {
        Write-Host 'Phone install failed. If it says INSTALL_FAILED_UPDATE_INCOMPATIBLE, uninstall the old Glide from the phone first.' -ForegroundColor Yellow
      }
    } else {
      Write-Host 'No phone connected: copy release\Glide.apk to the phone and open it to install.' -ForegroundColor Yellow
    }
  }
}

# =====================================================================
#  run the stages
# =====================================================================
$results = [ordered]@{}
if ($Only -eq 'all' -or $Only -eq 'exe') {
  try { Build-Exe; $results['EXE (Windows app)'] = 'OK' }
  catch { Write-Host "`nERROR: $($_.Exception.Message)" -ForegroundColor Red; $results['EXE (Windows app)'] = 'FAILED' }
}
if ($Only -eq 'all' -or $Only -eq 'apk') {
  try { Build-Apk; $results['APK (Android app)'] = 'OK' }
  catch { Write-Host "`nERROR: $($_.Exception.Message)" -ForegroundColor Red; $results['APK (Android app)'] = 'FAILED' }
}
Set-Location $root

Say 'Summary'
foreach ($k in $results.Keys) {
  $color = 'Green'
  if ($results[$k] -ne 'OK') { $color = 'Red' }
  Write-Host ("  {0,-20} {1}" -f $k, $results[$k]) -ForegroundColor $color
}
Write-Host ""
Write-Host "Files are in: $release"
Get-ChildItem $release -File -ErrorAction SilentlyContinue | ForEach-Object { Write-Host ("  {0}  ({1:N0} MB)" -f $_.Name, ($_.Length / 1MB)) }
Start-Process explorer.exe "`"$release`""
if ($results.Values -contains 'FAILED') { exit 1 }
