@echo off
title Glide - build EXE
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build-apk.ps1" -Only exe
echo.
pause
