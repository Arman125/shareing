@echo off
setlocal enabledelayedexpansion
title Glide - install APK on phone

rem Usage: double-click, or drag app-debug.apk onto this file, or: install-apk.bat path\to\app-debug.apk

rem ---- 1. find the APK ----
set "APK=%~1"
if not "%APK%"=="" goto have_apk
for %%P in (
  "%~dp0app-debug.apk"
  "%~dp0android\app\build\outputs\apk\debug\app-debug.apk"
  "%~dp0mobile\android\app\build\outputs\apk\debug\app-debug.apk"
  "%USERPROFILE%\Downloads\app-debug.apk"
) do (
  if exist %%P if "!APK!"=="" set "APK=%%~P"
)
:have_apk
if "%APK%"=="" (
  echo Could not find app-debug.apk.
  echo Put it next to this script, or drag it onto install-apk.bat.
  goto end
)
echo APK: %APK%

rem ---- 2. find adb ----
set "ADB="
where adb >nul 2>nul && set "ADB=adb"
if "%ADB%"=="" if exist "%ANDROID_HOME%\platform-tools\adb.exe" set "ADB=%ANDROID_HOME%\platform-tools\adb.exe"
if "%ADB%"=="" if exist "%ANDROID_SDK_ROOT%\platform-tools\adb.exe" set "ADB=%ANDROID_SDK_ROOT%\platform-tools\adb.exe"
if "%ADB%"=="" if exist "%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe" set "ADB=%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe"
if "%ADB%"=="" if exist "%~dp0platform-tools\adb.exe" set "ADB=%~dp0platform-tools\adb.exe"
if "%ADB%"=="" (
  echo.
  echo adb was not found. Install "Android SDK Platform-Tools" from
  echo https://developer.android.com/tools/releases/platform-tools
  echo unzip it, and put the "platform-tools" folder next to this script. Then run it again.
  goto end
)

rem ---- 3. check the phone ----
"%ADB%" start-server >nul 2>nul
set "FOUND="
set "UNAUTH="
for /f "skip=1 tokens=1,2" %%a in ('"%ADB%" devices') do (
  if "%%b"=="device" set "FOUND=1"
  if "%%b"=="unauthorized" set "UNAUTH=1"
)
if defined UNAUTH if not defined FOUND (
  echo.
  echo The phone is asking to allow USB debugging. Look at the phone screen,
  echo tick "Always allow" and press Allow, then run this script again.
  goto end
)
if not defined FOUND (
  echo.
  echo No phone found. Do this once:
  echo   1. Phone: Settings ^> About phone ^> tap "Build number" 7 times
  echo   2. Phone: Settings ^> System ^> Developer options ^> turn on "USB debugging"
  echo   3. Plug in the USB cable, choose "File transfer" mode, and allow the prompt
  echo Then run this script again.
  goto end
)

rem ---- 4. install and open ----
echo.
echo Installing...
"%ADB%" install -r "%APK%"
if errorlevel 1 (
  echo.
  echo Install failed. If the message says INSTALL_FAILED_UPDATE_INCOMPATIBLE,
  echo uninstall the old Glide from the phone first and run this again.
  goto end
)
echo.
echo Installed. Opening Glide on the phone...
"%ADB%" shell monkey -p com.glide.share -c android.intent.category.LAUNCHER 1 >nul 2>nul
echo Done.

:end
echo.
pause
endlocal
