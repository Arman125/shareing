package com.glide.share;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.net.wifi.WifiManager;
import android.util.Base64;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.BindException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Lets the phone host Glide sessions by itself, exactly like the PC app does: a tiny WebSocket
 * "signaling" server on port 8080 that only introduces two devices (files never pass through it),
 * plus the Glide web page, so a friend can also open http://PHONE-IP:8080 in a browser.
 * Same protocol as server/signaling.js: create / join / signal.
 */
@CapacitorPlugin(name = "GlideHost")
public class GlideHostPlugin extends Plugin {

    private static final int PORT = 8080;
    private static final long ROOM_TTL = 15 * 60 * 1000;
    private static final int MAX_PEERS = 8;
    private static final int MAX_MESSAGE = 1024 * 1024;

    private static class Client {
        Socket sock;
        OutputStream out;
        volatile String code;
        volatile int pid;
        volatile String home;
        volatile String hname;
        final Object wlock = new Object();
    }

    private static class Room {
        final List<Client> clients = new ArrayList<>();
        long created = System.currentTimeMillis();
        boolean fixed = false;
    }

    private static class Frame {
        int op;
        boolean fin;
        byte[] data;
    }

    private final ExecutorService pool = Executors.newCachedThreadPool();
    private final Map<String, Room> rooms = new HashMap<>();
    private final List<Client> clients = Collections.synchronizedList(new ArrayList<Client>());
    private ServerSocket server;
    private WifiManager.WifiLock wifiLock;
    private GlideMdns mdns; // v44: answers the name glide.local (experimental)
    private volatile boolean running = false;
    private volatile String error = "";

    /* ------------------------------------------------------------------ plugin methods */

    /** v45 (experimental): hand out `url` to phones that touch this one (NFC tag emulation). Empty url or on=false stops it. */
    @PluginMethod
    public void nfcSet(PluginCall call) {
        boolean on = Boolean.TRUE.equals(call.getBoolean("on", false));
        String url = call.getString("url", "");
        boolean ok = GlideNfcService.setUrl(on ? url : null);
        android.nfc.NfcAdapter a = android.nfc.NfcAdapter.getDefaultAdapter(getContext());
        JSObject r = new JSObject();
        r.put("supported", a != null);
        r.put("nfcOn", a != null && a.isEnabled());
        r.put("active", on && ok && a != null && a.isEnabled());
        call.resolve(r);
    }

    @PluginMethod
    public void hostStart(PluginCall call) {
        startServer();
        call.resolve(infoResult());
    }

    @PluginMethod
    public void hostStop(PluginCall call) {
        stopServer();
        call.resolve(infoResult());
    }

    /** The address of the Wi-Fi / hotspot this phone has joined (the hotspot phone itself). Empty when not on Wi-Fi. */
    @SuppressWarnings("deprecation")
    @PluginMethod
    public void gateway(PluginCall call) {
        String ip = "";
        try {
            WifiManager wm = (WifiManager) getContext().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            int g = wm == null ? 0 : wm.getDhcpInfo().gateway;
            if (g != 0) ip = (g & 0xff) + "." + ((g >> 8) & 0xff) + "." + ((g >> 16) & 0xff) + "." + ((g >> 24) & 0xff);
        } catch (Exception ignored) {
        }
        JSObject r = new JSObject();
        r.put("ip", ip);
        call.resolve(r);
    }

    /** Permanent notification + background service: keeps Glide ready while the screen is off. */
    @PluginMethod
    public void keepStart(PluginCall call) {
        try {
            if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(getContext(), Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7001);
            }
            Intent i = new Intent(getContext(), GlideService.class);
            i.putExtra("text", call.getString("text", "Ready to share files"));
            getContext().startForegroundService(i);
        } catch (Exception ignored) {
        }
        call.resolve();
    }

    /** A connection or transfer is active (on=true) or over (on=false): CPU + Wi-Fi locks, and the foreground service so Android does not stop the app with the screen off. */
    @PluginMethod
    public void keepBusy(PluginCall call) {
        final boolean on = Boolean.TRUE.equals(call.getBoolean("on", false));
        try {
            GlideService.hold(getContext(), on);
            if (on) {
                Intent i = new Intent(getContext(), GlideService.class);
                i.putExtra("text", "Sharing files…");
                getContext().startForegroundService(i);
            }
        } catch (Exception ignored) {
        }
        call.resolve();
    }

    /** v49: is Glide allowed to run in the background without Android's battery restrictions? */
    @PluginMethod
    public void bgStatus(PluginCall call) {
        JSObject r = new JSObject();
        boolean ignoring = false;
        try {
            PowerManager pm = (PowerManager) getContext().getSystemService(Context.POWER_SERVICE);
            ignoring = pm != null && pm.isIgnoringBatteryOptimizations(getContext().getPackageName());
        } catch (Exception ignored) {
        }
        r.put("ignoring", ignoring);
        r.put("maker", Build.MANUFACTURER == null ? "" : Build.MANUFACTURER.toLowerCase(Locale.ROOT));
        call.resolve(r);
    }

    /** v49: open the system screen where the user lets Glide run in the background. kind = battery | autostart (Xiaomi) | app */
    @PluginMethod
    public void bgOpen(PluginCall call) {
        final String kind = call.getString("kind", "battery");
        final Context c = getContext();
        try {
            Intent i;
            if ("battery".equals(kind)) {
                i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + c.getPackageName()));
            } else if ("autostart".equals(kind)) {
                i = new Intent();
                i.setComponent(new ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutostartManagementActivity"));
            } else {
                i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + c.getPackageName()));
            }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        } catch (Exception e) {
            try { // that screen does not exist on this phone: open the app's own settings page instead
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + c.getPackageName()));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                c.startActivity(i);
            } catch (Exception ignored) {
            }
        }
        call.resolve();
    }

    @PluginMethod
    public void keepStop(PluginCall call) {
        try {
            getContext().stopService(new Intent(getContext(), GlideService.class));
        } catch (Exception ignored) {
        }
        call.resolve();
    }

    /** A pop-up notification when someone wants to send a file while Glide is in the background. */
    @PluginMethod
    public void notifyIncoming(PluginCall call) {
        try {
            Context ctx = getContext();
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel("glide_incoming", "File requests", NotificationManager.IMPORTANCE_HIGH));
            Intent open = new Intent(ctx, MainActivity.class);
            open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pi = PendingIntent.getActivity(ctx, 1, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Notification n = new Notification.Builder(ctx, "glide_incoming")
                    .setContentTitle(call.getString("title", "Glide"))
                    .setContentText(call.getString("text", "Tap to accept"))
                    .setSmallIcon(R.drawable.ic_stat_glide)
                    .setColor(0xFF4F8CFF)
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .build();
            nm.notify(2, n);
        } catch (Exception ignored) {
        }
        call.resolve();
    }

    @PluginMethod
    public void hostInfo(PluginCall call) {
        call.resolve(infoResult());
    }

    @Override
    protected void handleOnDestroy() {
        stopServer();
        pool.shutdownNow();
        super.handleOnDestroy();
    }

    /* ------------------------------------------------------------------ server lifecycle */

    private synchronized void startServer() {
        if (running) return;
        try {
            ServerSocket ss = new ServerSocket();
            ss.setReuseAddress(true);
            ss.bind(new InetSocketAddress(PORT));
            server = ss;
            running = true;
            error = "";
            holdWifi(true);
            try {
                if (mdns == null) mdns = new GlideMdns(getContext());
                mdns.start();
            } catch (Exception ignored) {
            }
            pool.execute(() -> acceptLoop(ss));
        } catch (Exception e) {
            running = false;
            error = (e instanceof BindException) ? "Port " + PORT + " is already in use." : String.valueOf(e.getMessage());
        }
    }

    private synchronized void stopServer() {
        running = false;
        error = "";
        try { if (server != null) server.close(); } catch (Exception ignored) { }
        server = null;
        try { if (mdns != null) mdns.stop(); } catch (Exception ignored) { }
        holdWifi(false);
        synchronized (clients) {
            for (Client c : clients) {
                try { c.sock.close(); } catch (Exception ignored) { }
            }
            clients.clear();
        }
        synchronized (rooms) {
            rooms.clear();
        }
    }

    /** Keeps Wi-Fi awake so other devices can still reach this phone. */
    @SuppressWarnings("deprecation")
    private void holdWifi(boolean on) {
        try {
            if (on) {
                if (wifiLock == null) {
                    WifiManager wm = (WifiManager) getContext().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                    if (wm == null) return;
                    wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "glide-host");
                    wifiLock.setReferenceCounted(false);
                }
                if (!wifiLock.isHeld()) wifiLock.acquire();
            } else if (wifiLock != null && wifiLock.isHeld()) {
                wifiLock.release();
            }
        } catch (Exception ignored) {
        }
    }

    /** Mobile-data interfaces are useless for sharing on the same Wi-Fi, so they are left out. */
    private static boolean isMobileData(String n) {
        String l = n.toLowerCase(Locale.ROOT);
        return l.startsWith("rmnet") || l.startsWith("ccmni") || l.startsWith("pdp") || l.startsWith("ppp")
                || l.startsWith("v4-") || l.startsWith("tun") || l.startsWith("dummy");
    }

    /** True when something is really accepting connections on our port. */
    private boolean selfTest() {
        if (!running) return false;
        try (Socket t = new Socket()) {
            t.connect(new InetSocketAddress("127.0.0.1", PORT), 500);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Wi-Fi, hotspot (access point) and USB-tethering interface names. Mobile data is never listed. */
    private static boolean isLanName(String n) {
        String l = n.toLowerCase(Locale.ROOT);
        return l.startsWith("wlan") || l.startsWith("ap") || l.startsWith("swlan") || l.startsWith("softap")
                || l.startsWith("rndis") || l.startsWith("eth") || l.startsWith("p2p") || l.startsWith("bt-pan");
    }

    /** Wi-Fi / hotspot IPv4 addresses of this phone (mobile data excluded unless nothing else exists). */
    private static List<String> lanIps() {
        List<String> lan = new ArrayList<>();
        List<String> other = new ArrayList<>();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback() || isMobileData(ni.getName())) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address && !a.isLoopbackAddress() && !a.isLinkLocalAddress()) {
                        (isLanName(ni.getName()) ? lan : other).add(a.getHostAddress());
                    }
                }
            }
        } catch (Exception ignored) {
        }
        // only Wi-Fi / hotspot addresses when there are any; unknown interfaces (often mobile data) only as a last resort
        return lan.isEmpty() ? other : lan;
    }

    private JSObject infoResult() {
        JSArray urls = new JSArray();
        JSArray webUrls = new JSArray();
        for (String ip : lanIps()) {
            urls.put("ws://" + ip + ":" + PORT);
            webUrls.put("http://" + ip + ":" + PORT);
        }
        boolean listening = selfTest();
        JSObject r = new JSObject();
        r.put("running", running && listening);
        r.put("port", PORT);
        r.put("error", error.isEmpty() && running && !listening ? "The server did not start. Press Restart." : error);
        r.put("urls", urls);
        r.put("webUrls", webUrls);
        r.put("mdns", running && mdns != null && mdns.isActive() ? GlideMdns.HOST : "");
        return r;
    }

    private void acceptLoop(ServerSocket ss) {
        try {
            while (running) {
                final Socket s = ss.accept();
                pool.execute(() -> handle(s));
            }
        } catch (Exception ignored) {
        }
    }

    /* ------------------------------------------------------------------ connections */

    private void handle(Socket s) {
        Client c = null;
        try {
            s.setTcpNoDelay(true);
            s.setKeepAlive(true);
            s.setSoTimeout(15000); // the request line and headers must arrive quickly
            InputStream in = new BufferedInputStream(s.getInputStream(), 8192);
            OutputStream out = s.getOutputStream();

            String req = readLine(in);
            if (req == null) {
                s.close();
                return;
            }
            Map<String, String> h = new HashMap<>();
            String line;
            while ((line = readLine(in)) != null && !line.isEmpty()) {
                int i = line.indexOf(':');
                if (i > 0) h.put(line.substring(0, i).trim().toLowerCase(Locale.ROOT), line.substring(i + 1).trim());
            }
            String[] parts = req.split(" ");
            String method = parts.length > 0 ? parts[0] : "GET";
            String path = parts.length > 1 ? parts[1] : "/";

            String key = h.get("sec-websocket-key");
            String upgrade = h.get("upgrade");
            if (key == null || upgrade == null || !upgrade.equalsIgnoreCase("websocket")) {
                serveStatic(out, in, s, h, method, path);
                s.close();
                return;
            }

            String accept = Base64.encodeToString(
                    MessageDigest.getInstance("SHA-1").digest((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").getBytes(StandardCharsets.UTF_8)),
                    Base64.NO_WRAP);
            out.write(("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: " + accept + "\r\n\r\n")
                    .getBytes(StandardCharsets.US_ASCII));
            out.flush();
            s.setSoTimeout(0);

            c = new Client();
            c.sock = s;
            c.out = out;
            clients.add(c);

            ByteArrayOutputStream frag = null;
            int fragOp = 1;
            while (running) {
                Frame f = readFrame(in);
                if (f == null || f.op == 8) break;       // closed
                if (f.op == 9) {                          // ping -> pong
                    sendFrame(c, 10, f.data);
                    continue;
                }
                if (f.op == 10) continue;                 // pong
                if (f.op == 1 || f.op == 2) { frag = new ByteArrayOutputStream(); fragOp = f.op; }
                if (frag == null) continue;               // stray continuation
                frag.write(f.data);
                if (frag.size() > MAX_MESSAGE) break;
                if (f.fin) {
                    byte[] whole = frag.toByteArray();
                    frag = null;
                    if (fragOp == 2) relayBinary(c, whole); // file data in relay mode
                    else onMessage(c, new String(whole, StandardCharsets.UTF_8));
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) {
                clients.remove(c);
                onClose(c);
            }
            try { s.close(); } catch (Exception ignored) { }
        }
    }

    /* ------------------------------------------------------------------ signaling (same as server/signaling.js) */

    private static String norm(String c) {
        return c == null ? "" : c.toUpperCase(Locale.ROOT).replaceAll("[^A-Z0-9]", "");
    }

    private void reply(Client c, JSONObject o) {
        try {
            sendFrame(c, 1, o.toString().getBytes(StandardCharsets.UTF_8));
        } catch (Exception ignored) {
        }
    }

    private void replyType(Client c, String type, String message) {
        try {
            JSONObject o = new JSONObject();
            o.put("type", type);
            if (message != null) o.put("message", message);
            reply(c, o);
        } catch (Exception ignored) {
        }
    }

    private void onMessage(Client c, String text) {
        try {
            JSONObject m = new JSONObject(text);
            String type = m.optString("type", "");
            synchronized (rooms) {
                long now = System.currentTimeMillis();
                Iterator<Map.Entry<String, Room>> it = rooms.entrySet().iterator();
                while (it.hasNext()) {
                    Room old = it.next().getValue();
                    // only one-time codes nobody joined expire; a running session or a fixed code never does
                    if (!old.fixed && old.clients.size() < 2 && now - old.created > ROOM_TTL) it.remove();
                }

                if (type.equals("create") || type.equals("join") || type.equals("enter")) {
                    enter(c, type, norm(m.optString("code", "")));
                } else if (type.equals("announce")) {
                    c.home = norm(m.optString("code", ""));
                    c.hname = m.optString("name", "");
                } else if (type.equals("whois")) {
                    String home = "";
                    String hn = "";
                    synchronized (clients) {
                        for (Client x : clients) {
                            if (x.home != null && !x.home.isEmpty()) {
                                home = x.home;
                                hn = x.hname == null ? "" : x.hname;
                            }
                        }
                    }
                    JSONObject o = new JSONObject();
                    o.put("type", "whois");
                    o.put("home", home);
                    o.put("name", hn);
                    reply(c, o);
                } else if (type.equals("signal")) {
                    Room r = c.code == null ? null : rooms.get(c.code);
                    if (r == null) return;
                    int to = m.optInt("to", -1);
                    for (Client other : r.clients) {
                        if (other != c && other.pid == to) {
                            JSONObject o = new JSONObject();
                            o.put("type", "signal");
                            o.put("from", c.pid);
                            o.put("data", m.opt("data"));
                            reply(other, o);
                        }
                    }
                }
            }
        } catch (Exception ignored) {
        }
    }

    /** create = new one-time code, join = existing code, enter = join if it exists else open it (fixed codes). Caller holds the rooms lock. */
    private void enter(Client c, String type, String code) throws Exception {
        if (c.code != null) {
            replyType(c, "error", "Already in a session.");
            return;
        }
        if (code.length() < 1 || code.length() > 12) {
            replyType(c, "error", "Enter a code of 1 to 12 letters or numbers.");
            return;
        }
        Room r = rooms.get(code);
        if (type.equals("create") && r != null) {
            replyType(c, "error", "That code is taken. Try again.");
            return;
        }
        if (type.equals("join") && r == null) {
            replyType(c, "error", "Code not found. Check it and try again.");
            return;
        }
        if (r == null) {
            r = new Room();
            r.fixed = type.equals("enter");
            rooms.put(code, r);
        }
        if (r.clients.size() >= MAX_PEERS) {
            replyType(c, "error", "This code is full.");
            return;
        }
        int pid = 1;
        while (true) {
            boolean used = false;
            for (Client x : r.clients) if (x.pid == pid) used = true;
            if (!used) break;
            pid++;
        }
        List<Client> others = new ArrayList<>(r.clients);
        c.pid = pid;
        c.code = code;
        r.created = System.currentTimeMillis();
        r.clients.add(c);
        JSONArray ids = new JSONArray();
        for (Client x : others) ids.put(x.pid);
        JSONObject o = new JSONObject();
        o.put("type", "joined");
        o.put("id", pid);
        o.put("peers", ids);
        reply(c, o);
        for (Client x : others) {
            JSONObject p = new JSONObject();
            p.put("type", "peer-joined");
            p.put("id", pid);
            reply(x, p);
        }
    }

    /** Relay mode: first byte = target device id; it is replaced by the sender id and the frame is passed on. */
    private void relayBinary(Client c, byte[] data) {
        if (data.length < 1) return;
        Client target = null;
        synchronized (rooms) {
            Room r = c.code == null ? null : rooms.get(c.code);
            if (r == null) return;
            int to = data[0] & 0xff;
            for (Client x : r.clients) if (x != c && x.pid == to) target = x;
        }
        if (target == null) return;
        data[0] = (byte) c.pid;
        try {
            sendFrame(target, 2, data); // blocking write = natural back-pressure for a slow receiver
        } catch (Exception ignored) {
        }
    }

    private void onClose(Client c) {
        synchronized (rooms) {
            String code = c.code;
            Room r = code == null ? null : rooms.get(code);
            if (r == null) return;
            r.clients.remove(c);
            for (Client other : r.clients) {
                try {
                    JSONObject o = new JSONObject();
                    o.put("type", "peer-left");
                    o.put("id", c.pid);
                    reply(other, o);
                } catch (Exception ignored) {
                }
            }
            if (r.clients.isEmpty()) rooms.remove(code);
        }
    }

    /* ------------------------------------------------------------------ WebSocket framing (RFC 6455) */

    private static Frame readFrame(InputStream in) throws IOException {
        int b0 = in.read();
        if (b0 < 0) return null;
        int b1 = in.read();
        if (b1 < 0) return null;
        Frame f = new Frame();
        f.fin = (b0 & 0x80) != 0;
        f.op = b0 & 0x0f;
        boolean masked = (b1 & 0x80) != 0;
        long len = b1 & 0x7f;
        if (len == 126) {
            len = (readByte(in) << 8) | readByte(in);
        } else if (len == 127) {
            len = 0;
            for (int i = 0; i < 8; i++) len = (len << 8) | readByte(in);
        }
        if (len < 0 || len > MAX_MESSAGE) throw new IOException("frame too big");
        byte[] mask = new byte[4];
        if (masked) readFully(in, mask);
        byte[] data = new byte[(int) len];
        readFully(in, data);
        if (masked) {
            for (int i = 0; i < data.length; i++) data[i] ^= mask[i & 3];
        }
        f.data = data;
        return f;
    }

    private static int readByte(InputStream in) throws IOException {
        int b = in.read();
        if (b < 0) throw new EOFException();
        return b;
    }

    private static void readFully(InputStream in, byte[] buf) throws IOException {
        int off = 0;
        while (off < buf.length) {
            int n = in.read(buf, off, buf.length - off);
            if (n < 0) throw new EOFException();
            off += n;
        }
    }

    private static void sendFrame(Client c, int op, byte[] payload) throws IOException {
        synchronized (c.wlock) {
            ByteArrayOutputStream b = new ByteArrayOutputStream(payload.length + 10);
            b.write(0x80 | op);
            if (payload.length < 126) {
                b.write(payload.length);
            } else if (payload.length < 65536) {
                b.write(126);
                b.write((payload.length >> 8) & 0xff);
                b.write(payload.length & 0xff);
            } else {
                b.write(127);
                for (int i = 7; i >= 0; i--) b.write((int) (((long) payload.length >> (8 * i)) & 0xff));
            }
            b.write(payload);
            c.out.write(b.toByteArray());
            c.out.flush();
        }
    }

    /* ------------------------------------------------------------------ the Glide web page (from the app's own files) */

    private static String typeOf(String p) {
        String l = p.toLowerCase(Locale.ROOT);
        if (l.endsWith(".html")) return "text/html; charset=utf-8";
        if (l.endsWith(".js")) return "text/javascript; charset=utf-8";
        if (l.endsWith(".css")) return "text/css; charset=utf-8";
        if (l.endsWith(".svg")) return "image/svg+xml";
        if (l.endsWith(".png")) return "image/png";
        if (l.endsWith(".ico")) return "image/x-icon";
        if (l.endsWith(".json")) return "application/json";
        if (l.endsWith(".webmanifest")) return "application/manifest+json";
        return null;
    }

    private void httpReply(OutputStream out, int code, String text, String type, byte[] body, boolean head) throws IOException {
        String h = "HTTP/1.1 " + code + " " + text + "\r\nContent-Type: " + type + "\r\nContent-Length: " + body.length
                + "\r\nCache-Control: no-cache\r\nConnection: close\r\n\r\n";
        out.write(h.getBytes(StandardCharsets.US_ASCII));
        if (!head) out.write(body);
        out.flush();
    }

    private void serveStatic(OutputStream out, InputStream in, Socket sock, Map<String, String> h, String method, String rawPath) throws IOException {
        boolean head = method.equals("HEAD");
        String pathOnly = rawPath.indexOf('?') >= 0 ? rawPath.substring(0, rawPath.indexOf('?')) : rawPath;
        if (pathOnly.equals("/logo")) {
            serveLogo(out, in, sock, h, method);
            return;
        }
        if (!method.equals("GET") && !head) {
            httpReply(out, 405, "Method Not Allowed", "text/plain", new byte[0], true);
            return;
        }
        String p = rawPath;
        int q = p.indexOf('?');
        if (q >= 0) p = p.substring(0, q);
        try {
            p = URLDecoder.decode(p, "UTF-8");
        } catch (Exception e) {
            httpReply(out, 400, "Bad Request", "text/plain", new byte[0], true);
            return;
        }
        if (p.equals("/healthz")) {
            httpReply(out, 200, "OK", "text/plain", "ok".getBytes(StandardCharsets.UTF_8), head);
            return;
        }
        if (p.equals("/lan")) {
            // the page was opened as "localhost": tell it the address other phones must use
            StringBuilder sb = new StringBuilder("{\"port\":" + PORT + ",\"urls\":[");
            boolean first = true;
            for (String ip : lanIps()) {
                if (!first) sb.append(',');
                sb.append("\"http://").append(ip).append(':').append(PORT).append('"');
                first = false;
            }
            sb.append("]}");
            httpReply(out, 200, "OK", "application/json", sb.toString().getBytes(StandardCharsets.UTF_8), head);
            return;
        }
        if (p.equals("/ice")) {
            httpReply(out, 200, "OK", "application/json", "[]".getBytes(StandardCharsets.UTF_8), head);
            return;
        }
        if (p.isEmpty() || p.equals("/")) p = "/index.html";
        String type = typeOf(p);
        if (type == null || p.contains("..")) {
            httpReply(out, 404, "Not Found", "text/plain", "Not found".getBytes(StandardCharsets.UTF_8), head);
            return;
        }
        byte[] data;
        try (InputStream a = getContext().getAssets().open("public" + p)) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = a.read(buf)) > 0) bo.write(buf, 0, n);
            data = bo.toByteArray();
        } catch (IOException e) {
            httpReply(out, 404, "Not Found", "text/plain", "Not found".getBytes(StandardCharsets.UTF_8), head);
            return;
        }
        httpReply(out, 200, "OK", type, data, head);
    }

    /* ------------------------------------------------------------------ shared logo (same rules as server/signaling.js) */

    private static final int LOGO_MAX = 600 * 1024;

    private File logoFile() {
        return new File(getContext().getFilesDir(), "logo.png");
    }

    /** This phone itself (its app, or its own browser at the Wi-Fi address) may change the logo. */
    private static boolean isSelf(Socket sock) {
        try {
            InetAddress a = sock.getInetAddress();
            return a.isLoopbackAddress() || NetworkInterface.getByInetAddress(a) != null;
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean originOk(Map<String, String> h) {
        String o = h.get("origin");
        if (o == null || o.isEmpty() || o.equals("null")) return true;
        try {
            String host = new java.net.URI(o).getHost();
            String mine = h.get("host") == null ? "" : h.get("host").split(":")[0];
            return host != null && (host.equals(mine) || host.equals("localhost") || host.equals("127.0.0.1"));
        } catch (Exception e) {
            return false;
        }
    }

    private void logoReply(OutputStream out, int code, String text, String type, byte[] body, boolean head, boolean self) throws IOException {
        String hd = "HTTP/1.1 " + code + " " + text + "\r\nContent-Type: " + type + "\r\nContent-Length: " + (head && code == 204 ? 0 : body.length)
                + "\r\nAccess-Control-Allow-Origin: *\r\nAccess-Control-Allow-Headers: x-logo-key, content-type"
                + "\r\nAccess-Control-Expose-Headers: x-can-edit\r\nX-Can-Edit: " + (self ? "1" : "0")
                + "\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n";
        out.write(hd.getBytes(StandardCharsets.US_ASCII));
        if (!head) out.write(body);
        out.flush();
    }

    private void serveLogo(OutputStream out, InputStream in, Socket sock, Map<String, String> h, String method) throws IOException {
        boolean self = isSelf(sock);
        byte[] none = new byte[0];
        if (method.equals("OPTIONS")) {
            logoReply(out, 204, "No Content", "text/plain", none, true, self);
            return;
        }
        if (method.equals("GET") || method.equals("HEAD")) {
            boolean head = method.equals("HEAD");
            File f = logoFile();
            if (!f.exists() || f.length() == 0) {
                logoReply(out, 404, "Not Found", "text/plain", "none".getBytes(StandardCharsets.UTF_8), head, self);
                return;
            }
            byte[] data;
            try (InputStream fi = new java.io.FileInputStream(f)) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[16384];
                int n;
                while ((n = fi.read(buf)) > 0) bo.write(buf, 0, n);
                data = bo.toByteArray();
            }
            logoReply(out, 200, "OK", "image/png", data, head, self);
            return;
        }
        if (!method.equals("POST")) {
            logoReply(out, 405, "Method Not Allowed", "text/plain", none, true, self);
            return;
        }
        byte[] fail = null;
        int code = 200;
        if (!originOk(h)) { code = 403; fail = "{\"error\":\"origin\"}".getBytes(StandardCharsets.UTF_8); }
        else if (!self) { code = 403; fail = "{\"error\":\"host-only\"}".getBytes(StandardCharsets.UTF_8); }
        int len = 0;
        try { len = Integer.parseInt(h.get("content-length") == null ? "0" : h.get("content-length")); } catch (Exception ignored) { }
        if (fail == null && (len <= 0 || len > LOGO_MAX * 3 / 2 + 100)) { code = 413; fail = "{\"error\":\"too-big\"}".getBytes(StandardCharsets.UTF_8); }
        if (fail != null) {
            logoReply(out, code, "Forbidden", "application/json", fail, false, self);
            return;
        }
        byte[] body = new byte[len];
        readFully(in, body);
        String text = new String(body, StandardCharsets.UTF_8).trim();
        File f = logoFile();
        if (text.equals("reset")) {
            //noinspection ResultOfMethodCallIgnored
            f.delete();
            logoReply(out, 200, "OK", "application/json", "{\"ok\":true}".getBytes(StandardCharsets.UTF_8), false, self);
            return;
        }
        String prefix = "data:image/png;base64,";
        byte[] png = null;
        if (text.startsWith(prefix)) {
            try { png = Base64.decode(text.substring(prefix.length()), Base64.DEFAULT); } catch (Exception ignored) { }
        }
        if (png == null || png.length < 8 || png.length > LOGO_MAX || (png[0] & 0xff) != 0x89 || png[1] != 'P' || png[2] != 'N' || png[3] != 'G') {
            logoReply(out, 400, "Bad Request", "application/json", "{\"error\":\"bad-image\"}".getBytes(StandardCharsets.UTF_8), false, self);
            return;
        }
        try (java.io.FileOutputStream fo = new java.io.FileOutputStream(f)) {
            fo.write(png);
        } catch (Exception e) {
            logoReply(out, 500, "Error", "application/json", "{\"error\":\"save-failed\"}".getBytes(StandardCharsets.UTF_8), false, self);
            return;
        }
        logoReply(out, 200, "OK", "application/json", "{\"ok\":true}".getBytes(StandardCharsets.UTF_8), false, self);
    }

    /* ------------------------------------------------------------------ helpers */

    private static String readLine(InputStream in) throws IOException {
        StringBuilder sb = new StringBuilder();
        int c;
        while ((c = in.read()) != -1) {
            if (c == '\n') break;
            if (c != '\r') sb.append((char) c);
            if (sb.length() > 16384) throw new IOException("line too long");
        }
        if (c == -1 && sb.length() == 0) return null;
        return sb.toString();
    }
}
