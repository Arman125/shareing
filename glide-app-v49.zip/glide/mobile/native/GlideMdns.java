package com.glide.share;

import android.content.Context;
import android.net.wifi.WifiManager;

import java.io.ByteArrayOutputStream;
import java.net.DatagramPacket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.InterfaceAddress;
import java.net.MulticastSocket;
import java.net.NetworkInterface;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Locale;

/**
 * Tiny mDNS responder (v44, EXPERIMENTAL, never run on a phone by the author).
 * Answers "A" questions for the name glide.local with this phone's IPv4 address on the network the question came from,
 * so a PC / iPhone / Mac on the same Wi-Fi or hotspot can open http://glide.local:8080 instead of typing the IP.
 * Android browsers do not resolve .local names, so this does NOT help Android visitors.
 * Only normal multicast questions (sent from port 5353, which Windows and Apple resolvers do) are answered.
 * Started by GlideHostPlugin.startServer(), stopped by stopServer().
 */
public class GlideMdns {
    public static final String HOST = "glide.local";
    private static final int PORT = 5353;
    private static final String GROUP = "224.0.0.251";

    private final Context ctx;
    private volatile boolean running = false;
    private volatile boolean active = false;
    private MulticastSocket socket;
    private WifiManager.MulticastLock lock;

    public GlideMdns(Context ctx) {
        this.ctx = ctx.getApplicationContext();
    }

    /** True while the socket is bound and listening. */
    public boolean isActive() {
        return active;
    }

    @SuppressWarnings("deprecation")
    public synchronized void start() {
        if (running) return;
        running = true;
        try {
            WifiManager wm = (WifiManager) ctx.getSystemService(Context.WIFI_SERVICE);
            if (wm != null) {
                lock = wm.createMulticastLock("glide-mdns"); // without it Android drops multicast packets
                lock.setReferenceCounted(false);
                lock.acquire();
            }
        } catch (Exception ignored) {
        }
        Thread t = new Thread(this::loop, "glide-mdns");
        t.setDaemon(true);
        t.start();
    }

    public synchronized void stop() {
        running = false;
        active = false;
        try { if (socket != null) socket.close(); } catch (Exception ignored) { }
        socket = null;
        try { if (lock != null && lock.isHeld()) lock.release(); } catch (Exception ignored) { }
    }

    private void loop() {
        MulticastSocket s = null;
        try {
            s = new MulticastSocket(null);
            s.setReuseAddress(true);
            s.bind(new InetSocketAddress(PORT));
            s.setSoTimeout(3000);
            s.setTimeToLive(255);
            socket = s;
            active = true;
            byte[] buf = new byte[1500];
            long lastJoin = 0;
            while (running) {
                long now = System.currentTimeMillis();
                if (now - lastJoin > 3000) { joinAll(s); lastJoin = now; } // new interfaces (hotspot turned on later)
                DatagramPacket p = new DatagramPacket(buf, buf.length);
                try {
                    s.receive(p);
                } catch (SocketTimeoutException t) {
                    continue;
                }
                try {
                    handle(s, p);
                } catch (Exception ignored) {
                }
            }
        } catch (Exception ignored) {
        } finally {
            active = false;
            try { if (s != null) s.close(); } catch (Exception ignored) { }
        }
    }

    private static boolean usable(NetworkInterface ni) {
        try {
            if (!ni.isUp() || ni.isLoopback() || !ni.supportsMulticast()) return false;
        } catch (Exception e) {
            return false;
        }
        String l = ni.getName().toLowerCase(Locale.ROOT);
        return !(l.startsWith("rmnet") || l.startsWith("ccmni") || l.startsWith("pdp") || l.startsWith("ppp")
                || l.startsWith("v4-") || l.startsWith("tun") || l.startsWith("dummy"));
    }

    private void joinAll(MulticastSocket s) {
        try {
            InetSocketAddress g = new InetSocketAddress(InetAddress.getByName(GROUP), PORT);
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!usable(ni)) continue;
                try { s.joinGroup(g, ni); } catch (Exception ignored) { } // already joined -> exception, harmless
            }
        } catch (Exception ignored) {
        }
    }

    private void handle(MulticastSocket s, DatagramPacket p) throws Exception {
        if (p.getPort() != PORT || !(p.getAddress() instanceof Inet4Address)) return;
        byte[] from = p.getAddress().getAddress();
        NetworkInterface ni = null;
        byte[] ip = null;
        for (NetworkInterface cand : Collections.list(NetworkInterface.getNetworkInterfaces())) {
            if (!usable(cand)) continue;
            for (InterfaceAddress ia : cand.getInterfaceAddresses()) {
                if (ia.getAddress() instanceof Inet4Address && sameNet(from, ia.getAddress().getAddress(), ia.getNetworkPrefixLength())) {
                    ni = cand;
                    ip = ia.getAddress().getAddress();
                }
            }
        }
        if (ip == null) return;
        boolean[] unicast = new boolean[1];
        byte[] resp = answer(p.getData(), p.getLength(), ip, unicast);
        if (resp == null) return;
        try { if (ni != null) s.setNetworkInterface(ni); } catch (Exception ignored) { }
        s.send(new DatagramPacket(resp, resp.length, InetAddress.getByName(GROUP), PORT));
        if (unicast[0]) s.send(new DatagramPacket(resp, resp.length, p.getAddress(), p.getPort()));
    }

    /**
     * Pure function (also used by the test): returns the mDNS answer for a query packet, or null when the packet is not a
     * question for glide.local of type A / ANY. unicast[0] is set when the asker wants a unicast reply (QU bit).
     */
    static byte[] answer(byte[] d, int len, byte[] ip, boolean[] unicast) {
        if (len < 12 || ip == null || ip.length != 4) return null;
        int flags = u16(d, 2);
        if ((flags & 0x8000) != 0) return null; // a response, not a question
        int qd = u16(d, 4);
        int off = 12;
        boolean want = false;
        for (int i = 0; i < qd; i++) {
            StringBuilder name = new StringBuilder();
            off = readName(d, len, off, name);
            if (off < 0 || off + 4 > len) return null;
            int type = u16(d, off);
            int cls = u16(d, off + 2);
            off += 4;
            if (name.toString().equalsIgnoreCase(HOST) && (type == 1 || type == 255) && (cls & 0x7fff) == 1) {
                want = true;
                if ((cls & 0x8000) != 0 && unicast != null && unicast.length > 0) unicast[0] = true;
            }
        }
        if (!want) return null;
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        put16(o, 0);        // id is 0 in mDNS answers
        put16(o, 0x8400);   // response + authoritative
        put16(o, 0);        // questions
        put16(o, 1);        // answers
        put16(o, 0);
        put16(o, 0);
        for (String label : HOST.split("\\.")) {
            byte[] b = label.getBytes(StandardCharsets.UTF_8);
            o.write(b.length);
            o.write(b, 0, b.length);
        }
        o.write(0);
        put16(o, 1);        // type A
        put16(o, 0x8001);   // class IN + cache-flush
        put16(o, 0);
        put16(o, 120);      // ttl (seconds)
        put16(o, 4);        // rdlength
        o.write(ip, 0, 4);
        return o.toByteArray();
    }

    private static int u16(byte[] d, int i) {
        return ((d[i] & 0xff) << 8) | (d[i + 1] & 0xff);
    }

    private static void put16(ByteArrayOutputStream o, int v) {
        o.write((v >> 8) & 0xff);
        o.write(v & 0xff);
    }

    /** Reads a DNS name (labels and compression pointers) into out. Returns the offset after the name, or -1 on error. */
    private static int readName(byte[] d, int len, int off, StringBuilder out) {
        int pos = off;
        int end = -1;
        int hops = 0;
        while (true) {
            if (pos >= len) return -1;
            int l = d[pos] & 0xff;
            if (l == 0) {
                pos++;
                break;
            }
            if ((l & 0xc0) == 0xc0) {
                if (pos + 1 >= len) return -1;
                if (end < 0) end = pos + 2;
                pos = ((l & 0x3f) << 8) | (d[pos + 1] & 0xff);
                if (++hops > 10) return -1;
                continue;
            }
            pos++;
            if (pos + l > len) return -1;
            if (out.length() > 0) out.append('.');
            out.append(new String(d, pos, l, StandardCharsets.UTF_8));
            pos += l;
        }
        return end >= 0 ? end : pos;
    }

    private static boolean sameNet(byte[] a, byte[] b, int prefix) {
        int full = prefix / 8;
        int rem = prefix % 8;
        for (int i = 0; i < full && i < 4; i++) if (a[i] != b[i]) return false;
        if (rem > 0 && full < 4) {
            int mask = (0xff << (8 - rem)) & 0xff;
            if ((a[full] & mask) != (b[full] & mask)) return false;
        }
        return true;
    }
}
