package com.glide.share;

import android.app.Activity;
import android.content.ClipData;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.webkit.MimeTypeMap;

import androidx.activity.result.ActivityResult;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * Nearby sharing on the same Wi-Fi, with no server and no typing. Speaks the same protocol as the
 * Glide PC app, so phone-to-PC and phone-to-phone both work:
 *  - UDP broadcast on port 53319 announces this device and finds the others,
 *  - HTTP on port 53318 receives files (POST /send, Expect: 100-continue),
 *  - files are streamed straight from/to storage (content:// uris), never loaded into memory.
 */
@CapacitorPlugin(name = "GlideNearby")
public class GlideNearbyPlugin extends Plugin {

    private static final int HTTP_PORT = 53318;
    private static final int UDP_PORT = 53319;

    private static class Peer {
        String id;
        String name;
        String ip;
        int port;
        long seen;
        boolean manual;
    }

    private static class Decision {
        final CountDownLatch latch = new CountDownLatch(1);
        volatile boolean ok;
    }

    private static class Saved {
        Uri uri;
        OutputStream out;
        String name;
        String folder;
    }

    private final String myId = UUID.randomUUID().toString();
    private volatile String deviceName = "My phone";
    private final Map<String, Peer> peers = new ConcurrentHashMap<>();
    private final Map<String, Decision> pending = new ConcurrentHashMap<>();
    private final Map<String, String> extFolders = new ConcurrentHashMap<>();
    private final ExecutorService pool = Executors.newCachedThreadPool();
    private volatile boolean running = false;
    private DatagramSocket udp;
    private ServerSocket server;
    private WifiManager.MulticastLock lock;

    /* ------------------------------------------------------------------ plugin methods */

    @PluginMethod
    public void start(PluginCall call) {
        String n = call.getString("name");
        if (n != null && !n.trim().isEmpty()) deviceName = n.trim();
        JSObject types = call.getObject("types");
        if (types != null) {
            Iterator<String> it = types.keys();
            while (it.hasNext()) {
                String k = it.next();
                String v = types.optString(k, "");
                if (!v.isEmpty()) extFolders.put(k, v);
            }
        }
        if (!running) {
            running = true;
            startAll();
        }
        call.resolve(ipsResult());
    }

    @PluginMethod
    public void setName(PluginCall call) {
        String n = call.getString("name");
        if (n != null && !n.trim().isEmpty()) deviceName = n.trim();
        call.resolve();
    }

    @PluginMethod
    public void ips(PluginCall call) {
        call.resolve(ipsResult());
    }

    /** Adds a device by its IP address (for networks where broadcast does not get through). */
    @PluginMethod
    public void addPeer(PluginCall call) {
        String ip = call.getString("ip", "").trim();
        if (!ip.matches("\\d{1,3}(\\.\\d{1,3}){3}")) {
            call.reject("Invalid IP address");
            return;
        }
        Peer p = new Peer();
        p.id = "manual-" + ip;
        p.name = ip;
        p.ip = ip;
        p.port = HTTP_PORT;
        p.manual = true;
        p.seen = System.currentTimeMillis();
        peers.put(p.id, p);
        notifyPeers();
        call.resolve();
    }

    @PluginMethod
    public void respond(PluginCall call) {
        Decision d = pending.get(call.getString("id", ""));
        if (d != null) {
            Boolean ok = call.getBoolean("ok", false);
            d.ok = ok != null && ok;
            d.latch.countDown();
        }
        call.resolve();
    }

    /** Native file picker: returns content:// uris so files can be streamed without copying. */
    @PluginMethod
    public void pick(PluginCall call) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(call, i, "pickResult");
    }

    @ActivityCallback
    private void pickResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        JSArray files = new JSArray();
        if (result != null && result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
            Intent d = result.getData();
            ClipData cd = d.getClipData();
            if (cd != null) {
                for (int k = 0; k < cd.getItemCount(); k++) {
                    Uri u = cd.getItemAt(k).getUri();
                    if (u != null) files.put(describe(getContext(), u));
                }
            } else if (d.getData() != null) {
                files.put(describe(getContext(), d.getData()));
            }
        }
        JSObject res = new JSObject();
        res.put("files", files);
        call.resolve(res);
    }

    /** Sends one file to a nearby device. Resolves when the transfer has ended. */
    @PluginMethod
    public void send(PluginCall call) {
        final String peerId = call.getString("peerId", "");
        final String uriStr = call.getString("uri", "");
        final String name = call.getString("name", "file");
        final long size = call.getData().optLong("size", 0);
        final Peer peer = peers.get(peerId);
        if (peer == null) {
            call.reject("Device not found");
            return;
        }
        pool.execute(() -> {
            try {
                doSend(peer, uriStr, name, size);
            } finally {
                call.resolve();
            }
        });
    }

    /* ------------------------------------------------------------------ start / stop */

    private void startAll() {
        try {
            WifiManager wm = (WifiManager) getContext().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm != null) {
                lock = wm.createMulticastLock("glide");
                lock.setReferenceCounted(false);
                lock.acquire(); // without this many phones ignore broadcast packets
            }
        } catch (Exception ignored) {
        }
        pool.execute(this::udpLoop);
        pool.execute(this::beaconLoop);
        pool.execute(this::serverLoop);
    }

    @Override
    protected void handleOnDestroy() {
        running = false;
        try { if (udp != null) udp.close(); } catch (Exception ignored) { }
        try { if (server != null) server.close(); } catch (Exception ignored) { }
        try { if (lock != null && lock.isHeld()) lock.release(); } catch (Exception ignored) { }
        pool.shutdownNow();
        super.handleOnDestroy();
    }

    /* ------------------------------------------------------------------ discovery */

    private void udpLoop() {
        try {
            DatagramSocket s = new DatagramSocket(null);
            s.setReuseAddress(true);
            s.setBroadcast(true);
            s.bind(new InetSocketAddress(UDP_PORT));
            udp = s;
            byte[] buf = new byte[2048];
            while (running) {
                DatagramPacket p = new DatagramPacket(buf, buf.length);
                s.receive(p);
                onBeacon(new String(p.getData(), 0, p.getLength(), StandardCharsets.UTF_8), p.getAddress().getHostAddress());
            }
        } catch (Exception ignored) {
        }
    }

    private void beaconLoop() {
        while (running) {
            try {
                DatagramSocket s = udp;
                if (s != null) {
                    JSONObject j = new JSONObject();
                    j.put("app", "glide");
                    j.put("id", myId);
                    j.put("name", deviceName);
                    j.put("port", HTTP_PORT);
                    byte[] b = j.toString().getBytes(StandardCharsets.UTF_8);
                    for (InetAddress a : broadcastAddrs()) {
                        try {
                            s.send(new DatagramPacket(b, b.length, a, UDP_PORT));
                        } catch (Exception ignored) {
                        }
                    }
                }
                long now = System.currentTimeMillis();
                for (Peer p : peers.values()) {
                    if (!p.manual && now - p.seen > 8000) peers.remove(p.id);
                }
                notifyPeers();
                Thread.sleep(2500);
            } catch (InterruptedException ie) {
                return;
            } catch (Exception ignored) {
            }
        }
    }

    private void onBeacon(String msg, String ip) {
        try {
            JSONObject j = new JSONObject(msg);
            String id = j.optString("id", "");
            if (!"glide".equals(j.optString("app", "")) || id.isEmpty() || myId.equals(id)) return;
            Peer p = peers.get(id);
            boolean isNew = p == null;
            if (isNew) {
                p = new Peer();
                p.id = id;
                peers.put(id, p);
            }
            String name = j.optString("name", "Unknown");
            if (name.length() > 40) name = name.substring(0, 40);
            p.name = name;
            p.ip = ip;
            p.port = j.optInt("port", HTTP_PORT);
            p.seen = System.currentTimeMillis();
            if (isNew) notifyPeers();
        } catch (Exception ignored) {
        }
    }

    private List<InetAddress> broadcastAddrs() {
        List<InetAddress> out = new ArrayList<>();
        try {
            out.add(InetAddress.getByName("255.255.255.255"));
        } catch (Exception ignored) {
        }
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
                    InetAddress b = ia.getBroadcast();
                    if (b != null) out.add(b);
                }
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    private void notifyPeers() {
        Set<String> realIps = new HashSet<>();
        for (Peer p : peers.values()) {
            if (!p.manual) realIps.add(p.ip);
        }
        JSArray arr = new JSArray();
        for (Peer p : peers.values()) {
            if (p.manual && realIps.contains(p.ip)) continue; // already found by broadcast
            JSObject o = new JSObject();
            o.put("id", p.id);
            o.put("name", p.name);
            o.put("ip", p.ip);
            arr.put(o);
        }
        JSObject res = new JSObject();
        res.put("peers", arr);
        notifyListeners("peers", res);
    }

    private JSObject ipsResult() {
        JSArray arr = new JSArray();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address && !a.isLoopbackAddress()) arr.put(a.getHostAddress());
                }
            }
        } catch (Exception ignored) {
        }
        JSObject r = new JSObject();
        r.put("ips", arr);
        return r;
    }

    /* ------------------------------------------------------------------ receiving */

    private void serverLoop() {
        try {
            ServerSocket ss = new ServerSocket();
            ss.setReuseAddress(true);
            ss.bind(new InetSocketAddress(HTTP_PORT));
            server = ss;
            while (running) {
                final Socket s = ss.accept();
                pool.execute(() -> handleClient(s));
            }
        } catch (Exception ignored) {
        }
    }

    private void handleClient(Socket s) {
        String tid = UUID.randomUUID().toString();
        String name = "file";
        String from = "Unknown device";
        long size = 0;
        Saved saved = null;
        boolean announced = false;
        try {
            s.setTcpNoDelay(true);
            s.setSoTimeout(10000);
            InputStream in = new BufferedInputStream(s.getInputStream(), 65536);
            OutputStream out = s.getOutputStream();

            String req = readLine(in);
            if (req == null) {
                s.close();
                return;
            }
            Map<String, String> h = new HashMap<>();
            String line;
            while ((line = readLine(in)) != null && !line.isEmpty()) {
                int i = line.indexOf(':');
                if (i > 0) h.put(line.substring(0, i).trim().toLowerCase(Locale.ROOT), line.substring(i + 1).trim());
            }
            if (!req.startsWith("POST /send")) {
                respond(out, 404, "Not Found");
                s.close();
                return;
            }
            try {
                name = safeName(URLDecoder.decode(h.containsKey("x-file-name") ? h.get("x-file-name") : "file", "UTF-8"));
            } catch (Exception ignored) {
            }
            try {
                from = URLDecoder.decode(h.containsKey("x-sender") ? h.get("x-sender") : from, "UTF-8");
            } catch (Exception ignored) {
            }
            if (from.length() > 40) from = from.substring(0, 40);
            long total;
            try {
                String cl = h.containsKey("content-length") ? h.get("content-length") : h.get("x-file-size");
                total = Long.parseLong(cl == null ? "0" : cl);
            } catch (Exception e) {
                total = 0;
            }
            size = total;
            String ex = h.get("expect");
            boolean expect = ex != null && ex.toLowerCase(Locale.ROOT).contains("100");

            emitTransfer(tid, name, size, "in", from, "waiting", 0, null, null);
            announced = true;
            JSObject inc = new JSObject();
            inc.put("id", tid);
            inc.put("name", name);
            inc.put("size", size);
            inc.put("from", from);
            notifyListeners("incoming", inc);

            Decision d = new Decision();
            pending.put(tid, d);
            boolean answered = false;
            try {
                answered = d.latch.await(60, TimeUnit.SECONDS);
            } catch (InterruptedException ignored) {
            }
            pending.remove(tid);
            if (!answered || !d.ok) {
                respond(out, 403, "Forbidden");
                JSObject c = new JSObject();
                c.put("id", tid);
                notifyListeners("incomingCancel", c);
                emitTransfer(tid, name, size, "in", from, "declined", 0, null, null);
                s.close();
                return;
            }

            s.setSoTimeout(30000);
            if (expect) {
                out.write("HTTP/1.1 100 Continue\r\n\r\n".getBytes(StandardCharsets.US_ASCII));
                out.flush();
            }
            saved = createSaved(name);
            emitTransfer(tid, name, size, "in", from, "receiving", 0, null, null);
            byte[] buf = new byte[256 * 1024];
            long done = 0;
            long last = 0;
            while (done < total) {
                int n = in.read(buf, 0, (int) Math.min(buf.length, total - done));
                if (n < 0) throw new EOFException();
                saved.out.write(buf, 0, n);
                done += n;
                long now = System.currentTimeMillis();
                if (now - last > 120) {
                    last = now;
                    emitTransfer(tid, name, size, "in", from, "receiving", done, null, null);
                }
            }
            saved.out.flush();
            saved.out.close();
            finishSaved(saved);
            String path = "Downloads/Glide/" + saved.folder + "/" + saved.name;
            String uri = saved.uri.toString();
            saved = null;
            respond(out, 200, "OK");
            emitTransfer(tid, name, size, "in", from, "done", total, path, uri);
            s.close();
        } catch (Exception ex) {
            if (saved != null) {
                try { saved.out.close(); } catch (Exception ignored) { }
                try { getContext().getContentResolver().delete(saved.uri, null, null); } catch (Exception ignored) { }
            }
            if (announced) emitTransfer(tid, name, size, "in", from, "failed", 0, null, null);
            try { s.close(); } catch (Exception ignored) { }
        }
    }

    /* ------------------------------------------------------------------ sending */

    private void doSend(Peer peer, String uriStr, String name, long size) {
        String tid = UUID.randomUUID().toString();
        String to = peer.name;
        emitTransfer(tid, name, size, "out", to, "waiting", 0, null, null);
        Socket s = null;
        InputStream src = null;
        try {
            src = getContext().getContentResolver().openInputStream(Uri.parse(uriStr));
            if (src == null) throw new IOException("Cannot open the file");
            s = new Socket();
            s.connect(new InetSocketAddress(peer.ip, peer.port), 6000);
            s.setTcpNoDelay(true);
            s.setSoTimeout(75000); // the other person has up to 60 s to accept
            OutputStream out = s.getOutputStream();
            InputStream in = new BufferedInputStream(s.getInputStream());

            String hdr = "POST /send HTTP/1.1\r\n"
                    + "Host: " + peer.ip + ":" + peer.port + "\r\n"
                    + "Content-Length: " + size + "\r\n"
                    + "Expect: 100-continue\r\n"
                    + "Connection: close\r\n"
                    + "X-File-Name: " + enc(name) + "\r\n"
                    + "X-File-Size: " + size + "\r\n"
                    + "X-Sender: " + enc(deviceName) + "\r\n\r\n";
            out.write(hdr.getBytes(StandardCharsets.US_ASCII));
            out.flush();

            int code = statusCode(readLine(in));
            if (code != 100) {
                emitTransfer(tid, name, size, "out", to, code == 403 ? "declined" : "failed", 0, null, null);
                return;
            }
            while (true) { // skip the rest of the "100 Continue" reply
                String l = readLine(in);
                if (l == null || l.isEmpty()) break;
            }

            emitTransfer(tid, name, size, "out", to, "sending", 0, null, null);
            byte[] buf = new byte[256 * 1024];
            long done = 0;
            long last = 0;
            int n;
            while ((n = src.read(buf)) > 0) {
                out.write(buf, 0, n);
                done += n;
                long now = System.currentTimeMillis();
                if (now - last > 120) {
                    last = now;
                    emitTransfer(tid, name, size, "out", to, "sending", done, null, null);
                }
            }
            out.flush();
            s.setSoTimeout(30000);
            int fin = statusCode(readLine(in));
            if (fin == 200) emitTransfer(tid, name, size, "out", to, "done", size, null, null);
            else emitTransfer(tid, name, size, "out", to, "failed", done, null, null);
        } catch (Exception ex) {
            emitTransfer(tid, name, size, "out", to, "failed", 0, null, null);
        } finally {
            try { if (src != null) src.close(); } catch (Exception ignored) { }
            try { if (s != null) s.close(); } catch (Exception ignored) { }
        }
    }

    /* ------------------------------------------------------------------ helpers */

    private void emitTransfer(String id, String name, long size, String dir, String peer, String status, long done, String path, String uri) {
        JSObject o = new JSObject();
        o.put("id", id);
        o.put("name", name);
        o.put("size", size);
        o.put("dir", dir);
        o.put("peer", peer);
        o.put("status", status);
        o.put("done", done);
        if (path != null) o.put("path", path);
        if (uri != null) o.put("uri", uri);
        notifyListeners("transfer", o);
    }

    private Saved createSaved(String name) throws Exception {
        String folder = folderOf(name);
        ContentResolver cr = getContext().getContentResolver();
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        v.put(MediaStore.MediaColumns.MIME_TYPE, mimeOf(name));
        v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Glide/" + folder);
        v.put(MediaStore.MediaColumns.IS_PENDING, 1);
        Uri uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
        if (uri == null) throw new IOException("Could not create the file");
        OutputStream out = cr.openOutputStream(uri, "w");
        if (out == null) throw new IOException("Could not open the file");
        String finalName = name; // Android may rename to "name (1).ext"; read back the real name
        Cursor c = cr.query(uri, new String[]{MediaStore.MediaColumns.DISPLAY_NAME}, null, null, null);
        if (c != null) {
            try {
                if (c.moveToFirst()) finalName = c.getString(0);
            } finally {
                c.close();
            }
        }
        Saved s = new Saved();
        s.uri = uri;
        s.out = out;
        s.name = finalName;
        s.folder = folder;
        return s;
    }

    private void finishSaved(Saved s) {
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.IS_PENDING, 0);
        getContext().getContentResolver().update(s.uri, v, null, null);
    }

    private String folderOf(String name) {
        int dot = name.lastIndexOf('.');
        if (dot < 0 || dot == name.length() - 1) return "Other";
        String f = extFolders.get(name.substring(dot + 1).toLowerCase(Locale.ROOT));
        if (f == null) return "Other";
        String clean = f.replaceAll("[^A-Za-z0-9]", "");
        return clean.isEmpty() ? "Other" : clean;
    }

    private static String mimeOf(String name) {
        int dot = name.lastIndexOf('.');
        if (dot >= 0 && dot < name.length() - 1) {
            String mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substring(dot + 1).toLowerCase(Locale.ROOT));
            if (mime != null) return mime;
        }
        return "application/octet-stream";
    }

    private static String safeName(String n) {
        String b = n.replaceAll("[<>:\"/\\\\|?*\\x00-\\x1f]", "_").trim();
        return b.isEmpty() ? "file" : b;
    }

    private static String enc(String s) {
        try {
            return URLEncoder.encode(s, "UTF-8").replace("+", "%20");
        } catch (Exception e) {
            return "file";
        }
    }

    private static int statusCode(String line) {
        if (line == null) return -1;
        String[] p = line.split(" ");
        if (p.length < 2) return -1;
        try {
            return Integer.parseInt(p[1]);
        } catch (Exception e) {
            return -1;
        }
    }

    private static String readLine(InputStream in) throws IOException {
        StringBuilder sb = new StringBuilder();
        int c;
        while ((c = in.read()) != -1) {
            if (c == '\n') break;
            if (c != '\r') sb.append((char) c);
            if (sb.length() > 16384) throw new IOException("line too long");
        }
        if (c == -1 && sb.length() == 0) return null;
        return sb.toString();
    }

    private static void respond(OutputStream out, int code, String text) {
        try {
            byte[] body = (code == 200 ? "ok" : "").getBytes(StandardCharsets.UTF_8);
            String h = "HTTP/1.1 " + code + " " + text + "\r\nContent-Length: " + body.length + "\r\nConnection: close\r\n\r\n";
            out.write(h.getBytes(StandardCharsets.US_ASCII));
            out.write(body);
            out.flush();
        } catch (Exception ignored) {
        }
    }

    static JSObject describe(Context ctx, Uri u) {
        ContentResolver cr = ctx.getContentResolver();
        String name = "file";
        long size = 0;
        Cursor c = null;
        try {
            c = cr.query(u, null, null, null, null);
            if (c != null && c.moveToFirst()) {
                int ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                int si = c.getColumnIndex(OpenableColumns.SIZE);
                if (ni >= 0 && !c.isNull(ni)) name = c.getString(ni);
                if (si >= 0 && !c.isNull(si)) size = c.getLong(si);
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        if (size <= 0) {
            try (ParcelFileDescriptor pfd = cr.openFileDescriptor(u, "r")) {
                if (pfd != null) size = Math.max(0, pfd.getStatSize());
            } catch (Exception ignored) {
            }
        }
        JSObject f = new JSObject();
        f.put("uri", u.toString());
        f.put("name", name);
        f.put("size", size);
        return f;
    }
}
