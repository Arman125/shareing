package com.glide.share;

import android.nfc.cardemulation.HostApduService;
import android.os.Bundle;

import java.nio.charset.StandardCharsets;

/**
 * v45, EXPERIMENTAL (never run on a real phone by the author).
 * While Host is on and the NFC option is on, this phone acts like an NFC tag (Type 4, NDEF) that holds one web address.
 * Another phone that touches the back of this one opens that address in its browser: no Glide app needed there.
 * Works only while the screen is on; some phones / makers block card emulation.
 */
public class GlideNfcService extends HostApduService {
    private static volatile byte[] ndef = null; // 2-byte length + NDEF message, null = off
    private static final byte[] OK = {(byte) 0x90, 0x00};
    private static final byte[] NOT_FOUND = {0x6A, (byte) 0x82};
    private static final byte[] BAD_OFFSET = {0x6B, 0x00};
    // Capability container: version 2.0, read-only, NDEF file E104 up to 255 bytes
    private static final byte[] CC = {0x00, 0x0F, 0x20, 0x00, 0x3B, 0x00, 0x34, 0x04, 0x06, (byte) 0xE1, 0x04, 0x00, (byte) 0xFF, 0x00, (byte) 0xFF};
    private boolean ccSelected = false;

    /** Sets the address handed out by tapping. null or empty = stop. Returns false when it does not fit. */
    public static boolean setUrl(String url) {
        if (url == null || url.isEmpty()) { ndef = null; return true; }
        int code = 0;
        if (url.startsWith("http://")) { code = 3; url = url.substring(7); }
        else if (url.startsWith("https://")) { code = 4; url = url.substring(8); }
        byte[] u = url.getBytes(StandardCharsets.UTF_8);
        int plen = u.length + 1;
        if (plen > 200) return false;
        byte[] rec = new byte[4 + plen];
        rec[0] = (byte) 0xD1; rec[1] = 0x01; rec[2] = (byte) plen; rec[3] = 0x55; rec[4] = (byte) code;
        System.arraycopy(u, 0, rec, 5, u.length);
        byte[] file = new byte[2 + rec.length];
        file[0] = (byte) (rec.length >> 8); file[1] = (byte) rec.length;
        System.arraycopy(rec, 0, file, 2, rec.length);
        ndef = file;
        return true;
    }

    @Override
    public byte[] processCommandApdu(byte[] c, Bundle extras) {
        byte[] data = ndef;
        if (data == null || c == null || c.length < 4) return NOT_FOUND;
        if (c[1] == (byte) 0xA4) { // SELECT
            if (c[2] == 0x04) { ccSelected = false; return OK; } // application (only our AID is registered)
            if (c[2] == 0x00 && c.length >= 7) {
                int id = ((c[5] & 0xFF) << 8) | (c[6] & 0xFF);
                if (id == 0xE103) { ccSelected = true; return OK; }
                if (id == 0xE104) { ccSelected = false; return OK; }
            }
            return NOT_FOUND;
        }
        if (c[1] == (byte) 0xB0 && c.length >= 5) { // READ BINARY
            int off = ((c[2] & 0xFF) << 8) | (c[3] & 0xFF);
            int le = c[4] & 0xFF; if (le == 0) le = 256;
            byte[] src = ccSelected ? CC : data;
            if (off > src.length) return BAD_OFFSET;
            int n = Math.min(le, src.length - off);
            byte[] r = new byte[n + 2];
            System.arraycopy(src, off, r, 0, n);
            r[n] = (byte) 0x90; r[n + 1] = 0x00;
            return r;
        }
        return NOT_FOUND;
    }

    @Override
    public void onDeactivated(int reason) { ccSelected = false; }
}
