package com.glide.share;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.view.WindowManager;
import android.webkit.MimeTypeMap;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Saves received files into Downloads/Glide/<Type> (Video, Image, APK, PDF, Document...) using MediaStore,
 * opens the Android share sheet, accepts files shared from other apps, and can keep the screen on while a transfer session is active.
 */
@CapacitorPlugin(name = "GlideSaver")
public class GlideSaverPlugin extends Plugin {

    private static class Entry {
        Uri uri;
        OutputStream out;
        String name;
        String folder;
    }

    // An open content:// file being sent (sequential reads, reopened if the position jumps).
    private static class Reader {
        InputStream in;
        long pos;
    }

    private final Map<String, Reader> readers = new HashMap<>();

    private final Map<String, Entry> entries = new HashMap<>();

    private static String mimeOf(String name) {
        int dot = name.lastIndexOf('.');
        if (dot >= 0 && dot < name.length() - 1) {
            String ext = name.substring(dot + 1).toLowerCase(Locale.ROOT);
            String mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
            if (mime != null) return mime;
        }
        return "application/octet-stream";
    }

    private static String cleanFolder(String f) {
        if (f == null) return "Other";
        String c = f.replaceAll("[^A-Za-z0-9]", "");
        return c.isEmpty() ? "Other" : c;
    }

    @PluginMethod
    public void begin(PluginCall call) {
        String name = call.getString("name", "file");
        String folder = cleanFolder(call.getString("folder", "Other"));
        try {
            ContentResolver cr = getContext().getContentResolver();
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, mimeOf(name));
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Glide/" + folder);
            v.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (uri == null) {
                call.reject("Could not create the file");
                return;
            }
            OutputStream out = cr.openOutputStream(uri, "w");
            if (out == null) {
                call.reject("Could not open the file");
                return;
            }

            // Android may rename to "name (1).ext" if it already exists. Read back the real name.
            String finalName = name;
            Cursor c = cr.query(uri, new String[]{MediaStore.MediaColumns.DISPLAY_NAME}, null, null, null);
            if (c != null) {
                try {
                    if (c.moveToFirst()) finalName = c.getString(0);
                } finally {
                    c.close();
                }
            }

            Entry e = new Entry();
            e.uri = uri;
            e.out = out;
            e.name = finalName;
            e.folder = folder;
            String id = UUID.randomUUID().toString();
            synchronized (entries) {
                entries.put(id, e);
            }
            JSObject res = new JSObject();
            res.put("id", id);
            res.put("name", finalName);
            call.resolve(res);
        } catch (Exception ex) {
            call.reject(String.valueOf(ex.getMessage()));
        }
    }

    @PluginMethod
    public void write(PluginCall call) {
        Entry e;
        synchronized (entries) {
            e = entries.get(call.getString("id", ""));
        }
        if (e == null) {
            call.reject("Unknown file");
            return;
        }
        try {
            byte[] bytes = Base64.decode(call.getString("data", ""), Base64.DEFAULT);
            e.out.write(bytes);
            call.resolve();
        } catch (Exception ex) {
            call.reject(String.valueOf(ex.getMessage()));
        }
    }

    /** Cancelled download: close the stream and delete the half-written file. */
    @PluginMethod
    public void abort(PluginCall call) {
        Entry e;
        synchronized (entries) {
            e = entries.remove(call.getString("id", ""));
        }
        if (e != null) {
            try { e.out.close(); } catch (Exception ignored) { }
            try { getContext().getContentResolver().delete(e.uri, null, null); } catch (Exception ignored) { }
        }
        call.resolve();
    }

    @PluginMethod
    public void finish(PluginCall call) {
        Entry e;
        synchronized (entries) {
            e = entries.remove(call.getString("id", ""));
        }
        if (e == null) {
            call.reject("Unknown file");
            return;
        }
        try {
            e.out.flush();
            e.out.close();
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.IS_PENDING, 0);
            getContext().getContentResolver().update(e.uri, v, null, null);
            JSObject res = new JSObject();
            res.put("path", "Downloads/Glide/" + e.folder + "/" + e.name);
            res.put("uri", e.uri.toString());
            call.resolve(res);
        } catch (Exception ex) {
            call.reject(String.valueOf(ex.getMessage()));
        }
    }

    /** Opens the Android share sheet (Quick Share, Vivo Share, Bluetooth, WhatsApp...) for a saved file. */
    @PluginMethod
    public void shareFile(PluginCall call) {
        String uri = call.getString("uri", "");
        String name = call.getString("name", "file");
        if (uri.isEmpty()) {
            call.reject("No file");
            return;
        }
        try {
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType(mimeOf(name));
            send.putExtra(Intent.EXTRA_STREAM, Uri.parse(uri));
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent chooser = Intent.createChooser(send, "Share " + name);
            chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            getActivity().startActivity(chooser);
            call.resolve();
        } catch (Exception ex) {
            call.reject(String.valueOf(ex.getMessage()));
        }
    }

    /** Reads a slice of a file another app shared with Glide (content:// uri). Returns base64. */
    @PluginMethod
    public void readUri(PluginCall call) {
        String uri = call.getString("uri", "");
        long offset = call.getData().optLong("offset", 0);
        int length = call.getInt("length", 262144);
        try {
            byte[] buf = new byte[length];
            int n = 0;
            synchronized (readers) {
                Reader r = readers.get(uri);
                if (r == null || r.pos != offset) {
                    if (r != null && r.in != null) {
                        try { r.in.close(); } catch (Exception ignored) { }
                    }
                    r = new Reader();
                    r.in = getContext().getContentResolver().openInputStream(Uri.parse(uri));
                    if (r.in == null) {
                        call.reject("Could not open the file");
                        return;
                    }
                    long skipped = 0;
                    while (skipped < offset) {
                        long k = r.in.skip(offset - skipped);
                        if (k <= 0) break;
                        skipped += k;
                    }
                    r.pos = skipped;
                    readers.put(uri, r);
                }
                while (n < length) {
                    int k = r.in.read(buf, n, length - n);
                    if (k < 0) break;
                    n += k;
                }
                r.pos += n;
            }
            JSObject res = new JSObject();
            res.put("data", Base64.encodeToString(buf, 0, n, Base64.NO_WRAP));
            call.resolve(res);
        } catch (Exception ex) {
            call.reject(String.valueOf(ex.getMessage()));
        }
    }

    @PluginMethod
    public void closeUri(PluginCall call) {
        synchronized (readers) {
            Reader r = readers.remove(call.getString("uri", ""));
            if (r != null && r.in != null) {
                try { r.in.close(); } catch (Exception ignored) { }
            }
        }
        call.resolve();
    }

    /* ---- files shared INTO Glide from other apps (share sheet / Vivo Share) ---- */

    @Override
    public void load() {
        handleShareIntent(getActivity().getIntent());
    }

    @Override
    protected void handleOnNewIntent(Intent intent) {
        super.handleOnNewIntent(intent);
        handleShareIntent(intent);
    }

    @SuppressWarnings("deprecation")
    private void handleShareIntent(Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        ArrayList<Uri> uris = new ArrayList<>();
        try {
            if (Intent.ACTION_SEND.equals(action)) {
                Uri u = intent.getParcelableExtra(Intent.EXTRA_STREAM);
                if (u != null) uris.add(u);
            } else if (Intent.ACTION_SEND_MULTIPLE.equals(action)) {
                ArrayList<Uri> list = intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
                if (list != null) uris.addAll(list);
            } else {
                return;
            }
        } catch (Exception ex) {
            return;
        }
        if (uris.isEmpty()) return;

        ContentResolver cr = getContext().getContentResolver();
        JSArray files = new JSArray();
        for (Uri u : uris) {
            String name = "file";
            long size = 0;
            Cursor c = null;
            try {
                c = cr.query(u, null, null, null, null);
                if (c != null && c.moveToFirst()) {
                    int ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    int si = c.getColumnIndex(OpenableColumns.SIZE);
                    if (ni >= 0 && !c.isNull(ni)) name = c.getString(ni);
                    if (si >= 0 && !c.isNull(si)) size = c.getLong(si);
                }
            } catch (Exception ignored) {
            } finally {
                if (c != null) c.close();
            }
            JSObject f = new JSObject();
            f.put("uri", u.toString());
            f.put("name", name);
            f.put("size", size);
            files.put(f);
        }
        intent.setAction(Intent.ACTION_MAIN); // do not handle the same share twice
        JSObject data = new JSObject();
        data.put("files", files);
        notifyListeners("sharedFiles", data, true);
    }

    @PluginMethod
    public void keepAwake(PluginCall call) {
        final boolean on = Boolean.TRUE.equals(call.getBoolean("on", false));
        getActivity().runOnUiThread(() -> {
            if (on) {
                getActivity().getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            } else {
                getActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            }
        });
        call.resolve();
    }

    @Override
    protected void handleOnDestroy() {
        synchronized (entries) {
            for (Entry e : entries.values()) {
                try {
                    e.out.close();
                } catch (Exception ignored) {
                }
            }
            entries.clear();
        }
        synchronized (readers) {
            for (Reader r : readers.values()) {
                try { if (r.in != null) r.in.close(); } catch (Exception ignored) { }
            }
            readers.clear();
        }
        super.handleOnDestroy();
    }
}
