package com.glide.share;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.content.Context;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.IBinder;
import android.os.PowerManager;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Keeps Glide alive in the background with a permanent notification, so this phone stays ready
 * (hosting, nearby, saved devices) while the screen is off or another app is open.
 */
public class GlideService extends Service {
    static final String CHANNEL = "glide_keep";
    /** true while a connection or a file transfer is active (set by GlideHostPlugin.keepBusy). MainActivity keeps the WebView running while it is true. */
    static volatile boolean busy = false;
    private static PowerManager.WakeLock cpuLock;
    private static WifiManager.WifiLock wifiLock;

    /** CPU wake lock + Wi-Fi lock: the file keeps moving while the screen is off. Released when the transfer ends. */
    @SuppressWarnings("deprecation")
    static synchronized void hold(Context c, boolean on) {
        busy = on;
        try {
            Context app = c.getApplicationContext();
            if (on) {
                if (cpuLock == null) {
                    PowerManager pm = (PowerManager) app.getSystemService(Context.POWER_SERVICE);
                    if (pm != null) {
                        cpuLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "glide:transfer");
                        cpuLock.setReferenceCounted(false);
                    }
                }
                if (cpuLock != null && !cpuLock.isHeld()) cpuLock.acquire(6 * 60 * 60 * 1000L); // at most 6 hours, then it lets go by itself
                if (wifiLock == null) {
                    WifiManager wm = (WifiManager) app.getSystemService(Context.WIFI_SERVICE);
                    if (wm != null) {
                        wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "glide:transfer");
                        wifiLock.setReferenceCounted(false);
                    }
                }
                if (wifiLock != null && !wifiLock.isHeld()) wifiLock.acquire();
            } else {
                if (cpuLock != null && cpuLock.isHeld()) cpuLock.release();
                if (wifiLock != null && wifiLock.isHeld()) wifiLock.release();
            }
        } catch (Exception ignored) {
        }
    }
    private volatile boolean polling = false;
    private String lastNotified = "";

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String text = intent != null && intent.getStringExtra("text") != null ? intent.getStringExtra("text") : "Ready to share files";
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Glide is running", NotificationManager.IMPORTANCE_LOW));
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setContentTitle("Glide")
                .setContentText(text)
                .setSmallIcon(R.drawable.ic_stat_glide)
                .setColor(0xFF4F8CFF)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE);
        if (!polling) {
            polling = true;
            new Thread(this::watchHost, "glide-host-watch").start();
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        polling = false;
        hold(this, false);
        super.onDestroy();
    }

    /** Phone joined a hotspot whose owner runs Glide? Then a notification with the page address appears. */
    private void watchHost() {
        while (polling) {
            try {
                String gw = gateway();
                if (gw.isEmpty()) {
                    lastNotified = "";
                } else {
                    boolean up = probe(gw);
                    if (up && !gw.equals(lastNotified)) {
                        lastNotified = gw;
                        notifyHost(gw);
                    } else if (!up) {
                        lastNotified = "";
                    }
                }
            } catch (Exception ignored) {
            }
            try {
                Thread.sleep(6000);
            } catch (InterruptedException e) {
                break;
            }
        }
    }

    @SuppressWarnings("deprecation")
    private String gateway() {
        WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        int g = wm == null ? 0 : wm.getDhcpInfo().gateway;
        return g == 0 ? "" : (g & 0xff) + "." + ((g >> 8) & 0xff) + "." + ((g >> 16) & 0xff) + "." + ((g >> 24) & 0xff);
    }

    private boolean probe(String ip) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL("http://" + ip + ":8080/healthz").openConnection();
            c.setConnectTimeout(1500);
            c.setReadTimeout(1500);
            if (c.getResponseCode() != 200) return false;
            try (InputStream in = c.getInputStream()) {
                byte[] b = new byte[8];
                int n = in.read(b);
                return n >= 2 && b[0] == 'o' && b[1] == 'k';
            }
        } catch (Exception e) {
            return false;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private void notifyHost(String ip) {
        String url = "http://" + ip + ":8080/?auto=1";
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("glide_host", "Host found", NotificationManager.IMPORTANCE_HIGH));
        Intent view = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        view.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent pi = PendingIntent.getActivity(this, 3, view, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(this, "glide_host")
                .setContentTitle("Glide host found")
                .setContentText("http://" + ip + ":8080  (tap to open and connect)")
                .setSmallIcon(R.drawable.ic_stat_glide)
                .setColor(0xFF4F8CFF)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build();
        nm.notify(3, n);
    }
}
