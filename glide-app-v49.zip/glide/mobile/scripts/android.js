// Builds the Android project from the shared renderer.
//   node scripts/android.js setup   -> creates/updates mobile/android (open it in Android Studio)
//   node scripts/android.js apk     -> setup + builds a debug APK
const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const root = path.join(__dirname, '..');
const www = path.join(root, 'www');
const androidDir = path.join(root, 'android');
const pkg = 'com.glide.share';
const javaDir = path.join(androidDir, 'app', 'src', 'main', 'java', ...pkg.split('.'));

function run(cmd, cwd = root) {
  console.log(`\n> ${cmd}`);
  const r = spawnSync(cmd, { cwd, stdio: 'inherit', shell: true });
  if (r.status !== 0) { console.error(`\nFailed: ${cmd}`); process.exit(r.status || 1); }
}

function buildWeb() {
  fs.rmSync(www, { recursive: true, force: true });
  fs.cpSync(path.join(root, '..', 'renderer'), www, { recursive: true });
}

function patchAndroid() {
  // 1) native plugin: saves into Downloads/Glide/<type>, share sheet, share target, keeps the screen awake
  fs.mkdirSync(javaDir, { recursive: true });
  for (const f of fs.readdirSync(path.join(root, 'native')).filter((n) => n.endsWith('.java'))) {
    fs.copyFileSync(path.join(root, 'native', f), path.join(javaDir, f));
  }
  fs.writeFileSync(path.join(javaDir, 'MainActivity.java'),
`package ${pkg};

import android.os.Bundle;
import android.webkit.WebView;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(GlideSaverPlugin.class);
        registerPlugin(GlideNearbyPlugin.class);
        registerPlugin(GlideHostPlugin.class);
        super.onCreate(savedInstanceState);
        try { // v49: keep the page's render process at high priority even when the app is not visible (it is not paused or killed first)
            if (android.os.Build.VERSION.SDK_INT >= 26 && getBridge() != null && getBridge().getWebView() != null) {
                getBridge().getWebView().setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false);
            }
        } catch (Exception ignored) {
        }
    }

    // v48: while a transfer is active the page must keep running with the screen off (Android would pause the WebView)
    private void keepRunning() {
        try {
            if (GlideService.busy && getBridge() != null && getBridge().getWebView() != null) {
                WebView w = getBridge().getWebView();
                w.onResume();
                w.resumeTimers();
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        keepRunning();
    }

    @Override
    public void onStop() {
        super.onStop();
        keepRunning();
    }
}
`);

  // 2) allow ws:// to a PC on the same Wi-Fi
  const mf = path.join(androidDir, 'app', 'src', 'main', 'AndroidManifest.xml');
  let m = fs.readFileSync(mf, 'utf8');
  // nearby sharing: join the Wi-Fi broadcast group and read the network state
  for (const perm of ['INTERNET', 'ACCESS_NETWORK_STATE', 'ACCESS_WIFI_STATE', 'CHANGE_WIFI_MULTICAST_STATE', 'WAKE_LOCK', 'POST_NOTIFICATIONS', 'REQUEST_IGNORE_BATTERY_OPTIMIZATIONS', 'FOREGROUND_SERVICE', 'FOREGROUND_SERVICE_CONNECTED_DEVICE']) {
    if (!m.includes(`android.permission.${perm}"`)) {
      m = m.replace('<application', `<uses-permission android:name="android.permission.${perm}" />\n    <application`);
    }
  }
  // v45 NFC tap-to-connect (card emulation): permission, optional feature, service
  if (!m.includes('android.permission.NFC"')) m = m.replace('<application', '<uses-permission android:name="android.permission.NFC" />\n    <application');
  if (!m.includes('android.hardware.nfc')) m = m.replace('<application', '<uses-feature android:name="android.hardware.nfc" android:required="false" />\n    <application');
  if (!m.includes('.GlideNfcService')) {
    m = m.replace('</application>', '<service android:name=".GlideNfcService" android:exported="true" android:permission="android.permission.BIND_NFC_SERVICE"><intent-filter><action android:name="android.nfc.cardemulation.action.HOST_APDU_SERVICE" /><category android:name="android.intent.category.DEFAULT" /></intent-filter><meta-data android:name="android.nfc.cardemulation.host_apdu_service" android:resource="@xml/glide_apdu" /></service>\n    </application>');
  }
  const xmlDir = path.join(androidDir, 'app', 'src', 'main', 'res', 'xml');
  fs.mkdirSync(xmlDir, { recursive: true });
  fs.writeFileSync(path.join(xmlDir, 'glide_apdu.xml'), '<?xml version="1.0" encoding="utf-8"?>\n<host-apdu-service xmlns:android="http://schemas.android.com/apk/res/android" android:description="@string/app_name" android:requireDeviceUnlock="false">\n    <aid-group android:description="@string/app_name" android:category="other">\n        <aid-filter android:name="D2760000850101" />\n    </aid-group>\n</host-apdu-service>\n');
  if (!m.includes('usesCleartextTraffic')) m = m.replace('<application', '<application android:usesCleartextTraffic="true"');
  // background service with a permanent notification (keeps the phone ready while the screen is off)
  if (!m.includes('.GlideService')) {
    m = m.replace('</application>', '<service android:name=".GlideService" android:exported="false" android:foregroundServiceType="connectedDevice" />\n    </application>');
  }
  // let other apps (Gallery, Files, Vivo Share, Quick Share) send files to Glide through the share sheet
  if (!m.includes('android.intent.action.SEND"')) {
    const filters =
      '<intent-filter><action android:name="android.intent.action.SEND" /><category android:name="android.intent.category.DEFAULT" /><data android:mimeType="*/*" /></intent-filter>\n' +
      '        <intent-filter><action android:name="android.intent.action.SEND_MULTIPLE" /><category android:name="android.intent.category.DEFAULT" /><data android:mimeType="*/*" /></intent-filter>\n        ';
    m = m.replace('</activity>', filters + '</activity>');
  }
  fs.writeFileSync(mf, m);

  // 3) saving to Downloads through MediaStore needs Android 10+
  const vf = path.join(androidDir, 'variables.gradle');
  if (fs.existsSync(vf)) {
    fs.writeFileSync(vf, fs.readFileSync(vf, 'utf8').replace(/minSdkVersion\s*=\s*\d+/, 'minSdkVersion = 29'));
  }
}

// App icon (launcher): legacy square + round PNGs and an adaptive icon (navy background + artwork).
function installIcon() {
  const res = path.join(androidDir, 'app', 'src', 'main', 'res');
  const src = path.join(root, 'icons', 'res');
  if (!fs.existsSync(src) || !fs.existsSync(res)) return;
  // the default template may ship .webp icons with the same names: remove them so the PNGs win
  for (const d of fs.readdirSync(res).filter((n) => n.startsWith('mipmap-'))) {
    for (const f of fs.readdirSync(path.join(res, d))) {
      if (/^ic_launcher.*\.webp$/.test(f)) fs.rmSync(path.join(res, d, f), { force: true });
    }
  }
  fs.cpSync(src, res, { recursive: true });
  fs.mkdirSync(path.join(res, 'values'), { recursive: true });
  fs.writeFileSync(path.join(res, 'values', 'glide_icon.xml'),
    '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="glide_icon_bg">#06143E</color>\n</resources>\n');
  const adaptive = '<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n' +
    '    <background android:drawable="@color/glide_icon_bg"/>\n    <foreground android:drawable="@mipmap/glide_icon_fg"/>\n</adaptive-icon>\n';
  // v49: status-bar / notification icon: white shapes on transparent (Android draws it in one colour). Glide's crossing-arrows mark.
  fs.mkdirSync(path.join(res, 'drawable'), { recursive: true });
  fs.writeFileSync(path.join(res, 'drawable', 'ic_stat_glide.xml'),
    '<?xml version="1.0" encoding="utf-8"?>\n<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="24dp" android:height="24dp" android:viewportWidth="24" android:viewportHeight="24">\n' +
    '    <path android:strokeColor="#FFFFFFFF" android:strokeWidth="3.2" android:strokeLineCap="round" android:pathData="M4.5,4.5 L19.5,19.5"/>\n' +
    '    <path android:strokeColor="#FFFFFFFF" android:strokeWidth="3.2" android:strokeLineCap="round" android:pathData="M19.5,4.5 L4.5,19.5"/>\n' +
    '    <path android:fillColor="#FFFFFFFF" android:pathData="M2,2 L9,2 L2,9 Z"/>\n' +
    '    <path android:fillColor="#FFFFFFFF" android:pathData="M22,22 L15,22 L22,15 Z"/>\n' +
    '</vector>\n');
  fs.mkdirSync(path.join(res, 'mipmap-anydpi-v26'), { recursive: true });
  fs.writeFileSync(path.join(res, 'mipmap-anydpi-v26', 'ic_launcher.xml'), adaptive);
  fs.writeFileSync(path.join(res, 'mipmap-anydpi-v26', 'ic_launcher_round.xml'), adaptive);
}

function setup() {
  buildWeb();
  if (!fs.existsSync(path.join(root, 'node_modules'))) run('npm install');
  if (!fs.existsSync(androidDir)) run('npx cap add android');
  patchAndroid();
  installIcon();
  run('npx cap sync android');
}

const cmd = process.argv[2];
if (cmd === 'setup') {
  setup();
  console.log('\nDone. Open the "mobile/android" folder in Android Studio, or run: npm run apk');
} else if (cmd === 'apk') {
  setup();
  run(process.platform === 'win32' ? 'gradlew.bat assembleDebug' : './gradlew assembleDebug', androidDir);
  const apk = path.join(androidDir, 'app', 'build', 'outputs', 'apk', 'debug', 'app-debug.apk');
  console.log(`\nAPK ready: ${apk}`);
} else {
  console.log('Usage: node scripts/android.js setup|apk');
  process.exit(1);
}
