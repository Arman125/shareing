'use strict';
const $ = (s) => document.querySelector(s);
// Bigger chunks + a deep send buffer keep the data channel saturated (much faster on LAN).
// 256 KB is the largest message size every Chromium-based WebRTC stack accepts.
// Chromium closes a channel whose send queue passes ~16 MB, so stay well under that.
const CHUNK = 256 * 1024;
const MAX_BUFFER = 8 * 1024 * 1024;
const LOW_BUFFER = 2 * 1024 * 1024;
const ACK_WIN = 2 * 1024 * 1024; // v45: at most this much sent to one device that has not confirmed it yet (keeps one slow device from blocking the others)
const ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
const COLORS = ['#8f7cf5', '#f2907a', '#4fbfd0', '#e77fb0', '#6fbf8f', '#e8b04f'];

const state = {
  staged: [],
  peers: [],
  transfers: new Map(),
  incoming: [],
  room: { code: '', ws: null, status: 'idle', mode: '', url: '', myId: 0, joined: false, standby: false, peers: new Map() },
};

/* ---------- helpers ---------- */
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
function fmt(b) {
  if (b < 1024) return `${b} B`;
  const u = ['KB', 'MB', 'GB', 'TB'];
  let i = -1;
  do { b /= 1024; i++; } while (b >= 1024 && i < u.length - 1);
  return `${b.toFixed(b >= 100 ? 0 : 1)} ${u[i]}`;
}
function colorFor(s) {
  let h = 0;
  for (const c of s) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  return COLORS[h % COLORS.length];
}
const uuid = () => (crypto.randomUUID ? /*compat-ok*/ crypto.randomUUID()
  : [...crypto.getRandomValues(new Uint8Array(16))].map((b) => b.toString(16).padStart(2, '0')).join(''));
async function copyText(text) {
  try { await navigator.clipboard.writeText(text); return true; } catch {}
  try { // plain http pages have no clipboard API
    const t = document.createElement('textarea');
    t.value = text; t.style.position = 'fixed'; t.style.opacity = '0';
    document.body.appendChild(t); t.select();
    const ok = document.execCommand('copy');
    t.remove();
    return ok;
  } catch { return false; }
}
let toastTimer;
function toast(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (t.hidden = true), 3200);
}
function load(key, fallback) { try { return localStorage.getItem(key) || fallback; } catch { return fallback; } }
function store(key, val) { try { localStorage.setItem(key, val); } catch {} }

/* ---------- navigation ---------- */
document.querySelectorAll('nav button').forEach((b) => {
  b.onclick = () => showView(b.dataset.view);
});
function showView(v) {
  document.querySelectorAll('nav button').forEach((b) => b.classList.toggle('on', b.dataset.view === v));
  ['nearby', 'online', 'transfers'].forEach((n) => ($('#v-' + n).hidden = n !== v));
}

/* ---------- staged files ---------- */
async function addFiles(list) {
  for (const f of list) {
    if (f && !state.staged.some((s) => s.path === f.path)) state.staged.push(f);
  }
  renderStaged();
}
function renderStaged() {
  const n = state.staged.length;
  $('#drop-title').textContent = n ? `${n} file${n > 1 ? 's' : ''} ready` : 'Drop files to send';
  $('#drop-sub').textContent = n
    ? (state.room.status === 'live' && !$('#v-online').hidden ? 'Press Send files to share them.' : 'Pick who should get them.')
    : 'Anything, any size.';
  $('#send-top').hidden = !n; // v40: Send button in the drop bar, only while files are staged
  $('#chips').innerHTML = state.staged
    .map((f, i) => `<div class="chip"><span>${esc(f.name)}</span><small>${fmt(f.size)}</small><button data-i="${i}" aria-label="Remove ${esc(f.name)}">×</button></div>`)
    .join('');
  $('#chips').querySelectorAll('button').forEach((b) => {
    b.onclick = () => { state.staged.splice(Number(b.dataset.i), 1); renderStaged(); };
  });
}
$('#choose').onclick = async () => {
  try {
    addFiles(await api.pickFiles());
    // connected online and on the Online screen: sending right away is what people expect
    if (room && room.status === 'live' && !$('#v-online').hidden && state.staged.length) sendStagedOnline();
  } catch (e) { toast(`Could not open the file picker: ${String((e && e.message) || e)}`); }
};

const drop = $('#drop');
window.addEventListener('dragover', (e) => { e.preventDefault(); drop.classList.add('over'); });
window.addEventListener('dragleave', (e) => { if (!e.relatedTarget) drop.classList.remove('over'); });
window.addEventListener('drop', async (e) => {
  e.preventDefault();
  drop.classList.remove('over');
  const out = [];
  for (const f of e.dataTransfer.files) {
    const info = await api.statFile(api.pathOf(f));
    if (info) out.push(info);
  }
  if (out.length) addFiles(out);
  else toast('Folders are not supported yet. Drop files instead.');
});

/* ---------- files shared into Glide from other apps (Android share sheet, Vivo Share) ---------- */
if (api.onSharedFiles) {
  api.onSharedFiles((list) => {
    if (!list || !list.length) return;
    addFiles(list);
    const nearbyOk = api.platform === 'android';
    showView(nearbyOk ? 'nearby' : 'online');
    toast(`${list.length} file${list.length > 1 ? 's' : ''} added. ${nearbyOk ? 'Tap a device to send.' : 'Connect, then press Send files.'}`);
  });
}

/* ---------- nearby ---------- */
api.onPeers((list) => { state.peers = list; renderPeers(); });
function renderPeers() {
  const box = $('#peers');
  $('#radar').hidden = state.peers.length > 0;
  box.innerHTML = state.peers
    .map((p) => `<button class="peer" data-id="${esc(p.id)}">
        <div class="avatar" style="background:${colorFor(p.id)}">${esc((p.name[0] || '?').toUpperCase())}</div>
        <b>${esc(p.name)}</b><small>${esc(p.ip)}</small></button>`)
    .join('');
  box.querySelectorAll('.peer').forEach((b) => (b.onclick = () => sendNearby(b.dataset.id)));
}
async function sendNearby(peerId) {
  if (!state.staged.length) addFiles(await api.pickFiles());
  if (!state.staged.length) return;
  const files = state.staged.splice(0);
  renderStaged();
  toast(`Sending ${files.length} file${files.length > 1 ? 's' : ''}…`);
  for (const f of files) await api.lanSend(peerId, f.path);
}

/* ---------- incoming requests (both nearby and online) ---------- */
api.onIncoming((r) => askIncoming({ ...r, cb: (ok) => api.respond(r.id, ok) }));
api.onIncomingCancel((id) => { state.incoming = state.incoming.filter((r) => r.id !== id); renderModal(); });
const swarmOn = () => load('glide.swarm', '0') === '1';
const SW_CS = 64 * 1024;          // swarm piece size
const SW_PIPE = 16, SW_TIMEOUT = 6000; // requests in flight per device (was 4), and how long to wait for a piece before asking again
const swOut = (s, pid) => { let n = 0; for (const f of s.inflight.values()) if (f.pid === pid) n++; return n; }; // counted, never stored, so it cannot drift
const SW_AHEAD = 1024, SW_KEEP = 512; // a device asks only for the next 64 MB of pieces and keeps the last 32 MB for others, so any file size works
const autoAccept = () => load('glide.autoaccept', '0') === '1';
function askIncoming(r) {
  if (autoAccept()) { // owner's option "Accept all files automatically": no question, no modal
    toast(`Receiving ${r.name} from ${r.from}`);
    Promise.resolve().then(() => r.cb(true)).catch((e) => toast(`Could not start receiving: ${(e && e.message) || e}`));
    return;
  }
  state.incoming.push(r); renderModal();
}
function renderModal() {
  const r = state.incoming[0];
  $('#scrim').hidden = !r;
  if (!r) return;
  if (document.hidden && api.notifyIncoming && !r.notified) { // app is in the background: pop up a notification
    r.notified = true;
    api.notifyIncoming(`${r.from} wants to send you a file`, `${r.name} (${fmt(r.size)}). Tap to accept.`);
  }
  $('#m-title').textContent = `${r.from} wants to send you a file`;
  $('#m-sub').textContent = `${r.name} (${fmt(r.size)})`;
}
$('#m-yes').onclick = () => answer(true);
$('#m-no').onclick = () => answer(false);
function answer(ok) {
  const r = state.incoming.shift();
  if (r) Promise.resolve().then(() => r.cb(ok)).catch((e) => toast(`Could not start receiving: ${(e && e.message) || e}`));
  renderModal();
}

/* ---------- transfers ---------- */
api.onTransfer((t) => setTransfer(t));
const ACTIVE = ['sending', 'receiving'];
/* v48: "busy" = connected / connecting, or a file is moving. While busy the device must keep working with the screen off:
   Android app = wake lock + Wi-Fi lock + foreground service, browser = screen wake lock + silent audio + Web Lock (see platform.js setBusy). */
var busyRoom = false, busyXfer = false, busyNow = null;
function updateBusy() {
  const b = busyRoom || busyXfer;
  if (b === busyNow) return;
  busyNow = b;
  if (api.setBusy) api.setBusy(b);
  if (b) bgAsk();
  if (!b && api.keepService) setTimeout(() => { if (!busyNow) applyNotif(); }, 500); // back to the user's "notification" option after the transfer
}
const fmtSpeed = (bps) => (bps >= 1024 * 1024 ? `${(bps / 1048576).toFixed(bps >= 10485760 ? 1 : 2)} MB/s` : `${Math.round(bps / 1024)} KB/s`);
const fmtMbps = (bps) => `${Math.round((bps * 8) / 1e6)} Mbps`;
function fmtEta(sec) {
  if (!isFinite(sec) || sec < 0) return '';
  if (sec < 60) return `${Math.max(1, Math.round(sec))}s left`;
  if (sec < 3600) return `${Math.floor(sec / 60)}m ${Math.round(sec % 60)}s left`;
  return `${Math.floor(sec / 3600)}h ${Math.round((sec % 3600) / 60)}m left`;
}
// Measure speed over >= 0.5 s windows and smooth it so the number does not jump around.
function sample(t, now) {
  const dt = (now - t.lastT) / 1000;
  if (dt < 0.5) return;
  const inst = Math.max(0, (t.done || 0) - t.lastDone) / dt;
  t.speed = t.speed ? t.speed * 0.6 + inst * 0.4 : inst;
  t.lastT = now;
  t.lastDone = t.done || 0;
}
const cancelHooks = new Map(); // transfer id -> function that stops it (only online transfers have one)
const outJobs = new Map(); // transfer id -> sending job
function setTransfer(patch) {
  const cur0 = state.transfers.get(patch.id);
  if (cur0 && cur0.status === 'cancelled') return; // a cancelled transfer stays cancelled
  const t = { ...(state.transfers.get(patch.id) || {}), ...patch };
  const now = performance.now();
  if (ACTIVE.includes(t.status)) {
    if (!t.t0) { t.t0 = now; t.lastT = now; t.lastDone = t.done || 0; t.baseDone = t.done || 0; t.speed = 0; }
    else sample(t, now);
  } else {
    if (t.status === 'done' && t.t0 && t.avg === undefined) {
      const secs = (now - t.t0) / 1000;
      t.avg = secs >= 0.4 ? Math.max(0, (t.size || 0) - (t.baseDone || 0)) / secs : 0;
    }
    t.speed = 0;
  }
  state.transfers.set(t.id, t);
  scheduleRender();
}
// Keeps the meter honest when data stops flowing (speed falls toward 0) and drives the floating pill.
setInterval(() => {
  const now = performance.now();
  let up = 0, down = 0, any = false, anyAll = false;
  for (const t of state.transfers.values()) {
    if (!ACTIVE.includes(t.status)) continue;
    sample(t, now); // keeps each row's own speed fresh
    anyAll = true;
    if (String(t.via || '').startsWith('Swarm')) continue; // swarm has its own numbers (spd.sw)
    any = true;
    if (t.dir === 'out') up += t.speed || 0; else down += t.speed || 0;
  }
  spd.normalNow = any ? up + down : 0;
  busyXfer = anyAll; updateBusy();
  if (anyAll) scheduleRender();
}, 700);

/* ---------- top speed bar (v46b): Total / Original / Swarm, each with now, max, min and the amount moved ----------
   Original = normal one-to-one transfers. Swarm = pieces moving for a swarm (both directions of this device). Total = both.
   One session = until 20 s without any traffic; the next traffic starts new numbers. */
const spd = {
  orig: { now: 0, max: 0, min: 0, bytes: 0, last: 0 }, sw: { now: 0, max: 0, min: 0, bytes: 0, last: 0 }, all: { now: 0, max: 0, min: 0, bytes: 0, last: 0 },
  lastT: 0, normalNow: 0, swSeedNow: 0,
};
function spdStep(k, now, dt) {
  const e = spd[k];
  if (now > 0) {
    if (!e.last || performance.now() - e.last > 20000) { e.max = 0; e.min = 0; e.bytes = 0; }
    e.last = performance.now();
    e.bytes += now * dt;
    if (now > e.max) e.max = now;
    if (now >= 1024 && (!e.min || now < e.min)) e.min = now; // lowest speed while data was really flowing
  }
}
setInterval(() => {
  const t = performance.now(), dt = spd.lastT ? Math.min(2, (t - spd.lastT) / 1000) : 0.7;
  spd.lastT = t;
  spd.orig.now = spd.normalNow + spd.swSeedNow;
  spd.all.now = spd.orig.now + spd.sw.now;
  for (const k of ['orig', 'sw', 'all']) spdStep(k, spd[k].now, dt);
  const bar = $('#topspd');
  if (!bar) return;
  const show = ['orig', 'sw', 'all'].some((k) => spd[k].last && t - spd[k].last < 20000);
  bar.hidden = !show;
  if (!show) return;
  const tile = (k, title, cls) => {
    const e = spd[k], idle = !e.last || t - e.last > 3000;
    return `<div class="ts ${cls}${idle ? ' idle' : ''}"><div class="ts-h">${title}</div><div class="ts-n">${fmtSpeed(e.now)}<small> ${fmtMbps(e.now)}</small></div>`
      + `<div class="ts-s"><span>max <b>${fmtSpeed(e.max)}</b></span><span>min <b>${e.min ? fmtSpeed(e.min) : '–'}</b></span><span>total <b>${fmt(e.bytes)}</b></span></div></div>`;
  };
  bar.innerHTML = tile('all', 'Total speed', 'ts-all') + tile('orig', 'Original speed · from sender', 'ts-orig') + tile('sw', 'Swarm speed · device to device', 'ts-sw');
}, 700);
let raf = 0;
function scheduleRender() { if (!raf) raf = requestAnimationFrame(() => { raf = 0; renderTransfers(); }); }
const LABEL = {
  waiting: 'Waiting for a reply', sending: 'Sending', receiving: 'Receiving',
  done: 'Done', declined: 'Declined', failed: 'Failed', cancelled: 'Cancelled',
};
function renderTransfers() {
  const all = [...state.transfers.values()].reverse();
  const active = all.filter((t) => ['waiting', 'sending', 'receiving'].includes(t.status)).length;
  const badge = $('#badge');
  badge.hidden = !active;
  badge.textContent = active;
  $('#tlist').innerHTML = all.length
    ? all.map((t) => {
        const pct = t.size ? Math.min(100, Math.round(((t.done || 0) / t.size) * 100)) : (t.status === 'done' ? 100 : 0);
        const who = t.dir === 'out' ? `to ${esc(t.peer)}` : `from ${esc(t.peer)}`;
        const live = ACTIVE.includes(t.status);
        const extra = live ? ` ${pct}%` : '';
        const speedTxt = live
          ? ` · <span class="t-speed">${fmtSpeed(t.speed || 0)}</span>${t.speed > 20480 && t.size ? ' · ' + fmtEta(((t.size - (t.done || 0)) / t.speed)) : ''}`
          : (t.status === 'done' && t.avg ? ` · avg <span class="t-speed">${fmtSpeed(t.avg)}</span>` : '');
        const tag = t.dir === 'in' && window.GlideTypes ? `<span class="t-type">${esc(GlideTypes.folderOf(t.name))}</span>` : '';
        const canShare = t.status === 'done' && t.dir === 'in' && t.path && api.shareFile;
        const open = t.status === 'done' && t.path
          ? `<span class="t-actions">${canShare ? `<button class="link" data-s="${esc(t.path)}">Share…</button>` : ''}<button class="link" data-p="${esc(t.path)}">Show in folder</button></span>` : '';
        const stop = ['waiting', 'sending', 'receiving'].includes(t.status) && cancelHooks.has(t.id) ? `<span class="t-actions"><button class="link" data-c="${esc(t.id)}">Cancel</button></span>` : '';
        return `<div class="t ${t.status}">
          <div class="t-top"><b>${esc(t.name)}</b>${tag}<span>${fmt(t.size)}</span></div>
          <div class="bar"><i style="width:${pct}%"></i></div>
          <div class="t-meta"><span>${LABEL[t.status] || t.status}${extra} · ${who}${speedTxt}${t.via ? ` · <span class="t-via">${esc(t.via)}</span>` : ''}${t.error ? ` · <span class="t-err">${esc(t.error)}</span>` : ''}</span>${open}${stop}</div></div>`;
      }).join('')
    : '<div class="empty">Nothing sent or received yet.</div>';
  $('#tlist').querySelectorAll('[data-p]').forEach((b) => (b.onclick = () => api.showInFolder(b.dataset.p)));
  $('#tlist').querySelectorAll('[data-s]').forEach((b) => (b.onclick = () => api.shareFile(b.dataset.s)));
}

function cancelTransfer(id) {
  const t = state.transfers.get(id);
  if (!t || !['waiting', 'sending', 'receiving'].includes(t.status)) return;
  const h = cancelHooks.get(id);
  if (!h) return toast('This transfer cannot be cancelled.');
  cancelHooks.delete(id);
  try { h(); } catch {}
  setTransfer({ id, status: 'cancelled' });
}
// The list is rebuilt many times a second, so a plain click on a button can get lost: react to press + release instead.
(function () {
  const tl = $('#tlist');
  let armed = '';
  const idOf = (e) => { const b = e.target && e.target.closest && e.target.closest('[data-c]'); return b ? b.dataset.c : ''; };
  tl.addEventListener('pointerdown', (e) => { armed = idOf(e); });
  tl.addEventListener('pointerup', (e) => { const id = idOf(e); if (armed && id === armed) cancelTransfer(id); armed = ''; });
  tl.addEventListener('pointercancel', () => { armed = ''; });
  tl.addEventListener('click', (e) => { const id = idOf(e); if (id) cancelTransfer(id); }); // browsers without pointer events
})();

/* ---------- online sharing (WebRTC): several devices at once, remembered devices, fixed code ---------- */
const room = state.room;
const waiters = new Map(); // transfer id -> { r, pid }
function makeCode() {
  let s;
  do { // always at least one letter
    const a = crypto.getRandomValues(new Uint8Array(6));
    s = [...a].map((x) => ALPHABET[x % ALPHABET.length]).join('');
  } while (!/[A-Z]/.test(s));
  return s.slice(0, 3) + '-' + s.slice(3);
}
function makeHomeCode() {
  let s;
  do {
    const a = crypto.getRandomValues(new Uint8Array(8));
    s = [...a].map((x) => ALPHABET[x % ALPHABET.length]).join('');
  } while (!/[A-Z]/.test(s));
  return s;
}
const cleanCode = (c) => c.toUpperCase().replace(/[^A-Z0-9]/g, '');
const dash = (c) => (c.length > 3 ? c.slice(0, 3) + '-' + c.slice(3) : c);

/* The fixed code of this device ("home code"), the always-ready switch and the remembered devices. */
const HOME_KEY = 'glide.home', ON_KEY = 'glide.standby', SAVED_KEY = 'glide.saved';
function getHome() {
  let c = cleanCode(load(HOME_KEY, ''));
  if (!c) { c = makeHomeCode(); store(HOME_KEY, c); }
  return c;
}
const standbyOn = () => load(ON_KEY, api.platform === 'web' ? '0' : '1') === '1';
function getSaved() { try { const a = JSON.parse(load(SAVED_KEY, '[]')); return Array.isArray(a) ? a : []; } catch { return []; } }
function putSaved(a) { store(SAVED_KEY, JSON.stringify(a.slice(0, 30))); }
function saveDevice(name, home, server) {
  if (!home || home === getHome()) return;
  const a = getSaved().filter((d) => d.home !== home);
  a.unshift({ name, home, server, at: Date.now() });
  putSaved(a);
  renderSaved();
}
function renderSaved() {
  const a = getSaved();
  $('#saved').hidden = !a.length;
  $('#saved-list').innerHTML = a.map((d, i) => `<div class="row saved-item"><button class="btn" data-c="${i}">Connect to ${esc(d.name)}</button><button class="link" data-f="${i}">Forget</button></div>`).join('');
  $('#saved-list').querySelectorAll('[data-c]').forEach((b) => {
    b.onclick = () => { const d = getSaved()[Number(b.dataset.c)]; if (d) startRoom('enter', d.home, { server: d.server, saved: d.name }); };
  });
  $('#saved-list').querySelectorAll('[data-f]').forEach((b) => {
    b.onclick = () => { const a2 = getSaved(); a2.splice(Number(b.dataset.f), 1); putSaved(a2); renderSaved(); };
  });
}
function paintHome() {
  const on = standbyOn();
  $('#home-on').checked = on;
  $('#home-code').value = getHome();
  const ready = on && room.standby && room.joined;
  $('#home-dot').className = 'dot' + (ready ? ' on' : '');
  $('#home-title').textContent = ready ? 'Always ready' : on ? 'Getting ready…' : 'Always ready is off';
  $('#home-msg').textContent = on
    ? 'Devices that saved this device connect with one tap. No new code each time.'
    : 'Turn this on so saved devices can reach this device without a code.';
}

function setRoomStatus(s) {
  room.status = s;
  busyRoom = s === 'live' || s === 'connecting' || s === 'waiting'; updateBusy();
  $('#on-idle').hidden = !(s === 'idle' || s === 'standby');
  $('#on-wait').hidden = !(s === 'waiting' || s === 'connecting');
  $('#on-live').hidden = s !== 'live';
  $('#wait-title').textContent = s === 'connecting' ? 'Connecting…' : 'Waiting for the other person';
  paintHome();
  renderStaged();
}
/* the host of this room: it said so itself (hello.host), or it waits in the room we entered (older versions) */
const hostIdOn = () => load('glide.hostid', '1') !== '0'; // option "Recognise the host": default ON everywhere (apps and web), only '0' (user unticked it) turns it off (v40)
/* Exactly ONE device can be the host (v38; before, two devices could be labelled when one had the flag and another matched the home code).
   Order: the device the server says announced itself (whois) > a device that flagged hello.host > a device waiting in the room we entered. */
function hostPeer() {
  if (!hostIdOn()) return null;
  const ps = [...room.peers.values()].sort((x, y) => x.id - y.id);
  let c = [];
  if (room.hostHome) c = ps.filter((p) => p.home && p.home === room.hostHome);
  if (!c.length) c = ps.filter((p) => p.isHost);
  if (!c.length) c = ps.filter((p) => p.home && room.code && p.home === cleanCode(String(room.code)));
  return c[0] || null;
}
const isHostPeer = (p) => !!p && hostPeer() === p;
/* the two options in the Online page */
(function () {
  const sv = $('#opt-swarm');
  if (sv) { sv.checked = swarmOn(); sv.onchange = () => store('glide.swarm', sv.checked ? '1' : '0'); }
  const h = $('#opt-host'), au = $('#opt-auto');
  if (h) { h.checked = hostIdOn(); h.onchange = () => { store('glide.hostid', h.checked ? '1' : '0'); renderLivePeers(); }; }
  if (au) {
    au.checked = autoAccept();
    au.onchange = () => {
      store('glide.autoaccept', au.checked ? '1' : '0');
      if (au.checked) { while (state.incoming.length) answer(true); } // answer what is already waiting
    };
  }
})();
function renderLivePeers() {
  const box = $('#live-peers');
  const ps = [...room.peers.values()].filter((p) => p.live);
  box.innerHTML = ps.map((p) => `<label class="check"><input type="checkbox" data-id="${p.id}" ${p.sel ? 'checked' : ''}> ${esc(p.name)}${isHostPeer(p) ? ' <small>(host)</small>' : ''}</label>`).join('');
  box.querySelectorAll('input').forEach((i) => {
    i.onchange = () => { const p = room.peers.get(Number(i.dataset.id)); if (p) p.sel = i.checked; };
  });
  $('#live-title').textContent = ps.length > 1 ? `Connected to ${ps.length} devices` : 'Connected';
}
function refreshRoomStatus() {
  if (!room.ws) return;
  const ps = [...room.peers.values()];
  let s;
  if (ps.some((p) => p.live)) s = 'live';
  else if (ps.length || (room.mode === 'join' && !room.joined)) s = 'connecting';
  else s = room.standby ? 'standby' : 'waiting';
  if (s !== room.status) setRoomStatus(s); else paintHome();
  renderLivePeers();
}
function dropPeer(p, msg) {
  if (room.peers.get(p.id) !== p) return;
  clearTimeout(p.timer); clearTimeout(p.relayTimer);
  room.peers.delete(p.id);
  state.incoming = state.incoming.filter((r) => r.pid !== p.id); renderModal(); // no question for a device that is gone
  try { p.dc && p.dc.close(); } catch {}
  try { p.pc && p.pc.close(); } catch {}
  p.pc = null;
  for (const [k, w] of waiters) if (w.pid === p.id) { waiters.delete(k); w.r(null); }
  if (msg) toast(msg);
  if (!room.peers.size && room.mode === 'join') return closeRoom();
  refreshRoomStatus();
}
function closeRoom(silent) {
  for (const p of [...room.peers.values()]) {
    clearTimeout(p.timer); clearTimeout(p.relayTimer);
    try { p.dc && p.dc.close(); } catch {}
    try { p.pc && p.pc.close(); } catch {}
    p.pc = null;
  }
  room.peers = new Map();
  const ws = room.ws;
  room.ws = null; room.joined = false; room.myId = 0;
  try { ws && ws.close(); } catch {}
  for (const [, w] of waiters) w.r(false);
  waiters.clear();
  if (!silent) { setRoomStatus('idle'); setTimeout(ensureStandby, 300); }
}
// Keeps this device "always ready": it waits in its own fixed-code room so saved devices can connect with one tap.
const NOTIF_KEY = 'glide.notif';
function applyNotif() {
  if (!api.keepService) return;
  $('#notif-row').hidden = false;
  const on = load(NOTIF_KEY, '1') === '1';
  $('#notif-on').checked = on;
  api.keepService(on, 'Ready to share files');
}
// v49 (Android app): Android and the phone maker (Xiaomi, Oppo, Samsung ...) stop apps in the background unless the user allows it.
async function paintBg() {
  if (!api.bgStatus) return;
  const s = await api.bgStatus();
  $('#bg-row').hidden = false;
  $('#bg-msg').textContent = s.ignoring
    ? 'Background use is allowed. Glide can keep sending with the screen off.'
    : 'Android may stop Glide when the screen is off. Tap Allow background (choose "Allow"). On Xiaomi also open Autostart settings and turn Glide on, and set Battery saver to "No restrictions".';
  $('#bg-battery').hidden = !!s.ignoring;
  $('#bg-auto').hidden = !/xiaomi|redmi|poco/.test(s.maker || '');
}
async function bgAsk() { // the first time something is sent, ask once
  if (!api.bgStatus || load('glide.bgasked', '0') === '1') return;
  const s = await api.bgStatus();
  store('glide.bgasked', '1');
  if (!s.ignoring) { toast('Allow Glide to run in the background, so sending continues with the screen off.'); api.bgOpen('battery'); }
}
if ($('#bg-battery')) {
  $('#bg-battery').onclick = async () => { await api.bgOpen('battery'); setTimeout(paintBg, 1500); };
  $('#bg-auto').onclick = () => api.bgOpen('autostart');
  document.addEventListener('visibilitychange', () => { if (!document.hidden) paintBg(); });
  setTimeout(paintBg, 800);
}
$('#notif-on').onchange = (e) => { store(NOTIF_KEY, e.target.checked ? '1' : '0'); applyNotif(); };
let sbTimer = 0;
function ensureStandby() {
  clearTimeout(sbTimer);
  if (room.ws || !standbyOn()) { paintHome(); return; }
  const ok = startRoom('enter', getHome(), { standby: true, quiet: true });
  if (ok === false) sbTimer = setTimeout(ensureStandby, 5000);
}
/* Phone that joined someone's hotspot: finds the hosting phone by itself and connects, nothing to open or type. */
let autoPaused = false, autoGw = '', autoBusy = false;
function probeInfo(url) {
  return new Promise((resolve) => {
    let done = false, w;
    const none = { home: '', name: '' };
    const end = (v) => { if (!done) { done = true; clearTimeout(t); try { w && w.close(); } catch {} resolve(v); } };
    const t = setTimeout(() => end(none), 2500);
    try { w = new WebSocket(url); } catch { return end(none); }
    w.onopen = () => w.send(JSON.stringify({ type: 'whois' }));
    w.onmessage = (e) => { try { const m = JSON.parse(e.data); end(m.type === 'whois' ? { home: m.home || '', name: m.name || '' } : none); } catch { end(none); } };
    w.onerror = () => end(none);
  });
}
const probeHost = async (url) => (await probeInfo(url)).home;

/* Type a device NAME instead of an IP in Server address (for example "chachi" or "chachi:8080"):
   the app finds the IP by itself, from the remembered devices or from the phone whose hotspot this phone joined. */
const keyOf = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
let lastAlias = null;
function looksLikeName(v) {
  v = String(v || '').trim();
  if (!v || /^(wss?|https?):\/\//i.test(v)) return false;
  const host = v.replace(/:\d+$/, '');
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host) || /^localhost$/i.test(host) || host.includes('.')) return false;
  return true;
}
async function resolveAlias(v) {
  const k = keyOf(String(v).trim().replace(/:\d+$/, ''));
  const s = getSaved().find((d) => keyOf(d.name) === k);
  if (s) return { server: s.server, home: s.home, name: s.name };
  if (api.gateway) {
    const gw = await api.gateway();
    if (gw) {
      const server = `ws://${gw}:8080`;
      const i = await probeInfo(server);
      if (i.home && keyOf(i.name) === k) return { server, home: i.home, name: i.name };
    }
  }
  return null;
}
async function applyServerField() { // false = a name was typed but not found
  lastAlias = null;
  const raw = $('#server').value;
  if (!looksLikeName(raw)) return true;
  const r = await resolveAlias(raw);
  if (!r) { toast(`Cannot find "${raw.trim()}". Join the same hotspot with Glide open on that phone, or type its IP.`); return false; }
  lastAlias = r;
  $('#server').value = r.server;
  store('glide.server.v2', r.server);
  toast(`${r.name} found: ${r.server.replace(/^ws:\/\//, '')}`);
  return true;
}
async function autoFind() {
  if (!api.gateway || autoBusy) return;
  if (room.peers.size || !['idle', 'standby'].includes(room.status)) return;
  autoBusy = true;
  try {
    const gw = await api.gateway();
    if (gw !== autoGw) { autoGw = gw; autoPaused = false; } // joined a different Wi-Fi: try again
    if (!gw || autoPaused) return;
    const server = `ws://${gw}:8080`;
    const home = await probeHost(server);
    if (home && home !== getHome() && !room.peers.size && ['idle', 'standby'].includes(room.status)) {
      startRoom('enter', home, { server, saved: 'the host phone', auto: true });
    }
  } finally { autoBusy = false; }
}
setInterval(() => { if (!document.hidden) autoFind().catch(() => {}); }, 5000);
let refreshLan = async () => {}; // set by initHostBox: re-reads this device's Wi-Fi / hotspot addresses
let hostRunning = false; // this device is running its own session server (PC app or phone)
const IS_DESKTOP = api.platform === 'desktop';
const IS_WEB = api.platform === 'web';
let iceExtra = []; // optional TURN relay announced by the server (see README)
if (IS_WEB) fetch('/ice').then((r) => r.json()).then((a) => { if (Array.isArray(a)) iceExtra = a; }).catch(() => {});
// On the website the server is the site itself, so there is nothing to type.
const ORIGIN_WS = (location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host;
// Accepts "192.168.0.5", "192.168.0.5:8080", "ws://192.168.0.5", "https://my-site.onrender.com" or "my-site.onrender.com"
// and turns it into a ws:// or wss:// address.
function normalizeWs(v) {
  v = String(v || '').trim().replace(/\/+$/, '');
  if (!v) return '';
  if (/^https:\/\//i.test(v)) v = 'wss://' + v.slice(8);
  else if (/^http:\/\//i.test(v)) v = 'ws://' + v.slice(7);
  else if (!/^wss?:\/\//i.test(v)) {
    // bare address: IP / localhost -> ws:// ; a domain name -> wss:// (hosted websites use https)
    v = (/^([\d.]+|localhost)(:\d+)?$/i.test(v) ? 'ws://' : 'wss://') + v;
  }
  if (/^ws:\/\/([\d.]+|localhost)$/i.test(v)) v += ':8080';
  return v;
}
const isLocalAddr = (v) => /^wss?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/i.test(String(v || '').trim());
/* True when THIS device runs the server it is connected to (PC app / Android app talking to its own server; a browser tab is never the host).
   Sent in `hello` as host:true, so every other device knows who the host is, whatever kind of room it is (code, QR, home room). */
const amHost = () => { try { return !!(hostRunning && isLocalAddr(room.url)); } catch (e) { return false; } }; // only the app that RUNS the server; a browser tab on localhost is not the host
// Only an address the user typed is remembered; the PC app falls back to its own built-in server.
// A phone can never use "localhost" (that is the phone itself), so that value is ignored there.
function defaultServer() {
  if (IS_WEB) return ORIGIN_WS;
  let saved = load('glide.server.v2', '');
  if (!IS_DESKTOP && !api.serverInfo && isLocalAddr(saved)) saved = '';
  return saved || normalizeWs(window.GLIDE_SERVER) || (IS_DESKTOP || api.serverInfo ? 'ws://localhost:8080' : '');
}
$('#server').value = defaultServer();
if (IS_WEB) $('#server-details').hidden = true;

// Link that opens the website and joins this session by itself (also what the QR code holds).
function shareUrl(code, serverUrl) {
  let base;
  if (IS_WEB) {
    base = ON_LOCALHOST ? (state.webLan[lanPick] || '') : location.origin; // localhost in a QR is useless for the other phone
    if (!base) return '';
  } else {
    let u;
    try { u = new URL((serverUrl || $('#server').value).trim().replace(/^ws/, 'http')); } catch { return ''; }
    if (/^(localhost|127\.0\.0\.1)$/.test(u.hostname)) {
      if (!(state.lan && state.lan.length)) return ''; // localhost in a QR is useless for the other phone
      const rank = (x) => (/^http:\/\/192\.168\./.test(x) ? 0 : /^http:\/\/(10|172)\./.test(x) ? 1 : 2);
      u = new URL([...state.lan].sort((a, b) => rank(a) - rank(b))[0]);
    }
    base = u.origin;
  }
  return `${base}/?code=${cleanCode(code)}`;
}
/* ---------- website opened as "localhost": show the address other phones must use ---------- */
// "localhost" always means the device itself, so another phone can never use it. The server
// (Node or the Android host) reports its real Wi-Fi / hotspot address at /lan; the banner shows it
// with a QR, and the share link / QR of a new code use it instead of localhost.
const ON_LOCALHOST = IS_WEB && /^(localhost|127\.0\.0\.1|\[::1\])$/i.test(location.hostname);
state.webLan = [];
let lanPick = 0;
function paintLanBanner() {
  const box = $('#lan-banner');
  if (!ON_LOCALHOST) { box.hidden = true; return; }
  box.hidden = false;
  const urls = state.webLan;
  if (lanPick >= urls.length) lanPick = 0;
  const has = urls.length > 0;
  $('#lan-msg').textContent = has
    ? 'Connect the other phone to the same Wi-Fi or to this phone\'s hotspot, then scan the QR or type this address in its browser. "localhost" only works on this device.'
    : 'No Wi-Fi or hotspot address found. Connect to Wi-Fi, or turn on the hotspot and join it from the other phone.';
  const pick = $('#lan-addrs');
  pick.innerHTML = urls.length > 1
    ? urls.map((u, i) => `<button type="button" data-i="${i}" class="${i === lanPick ? 'on' : ''}">${esc(u.replace(/^https?:\/\//, ''))}</button>`).join('')
    : '';
  pick.querySelectorAll('button').forEach((b) => { b.onclick = () => { lanPick = Number(b.dataset.i); paintLanBanner(); }; });
  $('#lan-url').textContent = has ? urls[lanPick] : '';
  $('#lan-url').hidden = !has;
  $('#lan-copy').hidden = !has;
  $('#lan-copy').onclick = async () => toast((await copyText(urls[lanPick])) ? 'Address copied' : 'Could not copy. Select it instead.');
  const qr = $('#lan-qr');
  qr.hidden = true;
  if (has && window.QR) { try { qr.innerHTML = QR.svg(urls[lanPick]); qr.hidden = false; } catch {} }
}
let lanKey = '';
async function refreshWebLan() {
  if (!ON_LOCALHOST) return;
  let urls = [];
  try { const j = await (await fetch('/lan', { cache: 'no-store' })).json(); if (j && Array.isArray(j.urls)) urls = j.urls; } catch {}
  const key = urls.join('|');
  state.webLan = urls;
  if (key !== lanKey) { lanKey = key; paintLanBanner(); }
}
if (ON_LOCALHOST) {
  paintLanBanner();
  refreshWebLan();
  setInterval(() => { if (!document.hidden) refreshWebLan(); }, 3000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) refreshWebLan(); });
}

$('#server').onchange = async () => {
  if (looksLikeName($('#server').value)) { await applyServerField(); return; }
  lastAlias = null;
  $('#server').value = normalizeWs($('#server').value);
  store('glide.server.v2', $('#server').value);
  if (!room.peers.size && room.standby) { closeRoom(true); setRoomStatus('idle'); ensureStandby(); }
};
$('#code-in').oninput = (e) => { e.target.value = dash(cleanCode(e.target.value).slice(0, 12)); };
$('#code-custom').oninput = (e) => { e.target.value = dash(cleanCode(e.target.value).slice(0, 6)); };
$('#home-code').oninput = (e) => { e.target.value = cleanCode(e.target.value).slice(0, 12); };
$('#home-save').onclick = () => {
  const c = cleanCode($('#home-code').value);
  if (!c) return toast('Type a code (1 to 12 letters or numbers).');
  if (!/[A-Z]/.test(c)) return toast('Your code needs at least 1 letter (A-Z).');
  store(HOME_KEY, c);
  toast('Fixed code saved. Other devices must save this device again.');
  if (!room.peers.size) { closeRoom(true); setRoomStatus('idle'); }
  ensureStandby();
  paintHome();
};
$('#home-on').onchange = (e) => {
  store(ON_KEY, e.target.checked ? '1' : '0');
  if (e.target.checked) ensureStandby();
  else if (room.standby && !room.peers.size) { closeRoom(true); setRoomStatus('idle'); }
  paintHome();
};
$('#create').onclick = async () => {
  if (!(await applyServerField())) return;
  const own = cleanCode($('#code-custom').value);
  if (own && !/[A-Z]/.test(own)) return toast('Your code needs at least 1 letter (A-Z).'); // 1 to 6 characters
  try { await refreshLan(); } catch {}
  try { await refreshWebLan(); } catch {}
  startRoom('create', own ? dash(own) : makeCode());
};
$('#join').onclick = async () => {
  if (!(await applyServerField())) return;
  const c = cleanCode($('#code-in').value);
  if (c.length < 1 && lastAlias && lastAlias.home) { // a device name was typed and no code: connect to that device directly
    return startRoom('enter', lastAlias.home, { server: lastAlias.server, saved: lastAlias.name });
  }
  if (c.length < 1) return toast('Enter the code.');
  startRoom('join', dash(c));
};
$('#cancel').onclick = () => { autoPaused = true; closeRoom(); };
$('#disconnect').onclick = () => { autoPaused = true; closeRoom(); };
$('#copy').onclick = async () => toast((await copyText(room.code)) ? 'Code copied' : 'Could not copy. Select the code instead.');
$('#copy-link').onclick = async () => toast((await copyText(room.link || '')) ? 'Link copied' : 'Could not copy. Select the link instead.');
async function sendStagedOnline() {
  try {
    if (!state.staged.length) addFiles(await api.pickFiles());
    if (!state.staged.length) return;
    const targets = [...room.peers.values()].filter((p) => p.live && p.sel);
    if (!targets.length) return toast('Tick at least one connected device.');
    const files = state.staged.splice(0);
    renderStaged();
    // v48: stay on the page you are on (the top speed bar, the device picture and the Transfers badge show the progress)
    toast(`Sending ${files.length} file${files.length > 1 ? 's' : ''} to ${targets.length} device${targets.length > 1 ? 's' : ''}… each device gets it as soon as it taps Accept.`);
    for (const f of files) await sendMany(f, targets);
  } catch (e) {
    toast(`Could not send: ${String((e && e.message) || e)}`);
  }
}
$('#send-online').onclick = sendStagedOnline;
/* v40: "Send" button in the drop bar (works from every screen). Connected -> send to the ticked devices; otherwise go to the screen where you pick who gets the files. */
$('#send-top').onclick = () => {
  if (!state.staged.length) return;
  if (room && room.status === 'live') {
    if ([...room.peers.values()].some((p) => p.live && p.sel)) return sendStagedOnline();
    showView('online');
    return toast('Tick at least one connected device, then press Send.');
  }
  if (api.platform === 'android') { showView('nearby'); return toast('Tap a device to send.'); }
  showView('online');
  toast('Connect to a device first, then press Send.');
};

// Relay channel: same interface as an RTCDataChannel, but the data goes through the session server
// (the host phone) instead of a direct WebRTC link. Used when the direct link cannot be made,
// for example when this phone is the hotspot. Binary frames start with one byte: the other device's id.
function makeRelayChannel(ws, peerId) {
  return {
    isRelay: true,
    get readyState() { return ws.readyState === 1 ? 'open' : 'closed'; },
    get bufferedAmount() { return ws.bufferedAmount; },
    onbufferedamountlow: null,
    send(d) {
      if (typeof d === 'string') { ws.send(JSON.stringify({ type: 'signal', to: peerId, data: { r: d } })); return; }
      const src = d instanceof ArrayBuffer ? new Uint8Array(d) : new Uint8Array(d.buffer, d.byteOffset, d.byteLength);
      const out = new Uint8Array(1 + src.length);
      out[0] = peerId;
      out.set(src, 1);
      ws.send(out);
    },
    close() {},
  };
}

function startRoom(mode, code, opts) {
  opts = opts || {};
  const say = (m) => { if (!opts.quiet) toast(m); };
  closeRoom(true);
  const url = normalizeWs(opts.server || $('#server').value);
  if (!opts.server) $('#server').value = url;
  if (!/^wss?:\/\//.test(url)) {
    if (!opts.quiet) $('#server-details').open = true;
    say('Enter the server address first (your website address, or your PC address like 192.168.0.5:8080).');
    return false;
  }
  if (!IS_DESKTOP && !IS_WEB && isLocalAddr(url) && !hostRunning && !opts.standby) {
    $('#server-details').open = true;
    $('#server').focus();
    say('"localhost" means this phone. Type your website address (https://…) or your PC address (192.168.x.x:8080).');
    return false;
  }

  room.code = code; room.mode = mode; room.standby = !!opts.standby; room.url = url;
  room.hostHome = ''; // filled by whois once joined (see onSignal)
  room.peers = new Map(); room.joined = false; room.myId = 0;
  $('#code-show').textContent = dash(cleanCode(code));
  $('#wait-sub').textContent = opts.saved
    ? `Waiting for ${opts.saved}. Glide must be open there.`
    : mode === 'create' ? 'Share this code. More devices can join with it, and it expires in 15 minutes if nobody does.' : 'Setting up a direct connection.';
  setRoomStatus(opts.standby ? 'standby' : mode === 'create' ? 'waiting' : 'connecting');

  room.link = mode === 'create' ? shareUrl(code, url) : '';
  let qrOk = false;
  if (room.link && window.QR) {
    try { $('#qr').innerHTML = QR.svg(room.link); $('#link-show').textContent = room.link; qrOk = true; } catch {}
  }
  if (mode === 'create' && !room.link && hostRunning && !IS_DESKTOP) {
    $('#wait-sub').textContent = 'No hotspot or Wi-Fi address found yet. Turn on the hotspot (or join Wi-Fi), then press Cancel and Create a code again.';
  }
  if (mode === 'create' && !room.link && ON_LOCALHOST) {
    $('#wait-sub').textContent = 'No Wi-Fi or hotspot address found yet. Connect to Wi-Fi (or turn on the hotspot), then press Cancel and Create a code again.';
  }
  $('#share').hidden = !qrOk;
  $('#copy-link').hidden = !room.link;

  const ws = new WebSocket(url);
  ws.binaryType = 'arraybuffer';
  room.ws = ws;
  const iceServers = [
    { urls: 'stun:stun.l.google.com:19302' }, { urls: 'stun:stun1.l.google.com:19302' }, { urls: 'stun:global.stun.twilio.com:3478' },
    ...iceExtra,
  ];
  const wsSend = (o) => { if (ws.readyState === 1) ws.send(JSON.stringify(o)); };
  const keepAlive = setInterval(() => { if (room.ws !== ws) clearInterval(keepAlive); else wsSend({ type: 'ping' }); }, 25000);

  // Browsers hide a device's Wi-Fi address behind a random name like "3f2a...-....local" (mDNS).
  // On a phone hotspot that name often cannot be resolved, so the two devices never find each other.
  // When the server itself is a device on the local network (an IP address), the other device is on that
  // same network, so we swap the hidden name for the server's real IP. Only used for IP servers.
  const lanIp = (() => { try { const h = new URL(url.replace(/^ws/, 'http')).hostname; return /^\d{1,3}(\.\d{1,3}){3}$/.test(h) && !/^127\./.test(h) ? h : ''; } catch { return ''; } })();
  const unhide = (t) => (lanIp && typeof t === 'string' ? t.replace(/[0-9a-f-]{36}\.local/gi, lanIp) : t);

  function makeLive(p) {
    if (p.live) return;
    p.live = true;
    clearTimeout(p.timer); clearTimeout(p.relayTimer);
    try { p.dc.send(JSON.stringify({ t: 'hello', name: $('#name').value || 'Device', home: getHome(), host: hostIdOn() && amHost(), sw: true, ack: true })); } catch {}
    toast(p.relay ? 'Connected (through the host)' : 'Connected');
    refreshRoomStatus();
  }
  // If the direct link is not up a few seconds after two devices met (typical when this phone is the hotspot),
  // switch that pair to relay mode: files travel through the host phone over the same Wi-Fi. Still full Wi-Fi speed.
  function goRelay(p, tell) {
    if (room.peers.get(p.id) !== p || p.relay || p.live || ws.readyState !== 1) return;
    p.relay = true;
    clearTimeout(p.relayTimer);
    if (tell) wsSend({ type: 'signal', to: p.id, data: { relay: 'go' } });
    const pc = p.pc; p.pc = null;
    try { pc && pc.close(); } catch {}
    p.dc = makeRelayChannel(ws, p.id);
    makeLive(p);
  }
  function setupChannel(p, dc) {
    dc.binaryType = 'arraybuffer';
    dc.bufferedAmountLowThreshold = LOW_BUFFER;
    dc.onopen = () => {
      if (p.relay || room.peers.get(p.id) !== p) return; // relay mode already took over
      p.dc = dc;
      makeLive(p);
    };
    dc.onclose = () => { if (p.dc === dc && room.peers.get(p.id) === p) dropPeer(p, `${p.name} disconnected.`); };
    dc.onmessage = (ev) => onPeerMessage(p, ev);
  }
  function addPeer(id) {
    if (room.peers.has(id)) return room.peers.get(id);
    const p = { id, name: `Device ${id}`, home: '', live: false, relay: false, sel: true, dc: null, pc: null, early: [], curIn: null, timer: 0, relayTimer: 0 };
    const pc = new RTCPeerConnection({ iceServers });
    p.pc = pc;
    pc.onicecandidate = (e) => { if (e.candidate) wsSend({ type: 'signal', to: id, data: { candidate: e.candidate } }); };
    pc.onconnectionstatechange = () => {
      if (!['failed', 'closed'].includes(pc.connectionState) || p.pc !== pc) return;
      if (p.live) dropPeer(p, 'The connection dropped.');
      else goRelay(p, true); // direct link impossible: use the host instead
    };
    pc.ondatachannel = (e) => setupChannel(p, e.channel);
    p.relayTimer = setTimeout(() => goRelay(p, true), 6000);
    p.timer = setTimeout(() => { if (room.peers.get(id) === p && !p.live) dropPeer(p, 'Could not connect to a device. Try again.'); }, 45000);
    room.peers.set(id, p);
    refreshRoomStatus();
    return p;
  }

  let chain = Promise.resolve();
  ws.onopen = () => wsSend({ type: mode, code });
  ws.onerror = () => {
    if (room.ws !== ws) return;
    if (room.standby) { closeRoom(true); setRoomStatus('idle'); sbTimer = setTimeout(ensureStandby, 5000); return; }
    closeRoom();
    if (opts.auto) return;
    if (opts.saved) { toast(`Cannot reach ${opts.saved}. Is Glide open on it, on the same Wi-Fi or hotspot?`); return; }
    if (IS_DESKTOP) toast('Cannot reach that server. Open Server address and press "Use this PC".');
    else { $('#server-details').open = true; toast('Cannot reach the server. Check the address, and that the website or PC app is running (phone and PC on the same Wi-Fi if you use a PC address).'); }
  };
  ws.onclose = () => {
    if (room.ws !== ws) return;
    for (const p of [...room.peers.values()]) if (p.relay || !p.live) dropPeer(p);
    if (room.peers.size) return; // direct links that are already up keep working
    const was = room.status;
    const sb = room.standby;
    closeRoom(true);
    setRoomStatus('idle');
    if (sb) sbTimer = setTimeout(ensureStandby, 5000);
    else if (was !== 'idle') toast('Disconnected from the server.');
  };
  ws.onmessage = (ev) => {
    if (typeof ev.data !== 'string') { // relay mode: file data, first byte = who sent it
      chain = chain.then(() => {
        const u = new Uint8Array(ev.data);
        const p = room.peers.get(u[0]);
        if (p && p.relay && room.ws === ws) return onPeerMessage(p, { data: u.slice(1).buffer });
      }).catch(() => {});
      return;
    }
    chain = chain.then(() => onSignal(JSON.parse(ev.data))).catch(() => {});
  };

  async function onSignal(m) {
    if (room.ws !== ws) return;
    if (m.type === 'error') {
      const sb = room.standby;
      closeRoom(true); setRoomStatus('idle');
      if (sb) sbTimer = setTimeout(ensureStandby, 15000);
      toast(m.message);
    } else if (m.type === 'joined') {
      room.myId = m.id; room.joined = true;
      if (((room.standby && isLocalAddr(url)) || (amHost() && hostIdOn()))) wsSend({ type: 'announce', code: room.standby ? room.code : getHome(), name: $('#name').value || 'Device' }); // lets phones on this hotspot find this device by themselves, and tells every visitor who the host is
      if (!amHost() && hostIdOn()) { // visitor: ask the server which device announced itself as host
        const askHost = (left) => probeInfo(url).then((i) => {
          if (room.ws !== ws) return;
          const hh = cleanCode(String(i.home || ''));
          if (hh) { room.hostHome = hh; renderLivePeers(); } else if (left > 0) setTimeout(() => askHost(left - 1), 3000);
        });
        askHost(2);
      }
      (m.peers || []).forEach((id) => addPeer(id)); // the devices already there will call us
      if (!room.standby && !room.peers.size) $('#wait-sub').textContent = opts.saved ? `Waiting for ${opts.saved}. Glide must be open there.` : $('#wait-sub').textContent;
      refreshRoomStatus();
    } else if (m.type === 'peer-joined') {
      const p = addPeer(m.id);
      if (!p.pc) return;
      setupChannel(p, p.pc.createDataChannel('files'));
      await p.pc.setLocalDescription(await p.pc.createOffer());
      wsSend({ type: 'signal', to: p.id, data: { sdp: p.pc.localDescription } });
    } else if (m.type === 'peer-left') {
      const p = room.peers.get(m.id);
      if (p && (p.relay || !p.live)) dropPeer(p, p.live ? `${p.name} left.` : '');
    } else if (m.type === 'signal') {
      const d = m.data || {};
      const p = room.peers.get(m.from);
      if (!p) return;
      if (d.relay === 'go') { goRelay(p, false); return; }
      if (typeof d.r === 'string') { if (p.relay) await onPeerMessage(p, { data: d.r }); return; }
      if (p.relay || !p.pc) return;
      const pc = p.pc;
      if (d.sdp) {
        await pc.setRemoteDescription({ type: d.sdp.type, sdp: unhide(d.sdp.sdp) });
        for (const c of p.early.splice(0)) await pc.addIceCandidate(c).catch(() => {});
        if (d.sdp.type === 'offer') {
          await pc.setLocalDescription(await pc.createAnswer());
          wsSend({ type: 'signal', to: p.id, data: { sdp: pc.localDescription } });
        }
      } else if (d.candidate) {
        // candidates can overtake the offer/answer; hold them until the description is set
        const cand = { ...d.candidate, candidate: unhide(d.candidate.candidate) };
        if (pc.remoteDescription) await pc.addIceCandidate(cand);
        else p.early.push(cand);
      }
    }
  }
  return true;
}

/* receive (one state per connected device) */
async function onPeerMessage(p, ev) {
  const dc = p.dc;
  if (typeof ev.data === 'string') {
    const m = JSON.parse(ev.data);
    if (swMsg(p, m)) return;
    if (m.t === 'hello') {
      p.name = String(m.name || '').trim().slice(0, 40) || p.name;
      p.home = cleanCode(String(m.home || ''));
      p.sw = m.sw === true; p.ack = m.ack === true; p.isHost = m.host === true; // that device runs the server we are connected to
      // remember the device (only when its server is reachable by others, not this device's own "localhost")
      if (p.home && room.url && !isLocalAddr(room.url)) saveDevice(p.name, p.home, room.url);
      refreshRoomStatus();
    } else if (m.t === 'offer') {
      askIncoming({
        id: m.id, name: m.name, size: m.size, from: p.name,
        pid: p.id,
        cb: async (ok) => {
          const dc = p.dc; // the channel as it is NOW (it may have been replaced while the question was open)
          if (!dc || dc.readyState !== 'open') return toast(`Connection to ${p.name} was lost. Ask them to send again.`);
          if (!ok) return dc.send(JSON.stringify({ t: 'decline', id: m.id }));
          let rid;
          try { rid = await api.rtcOpen(m.name); }
          catch (e) { // e.g. no storage permission: say no, so the sender does not wait for ever, and show why
            dc.send(JSON.stringify({ t: 'decline', id: m.id }));
            toast(`Could not save ${m.name}: ${(e && e.message) || e}`);
            return;
          }
          p.curIn = { id: m.id, rid, size: m.size, done: 0, q: Promise.resolve() };
          cancelHooks.set(m.id, () => {
            const cur = p.curIn;
            if (!cur || cur.id !== m.id) return;
            p.curIn = null;
            try { dc.send(JSON.stringify({ t: 'cancel', id: m.id })); } catch {}
            cur.q = cur.q.then(() => api.rtcAbort(cur.rid)).catch(() => {});
          });
          setTransfer({ id: m.id, name: m.name, size: m.size, dir: 'in', peer: p.name, pid: p.id, status: 'receiving', done: 0 });
          dc.send(JSON.stringify({ t: 'accept', id: m.id }));
        },
      });
    } else if (m.t === 'ack') { // the receiver confirms how many bytes it has
      const j = outJobs.get(m.id);
      if (j && j.p === p) { j.acked = Number(m.n) || 0; j.ackT = Date.now(); if (j.wake) { const w = j.wake; j.wake = null; w(); } }
    } else if (m.t === 'cancel') { // the other device stopped this transfer
      const j = outJobs.get(m.id);
      if (j && j.p === p) {
        j.dead = true;
        const w = waiters.get(m.id); if (w) { waiters.delete(m.id); w.r(false); }
        setTransfer({ id: m.id, status: 'cancelled' });
      } else if (p.curIn && p.curIn.id === m.id) {
        const cur = p.curIn; p.curIn = null;
        cur.q = cur.q.then(() => api.rtcAbort(cur.rid)).catch(() => {});
        setTransfer({ id: m.id, status: 'cancelled' });
      }
    } else if (m.t === 'accept' || m.t === 'decline') {
      const w = waiters.get(m.id);
      if (w) { waiters.delete(m.id); w.r(m.t === 'accept'); }
    } else if (m.t === 'end' && p.curIn && p.curIn.id === m.id) {
      const cur = p.curIn; p.curIn = null;
      cur.q = cur.q.then(async () => {
        const path = await api.rtcClose(cur.rid);
        setTransfer({ id: cur.id, status: 'done', done: cur.size, path });
      });
    }
  } else if (p.swNext) {
    const nx = p.swNext; p.swNext = null;
    swGot(p, nx.sid, nx.i, ev.data);
  } else if (p.curIn) {
    const cur = p.curIn;
    const chunk = new Uint8Array(ev.data);
    cur.done += chunk.byteLength;
    if (cur.done - (cur.acked || 0) >= 512 * 1024 || cur.done >= cur.size) { cur.acked = cur.done; try { dc.send(JSON.stringify({ t: 'ack', id: cur.id, n: cur.done })); } catch {} }
    cur.q = cur.q.then(() => api.rtcWrite(cur.rid, chunk));
    setTransfer({ id: cur.id, done: cur.done });
  }
}

/* send one file to one or several devices: each chunk is read once and sent to every device that accepted */
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
// v49: wait until the channel's send buffer has emptied below LOW_BUFFER. Event driven: a background page (screen off) runs setTimeout only about once a second,
// so a 5 ms polling loop would crawl at ~64 KB/s there. The 1 s timer is only a safety net.
const drained = (dc) => new Promise((res) => {
  let done = false, t = 0;
  const f = () => { if (done) return; done = true; clearTimeout(t); try { dc.removeEventListener('bufferedamountlow', f); } catch {} res(); };
  try { dc.addEventListener('bufferedamountlow', f); } catch {}
  t = setTimeout(f, 1000);
});
async function sendMany(file, targets) {
  let swarmed = false;
  if (swarmOn() && file.size > 0) { // v45 option: devices also share pieces with each other
    const sw = targets.filter((p) => p.sw && p.dc && p.dc.readyState === 'open');
    if (sw.length >= 2) { swarmed = true; swarmSend(file, sw); targets = targets.filter((p) => !sw.includes(p)); if (!targets.length) return; }
  }
  const jobs = [];
  for (const p of targets) {
    const dc = p.dc;
    if (!dc || dc.readyState !== 'open') continue;
    const id = uuid();
    setTransfer({ id, name: file.name, size: file.size, dir: 'out', peer: p.name, pid: p.id, status: 'waiting', done: 0 });
    dc.send(JSON.stringify({ t: 'offer', id, name: file.name, size: file.size }));
    const answer = new Promise((r) => {
      waiters.set(id, { r, pid: p.id });
      setTimeout(() => { const w = waiters.get(id); if (w && w.r === r) { waiters.delete(id); r(null); } }, 300000); // 5 min to tap Accept
    });
    const job = { p, dc, id, answer, dead: false };
    jobs.push(job);
    outJobs.set(id, job);
    cancelHooks.set(id, () => {
      job.dead = true;
      try { dc.send(JSON.stringify({ t: 'cancel', id })); } catch {}
      const w = waiters.get(id); if (w) { waiters.delete(id); w.r(false); }
    });
  }
  if (!jobs.length) return toast('Not connected.');
  // Start sending to each device as soon as IT accepts: nobody waits for the others.
  // Devices that accept at about the same time share one pass over the file (the file is read once);
  // a device that accepts later gets its own pass right after the current one.
  const ready = [];
  let unanswered = jobs.length;
  let wake = null;
  const poke = () => { if (wake) { const w = wake; wake = null; w(); } };
  jobs.forEach((j) => {
    j.answer.then((a) => {
      unanswered--;
      if (a === null) {
        setTransfer({ id: j.id, status: 'failed', error: 'The other device did not answer. Is Glide open there? Tap Accept on it.' });
        toast(`No answer from ${j.p.name}. Ask them to tap Accept.`);
      } else if (!a) setTransfer({ id: j.id, status: 'declined' });
      else ready.push(j);
      poke();
    });
  });
  const runs = [];
  try {
    while (unanswered > 0 || ready.length) {
      if (!ready.length) { await new Promise((r) => { wake = r; }); continue; }
      // v45: one independent run per device, started the moment it accepts, so a slow device never holds the others back
      for (const j of ready.splice(0)) { setTransfer({ id: j.id, status: 'sending' }); j.ackT = Date.now(); runs.push(sendPass(file, [j])); }
    }
    await Promise.all(runs);
  } finally {
    if (!swarmed) api.readClose(file.path); // a swarm closes the file itself when it is finished
  }
}

/* one pass over the file towards the devices in `active` (all of them already accepted) */
async function sendPass(file, active) {
  const sctpMax = (j) => (j.p.pc && j.p.pc.sctp && j.p.pc.sctp.maxMessageSize) || CHUNK;
  const chunk = active.some((j) => j.dc.isRelay) ? 128 * 1024 : Math.max(16 * 1024, Math.min(CHUNK, ...active.map(sctpMax)));
  const readAt = (o) => (o < file.size ? api.readChunk(file.path, o, Math.min(chunk, file.size - o)) : null);
  let off = 0;
  try {
    let next = readAt(0); // read the next chunk while the current one is being sent
    while (next) {
      const buf = await next;
      if (!buf.byteLength) break;
      next = readAt(off + buf.byteLength);
      for (const j of active) {
        if (j.dead) continue;
        try {
          while (j.dc.readyState === 'open' && j.dc.bufferedAmount > MAX_BUFFER) await drained(j.dc);
          while (j.p.ack && !j.dead && j.dc.readyState === 'open' && (j.sent || 0) - (j.acked || 0) > ACK_WIN) { // wait for the receiver to confirm
            if (Date.now() - (j.ackT || 0) > 60000) throw new Error('The other device stopped receiving');
            await new Promise((r) => { j.wake = r; setTimeout(r, 1000); }); // woken by the next ack (no 5 ms timer: a background page runs timers only about once a second)
          }
          if (j.dead) continue;
          if (j.dc.readyState !== 'open') throw new Error('closed');
          j.dc.send(buf);
          j.sent = (j.sent || 0) + buf.byteLength;
          setTransfer({ id: j.id, done: off + buf.byteLength });
        } catch (e) {
          j.dead = true;
          setTransfer({ id: j.id, status: 'failed', error: String((e && e.message) || e || 'unknown error') });
        }
      }
      off += buf.byteLength;
      if (active.every((j) => j.dead)) break;
    }
    for (const j of active) {
      if (j.dead) continue;
      try { j.dc.send(JSON.stringify({ t: 'end', id: j.id })); setTransfer({ id: j.id, status: 'done', done: file.size }); }
      catch (e) { setTransfer({ id: j.id, status: 'failed', error: 'closed' }); }
    }
  } catch (e) {
    const why = String((e && e.message) || e || 'unknown error');
    for (const j of active) if (!j.dead) setTransfer({ id: j.id, status: 'failed', error: why });
    toast(`Sending failed: ${why}`);
  }
}

/* ---------- swarm sharing (v45, v46: own speed meter + deeper pipeline; EXPERIMENTAL: written without a real group of phones to test on) ----------
   One device sends a file to 2+ devices that are all in the same room. The file is cut into 64 KB pieces; every
   receiver asks any device that already has a piece (the sender or another receiver), and offers its own pieces too.
   Messages (JSON on the normal data channel): swoffer / swaccept / swdecline / swhave {add|all} / swreq {i} / swno {i};
   a piece is `sc {sid,i}` followed at once by one binary message. A device holds only a moving window of pieces (SW_AHEAD / SW_KEEP) and writes them to disk in order, so there is no file size limit. */
const swarms = new Map();
const swFlow = new Map(); // "idA|idB" -> time of the last swarm piece between those two devices (renderer/linkfx.js draws it)
const swMark = (a, b) => { if (a !== b) swFlow.set(Math.min(a, b) + '|' + Math.max(a, b), Date.now()); };
const swLive = () => [...room.peers.values()].filter((q) => q.live && q.dc && q.dc.readyState === 'open');
const swSend = (q, o) => { try { q.dc.send(JSON.stringify(o)); } catch {} };
const swLen = (s, i) => (i === s.n - 1 ? s.size - i * s.cs : s.cs);

/* ---------- swarm speed meter (v46): its own numbers, separate from the normal file-transfer meter ----------
   Counts every piece that really crosses a data channel for a swarm: pieces I receive (and from whom) and pieces I serve
   to others (and to whom). Shows how much of the file came from the sender and how much device-to-device, so it is
   clear at once whether the swarm is working (device-to-device must be above 0%). */
function swCountReset() { // a new swarm session starts after 20 s without swarm traffic
  const now = performance.now();
  if (!swStat.last || now - swStat.last > 20000) { swStat.down.clear(); swStat.up.clear(); swStat.dTot = swStat.uTot = swStat.dSeed = 0; swStat.repBytes = swStat.repLast = swStat.repRate = 0; swStat.t0 = now; swStat.lastSample = now; }
}
const swStat = { down: new Map(), up: new Map(), t0: 0, last: 0, lastSample: 0, dTot: 0, uTot: 0, dSeed: 0, repBytes: 0, repLast: 0, repRate: 0 };
function swCount(dir, q, bytes, fromSeed) { // fromSeed: down = the piece came from the sender; up = I am the sender
  swCountReset();
  const now = performance.now();
  swStat.last = now;
  const m = swStat[dir];
  const e = m.get(q.id) || { name: q.name, bytes: 0, lastB: 0, rate: 0, pieces: 0 };
  e.name = q.name; e.bytes += bytes; e.pieces++; e.seed = !!fromSeed; m.set(q.id, e);
  if (dir === 'down') { swStat.dTot += bytes; if (fromSeed) swStat.dSeed += bytes; } else swStat.uTot += bytes;
}
function swMeterTick() {
  const now = performance.now();
  const dt = (now - swStat.lastSample) / 1000;
  if (swStat.last && dt >= 0.5) {
    for (const m of [swStat.down, swStat.up]) for (const e of m.values()) {
      const inst = Math.max(0, e.bytes - e.lastB) / dt;
      e.rate = e.rate ? e.rate * 0.6 + inst * 0.4 : inst;
      if (inst === 0 && e.rate < 512) e.rate = 0;
      e.lastB = e.bytes;
    }
    const ri = Math.max(0, swStat.repBytes - swStat.repLast) / dt;
    swStat.repRate = swStat.repRate ? swStat.repRate * 0.6 + ri * 0.4 : ri;
    if (ri === 0 && swStat.repRate < 512) swStat.repRate = 0;
    swStat.repLast = swStat.repBytes;
    swStat.lastSample = now;
  }
  const show = !!swStat.last && now - swStat.last < 20000;
  const live = show && now - swStat.last < 3000;
  const box = $('#swm');
  if (box) box.hidden = !show;
  if (!show) { spd.sw.now = 0; spd.swSeedNow = 0; return; }
  const sum = (m) => [...m.values()].reduce((a, e) => a + e.rate, 0);
  const dn = sum(swStat.down), up = sum(swStat.up);
  const p2p = swStat.dTot ? Math.round(((swStat.dTot - swStat.dSeed) / swStat.dTot) * 100) : 0;
  // Original = pieces that come straight from the sender (receiver: down from the sender; sender: its own upload).
  // Swarm = pieces that travel device-to-device (receiver: down from other receivers; sender: what the receivers report minus its own upload).
  const rate = (m, f) => [...m.values()].filter(f).reduce((a, e) => a + e.rate, 0);
  const seedDown = rate(swStat.down, (e) => e.seed), p2pDown = rate(swStat.down, (e) => !e.seed), seedUp = rate(swStat.up, (e) => e.seed);
  spd.swSeedNow = live ? seedDown + seedUp : 0;
  spd.sw.now = live ? p2pDown + Math.max(0, swStat.repRate - seedUp) : 0;
  if (box) {
    const rows = (m, arrow, word) => [...m.values()].sort((a, b) => b.rate - a.rate).map((e) =>
      `<div class="swm-row"><span>${arrow} ${word} ${esc(e.name)}</span><span><b>${fmtSpeed(e.rate)}</b> · ${fmt(e.bytes)} · ${e.pieces} pcs</span></div>`).join('');
    const verdict = swStat.dTot === 0 ? '' : p2p > 0
      ? `<div class="swm-ok">Swarm works: ${p2p}% of the pieces came from other receivers (not from the sender).</div>`
      : `<div class="swm-bad">Device-to-device is 0%: every piece came from the sender. The other devices are not sharing yet.</div>`;
    box.innerHTML = `<div class="swm-h"><b>Swarm speed</b><span>&#8595; <b>${fmtSpeed(dn)}</b> &nbsp; &#8593; <b>${fmtSpeed(up)}</b></span></div>`
      + (swStat.dTot ? `<div class="swm-sub">Received ${fmt(swStat.dTot)} · from sender ${fmt(swStat.dSeed)} · device-to-device ${fmt(swStat.dTot - swStat.dSeed)} (${p2p}%)</div>` : '')
      + rows(swStat.down, '&#8595;', 'from') + rows(swStat.up, '&#8593;', 'to') + verdict
      + (swStat.uTot ? `<div class="swm-sub">Sent to others ${fmt(swStat.uTot)}</div>` : '')
      + (swStat.repBytes > 0 ? (() => { // sender view: what the receivers say they hold vs what this device sent
          const p2pB = Math.max(0, swStat.repBytes - swStat.uTot);
          const pc = swStat.repBytes ? Math.round((p2pB / swStat.repBytes) * 100) : 0;
          return `<div class="swm-sub">Receivers report ${fmt(swStat.repBytes)} · you sent ${fmt(swStat.uTot)} · device-to-device about ${fmt(p2pB)} (${pc}%)</div>`
            + (pc > 0 ? `<div class="swm-ok">Swarm works: about ${pc}% came from the receivers, not from you.</div>` : `<div class="swm-bad">Device-to-device is 0%: you sent everything. The receivers are not sharing.</div>`);
        })() : '');
  }
}
setInterval(swMeterTick, 700);

async function swarmSend(file, targets) {
  const s = { sid: uuid(), name: file.name, size: file.size, cs: SW_CS, n: Math.ceil(file.size / SW_CS), seed: file, jobs: new Map(), holders: new Map() };
  swarms.set(s.sid, s);
  for (const q of targets) {
    const job = { tid: uuid(), t: Date.now(), state: 'waiting', q };
    s.jobs.set(q.id, job);
    cancelHooks.set(job.tid, () => { job.state = 'failed'; swSend(q, { t: 'swcancel', sid: s.sid }); });
    setTransfer({ id: job.tid, name: s.name, size: s.size, dir: 'out', peer: q.name, pid: q.id, status: 'waiting', done: 0, via: 'Swarm' });
    swSend(q, { t: 'swoffer', sid: s.sid, name: s.name, size: s.size, n: s.n, cs: s.cs });
  }
  s.tick = setInterval(() => {
    let open = 0;
    for (const [pid, j] of s.jobs) {
      if (j.state === 'done' || j.state === 'failed') continue;
      const alive = room.peers.get(pid) === j.q && j.q.live;
      if (!alive) { j.state = 'failed'; setTransfer({ id: j.tid, status: 'failed', error: 'Device disconnected.' }); }
      else if (j.state === 'waiting' && Date.now() - j.t > 300000) { j.state = 'failed'; setTransfer({ id: j.tid, status: 'failed', error: 'The other device did not answer. Tap Accept on it.' }); }
      else open++;
    }
    if (!open || Date.now() - s.t0 > 30 * 60000) { clearInterval(s.tick); api.readClose(file.path); swarms.delete(s.sid); }
  }, 2000);
  s.t0 = Date.now();
}

function swMsg(q, m) {
  if (!m || typeof m.t !== 'string') return false;
  if (m.t === 'sc') { q.swNext = { sid: m.sid, i: m.i }; return true; }
  if (m.t === 'swoffer') {
    askIncoming({ id: m.sid, name: m.name, size: m.size, from: q.name, pid: q.id, cb: async (ok) => {
      if (!ok) return swSend(q, { t: 'swdecline', sid: m.sid });
      if (!q.dc || q.dc.readyState !== 'open') return toast(`Connection to ${q.name} was lost. Ask them to send again.`);
      let rid;
      try { rid = await api.rtcOpen(String(m.name)); }
      catch (e) { swSend(q, { t: 'swdecline', sid: m.sid }); return toast(`Could not save ${m.name}: ${(e && e.message) || e}`); }
      const s = { rid, next: 0, draining: false, batchSrc: {}, sender: q.id, sid: m.sid, name: String(m.name), size: Number(m.size), cs: Number(m.cs) || SW_CS, n: Number(m.n), tid: uuid(), chunks: [], got: 0,
        holders: new Map([[q.id, 'all']]), inflight: new Map(), per: new Map(), newHave: [], done: false, src: new Map() };
      if (!(s.n > 0)) { api.rtcAbort(rid); return swSend(q, { t: 'swdecline', sid: m.sid }); }
      swarms.set(s.sid, s);
      cancelHooks.set(s.tid, () => { swAbort(s); swSend(q, { t: 'swcancel', sid: s.sid }); });
      setTransfer({ id: s.tid, name: s.name, size: s.size, dir: 'in', peer: q.name, pid: q.id, status: 'receiving', done: 0, via: 'Swarm' });
      swSend(q, { t: 'swaccept', sid: s.sid });
      for (const o of swLive()) swSend(o, { t: 'swhave', sid: s.sid, add: [] }); // tells everybody "I am in this swarm"
      s.tick = setInterval(() => swTick(s), 2000);
      swPump(s);
    } });
    return true;
  }
  if (m.t === 'swhave' && m.src && typeof m.src === 'object') for (const k of Object.keys(m.src)) swMark(q.id, Number(k)); // q got pieces from device k
  const s = swarms.get(m.sid);
  if (m.t === 'swaccept' && s && s.seed) {
    const j = s.jobs.get(q.id);
    if (j && j.state === 'waiting') { j.state = 'sending'; setTransfer({ id: j.tid, status: 'sending' }); s.holders.set(q.id, new Set()); swSend(q, { t: 'swhave', sid: s.sid, all: true }); }
  } else if (m.t === 'swcancel' && s) { // the other side stopped
    if (s.seed) { const j = s.jobs.get(q.id); if (j) { j.state = 'failed'; setTransfer({ id: j.tid, status: 'cancelled' }); } }
    else { swAbort(s); setTransfer({ id: s.tid, status: 'cancelled' }); }
  } else if (m.t === 'swdecline' && s && s.seed) {
    const j = s.jobs.get(q.id);
    if (j) { j.state = 'failed'; setTransfer({ id: j.tid, status: 'declined' }); }
  } else if (m.t === 'swhave' && s) {
    if (s.seed) { // sender: only watches progress
      const j = s.jobs.get(q.id), h = s.holders.get(q.id);
      if (j && h && Array.isArray(m.add)) { const before = h.size; m.add.forEach((i) => h.add(i)); swCountReset(); swStat.last = performance.now(); swStat.repBytes += (h.size - before) * s.cs; setTransfer({ id: j.tid, done: Math.min(s.size, h.size * s.cs) }); if (h.size >= s.n) { j.state = 'done'; setTransfer({ id: j.tid, status: 'done', done: s.size }); } }
    } else {
      let h = s.holders.get(q.id);
      if (m.all) h = 'all'; else if (!h) h = new Set();
      if (h !== 'all' && Array.isArray(m.add)) m.add.forEach((i) => h.add(i));
      s.holders.set(q.id, h);
      swPump(s);
    }
  } else if (m.t === 'swreq' && s) {
    const j = s.seed && s.jobs.get(q.id);
    if (!(j && j.state === 'failed')) swServe(q, s, Number(m.i)); // a cancelled device gets nothing more
  } else if (m.t === 'swreq') {
    swSend(q, { t: 'swno', sid: m.sid, i: m.i }); // this swarm is gone here
  } else if (m.t === 'swno' && s && !s.seed) {
    const h = s.holders.get(q.id);
    if (h && h !== 'all') h.delete(m.i);
    s.inflight.delete(m.i);
    swPump(s);
  } else return false;
  return true;
}

async function swServe(q, s, i) {
  try {
    let buf = null;
    if (s.seed) { const o = i * s.cs; if (o >= 0 && o < s.size) buf = await api.readChunk(s.seed.path, o, Math.min(s.cs, s.size - o)); }
    else if (s.chunks && s.chunks[i]) buf = s.chunks[i];
    if (!buf || !buf.byteLength) return swSend(q, { t: 'swno', sid: s.sid, i });
    const dc = q.dc;
    while (dc.readyState === 'open' && dc.bufferedAmount > MAX_BUFFER) await drained(dc);
    if (dc.readyState !== 'open') return;
    swMark(room.myId, q.id);
    dc.send(JSON.stringify({ t: 'sc', sid: s.sid, i })); dc.send(buf); swCount('up', q, buf.byteLength, !!s.seed); // the two sends are never split by anything else
  } catch {}
}

function swAbort(s) {
  if (!s.done && s.rid) Promise.resolve(api.rtcAbort(s.rid)).catch(() => {}); // delete the half file
  s.done = true; clearInterval(s.tick); clearTimeout(s.flush);
  s.chunks = []; swarms.delete(s.sid);
}

function swPick(s, h) {
  const span = Math.min(SW_AHEAD, s.n - s.next); // only the next pieces, so written-out pieces can be forgotten
  if (span <= 0) return -1;
  const r = Math.floor(Math.random() * span); // random start so devices do not all ask for the same piece
  for (let k = 0; k < span; k++) {
    const i = s.next + ((r + k) % span);
    if (!s.chunks[i] && !s.inflight.has(i) && (h === 'all' || h.has(i))) return i;
  }
  return -1;
}

function swPump(s) {
  if (s.done) return;
  for (const q of swLive()) {
    const h = s.holders.get(q.id);
    if (!h) continue;
    let out = swOut(s, q.id);
    while (out < SW_PIPE) {
      const i = swPick(s, h);
      if (i < 0) break;
      s.inflight.set(i, { pid: q.id, t: Date.now() }); out++;
      swSend(q, { t: 'swreq', sid: s.sid, i });
    }
  }
}

function swTick(s) {
  if (s.done) return;
  const live = new Set(swLive().map((q) => q.id));
  for (const [i, f] of [...s.inflight]) {
    if (!live.has(f.pid) || Date.now() - f.t > SW_TIMEOUT) s.inflight.delete(i);
  }
  if (!live.size) { swAbort(s); setTransfer({ id: s.tid, status: 'failed', error: 'All devices disconnected.' }); return; }
  swPump(s);
}

function swGot(q, sid, i, buf) {
  const s = swarms.get(sid);
  if (s && s.inflight) s.inflight.delete(i);
  if (!s || s.seed || s.done || !(i >= 0 && i < s.n) || i < s.next || s.chunks[i] || !buf || buf.byteLength !== swLen(s, i)) return;
  s.chunks[i] = buf; s.got++; swCount('down', q, buf.byteLength, q.id === s.sender);
  s.batchSrc[q.id] = (s.batchSrc[q.id] || 0) + 1; swMark(room.myId, q.id);
  const sr = s.src.get(q.id) || { name: q.name, n: 0 }; sr.n++; s.src.set(q.id, sr); // who delivered how many pieces
  s.inflight.delete(i);
  s.newHave.push(i);
  setTransfer({ id: s.tid, done: Math.min(s.size, s.got * s.cs), via: 'Swarm: ' + [...s.src.values()].map((x) => `${x.name} ${Math.round((x.n / s.got) * 100)}%`).join(', ') });
  if (!s.flush) s.flush = setTimeout(() => { // tell the others in small batches
    s.flush = null;
    const add = s.newHave.splice(0);
    const src = s.batchSrc; s.batchSrc = {}; // who gave me these pieces (so every screen can draw the swarm)
    if (add.length) for (const o of swLive()) swSend(o, { t: 'swhave', sid: s.sid, add, src });
  }, 250);
  swDrain(s);
  swPump(s);
}

// write the pieces to disk in order (as soon as the next one is here), then forget the old ones
async function swDrain(s) {
  if (s.draining || s.done) return;
  s.draining = true;
  try {
    while (!s.done && s.chunks[s.next]) {
      await api.rtcWrite(s.rid, new Uint8Array(s.chunks[s.next]));
      s.next++;
      const old = s.next - SW_KEEP - 1;
      if (old >= 0) s.chunks[old] = undefined;
    }
    if (!s.done && s.next >= s.n) await swFinish(s);
  } catch (e) {
    if (!s.done) { swAbort(s); setTransfer({ id: s.tid, status: 'failed', error: String((e && e.message) || e || 'could not save the file') }); }
  }
  s.draining = false;
  if (!s.done && s.chunks[s.next]) swDrain(s); // a piece arrived while the loop was ending
  else if (!s.done) swPump(s);
}

async function swFinish(s) {
  s.done = true; clearInterval(s.tick);
  try {
    const path = await api.rtcClose(s.rid);
    setTransfer({ id: s.tid, status: 'done', done: s.size, path });
  } catch (e) {
    setTransfer({ id: s.tid, status: 'failed', error: String((e && e.message) || e || 'could not save the file') });
  }
  setTimeout(() => { s.chunks = []; swarms.delete(s.sid); }, 10 * 60000); // keep sharing the last pieces for 10 more minutes
}

/* ---------- built-in server box (desktop) ---------- */
async function initHostBox() {
  $('#host-box').hidden = false;
  const paint = (s) => {
    $('#host-on').checked = s.enabled;
    state.lan = s.webUrls || [];
    const urls = s.urls.length ? s.urls : [];
    hostRunning = !!s.running;
    // big, always-visible host panel: address + QR for the other device
    const card = $('#host-card');
    card.hidden = false;
    const web = (s.webUrls || [])[0];
    $('#hc-on').checked = !!s.enabled;
    $('#hc-title').textContent = s.error ? 'Hosting problem' : s.running ? 'This device is hosting' : 'Hosting is off';
    $('#hc-dot').className = 'dot' + (s.running ? ' on' : '');
    const showShare = !!(s.running && web && window.QR);
    $('#hc-share').hidden = !showShare;
    if (showShare) {
      $('#hc-url').textContent = (s.webUrls || []).join('   ');
      try { $('#hc-qr').innerHTML = QR.svg(web + '/?auto=1'); } catch {}
      $('#hc-note').textContent = `Or in the Glide app, type ${web.replace(/^https?:\/\//, '')} under Server address.` +
        (s.mdns ? ` Experimental: on a PC, iPhone or Mac you can also try http://${s.mdns}:${s.port} (Android browsers cannot open .local names).` : '');
      $('#hc-copy').onclick = async () => toast((await copyText(web)) ? 'Address copied' : 'Could not copy. Select it instead.');
    }
    if (api.setNfc) { // Android app only (v45, experimental): this phone hands out its address when another phone touches it
      const row = $('#hc-nfc-row'), box = $('#hc-nfc'), msg = $('#hc-nfc-msg');
      row.hidden = false;
      box.checked = load('glide.nfc', '0') === '1';
      const apply = async () => {
        const on = box.checked && !!s.running && !!web;
        const r = await api.setNfc(on, web ? web + '/?auto=1' : '');
        msg.textContent = !box.checked ? '' : !r.supported ? 'This phone has no NFC.' : !r.nfcOn ? 'Turn NFC on in the phone settings.' : !on ? 'Starts when Host is on.' : 'Ready: keep the screen on and touch the back of the other phone.';
      };
      box.onchange = () => { store('glide.nfc', box.checked ? '1' : '0'); apply(); };
      apply();
    }
    $('#hc-msg').textContent = s.error
      ? s.error
      : s.running
        ? (web ? 'If the other device cannot open this address, your Wi-Fi may block devices from talking to each other. Turn on this phone\'s hotspot and connect the other device to it, then use the address shown here.' : 'No Wi-Fi found. Connect to Wi-Fi, or turn on the hotspot and join it from the other device.')
        : 'Turn Host on so other devices can connect to this one.';
    $('#hc-on').onchange = async (e) => paint(await api.setHost(e.target.checked));
    if (s.running && !IS_DESKTOP && !$('#server').value) $('#server').value = `ws://localhost:${s.port}`;
    $('#host-status').innerHTML = s.error
      ? `Could not start: ${esc(s.error)}`
      : s.running
        ? `Running. This device: <code>ws://localhost:${s.port}</code>` +
          ` <button class="link" id="use-local">Use this device</button>` +
          (!IS_DESKTOP && !urls.length ? '<br>No Wi-Fi found. Connect this phone to Wi-Fi, or turn on its hotspot and join it from the other device.' : '') +
          (urls.length ? `<br>Other devices on the same Wi-Fi type one of these: ${urls.map((u) => `<button class="link addr" data-u="${esc(u)}">${esc(u)}</button>`).join(' ')}` : '')
        : 'Off. Turn it on, or enter another device\'s address above.';
    if (!IS_DESKTOP && s.enabled && !s.running) {
      $('#host-status').insertAdjacentHTML('beforeend', ' <button class="link" id="host-restart">Restart</button>');
      $('#host-restart').onclick = async () => { await api.setHost(false); paint(await api.setHost(true)); };
    }
    const useLocal = $('#use-local');
    if (useLocal) useLocal.onclick = () => {
      $('#server').value = `ws://localhost:${s.port}`;
      store('glide.server.v2', $('#server').value);
      toast('Using this device as the server.');
    };
    $('#host-status').querySelectorAll('.addr').forEach((b) => {
      b.onclick = async () => { try { await navigator.clipboard.writeText(b.dataset.u); toast('Address copied. Type it on the other device: Online > Server address.'); } catch { toast(b.dataset.u); } };
    });
  };
  $('#host-on').onchange = async (e) => paint(await api.setHost(e.target.checked));
  let lastKey = '';
  refreshLan = async () => {
    const s = await api.serverInfo();
    const key = JSON.stringify([s.running, s.webUrls || []]);
    state.lan = s.webUrls || [];
    hostRunning = !!s.running;
    if (key !== lastKey) { lastKey = key; paint(s); }
  };
  await refreshLan();
  setInterval(() => { if (!document.hidden) refreshLan().catch(() => {}); }, 3000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) refreshLan().catch(() => {}); });
}

/* ---------- boot ---------- */
(async () => {
  const info = await api.info();
  $('#name').value = info.name;
  $('#name').onchange = async (e) => { e.target.value = await api.setName(e.target.value); };
  $('#open-folder').onclick = () => api.openSaveFolder();

  if (!IS_DESKTOP) {
    document.body.classList.add('mobile');
    document.documentElement.classList.add('mobile');
    if (IS_WEB) { // a website cannot find devices on the Wi-Fi, so only the code-based mode is offered
      document.querySelector('nav [data-view="nearby"]').hidden = true;
      $('#v-nearby').hidden = true;
      showView('online');
    } else {
      showView('nearby');
      const sub = document.querySelector('#on-idle .sub');
      if (sub) sub.textContent = 'This phone hosts the session by itself (see Server address below). One device creates a code. The other types this phone\'s address, then the code.';
      $('#server-details').open = true;
    }
  }
  if (api.addPeer) { // same-Wi-Fi sharing: show this device's IP and let people add the other one by IP
    $('#ip-box').hidden = false;
    const ips = await api.myIps();
    $('#my-ip').textContent = ips.length
      ? `This device: ${ips.join(' · ')}. If the other device does not appear, type its IP below.`
      : 'Not connected to Wi-Fi. Connect both devices to the same Wi-Fi (or one phone\'s hotspot).';
    $('#add-ip').onclick = async () => {
      const v = $('#peer-ip').value.trim();
      if (!/^\d{1,3}(\.\d{1,3}){3}$/.test(v)) return toast('Enter an IP like 192.168.0.7');
      try { await api.addPeer(v); $('#peer-ip').value = ''; toast('Added. Tap it above to send.'); } catch { toast('Invalid IP address.'); }
    };
  }
  if (api.serverInfo) await initHostBox();

  // opened from a QR code or shared link: /?code=ABC-DEF joins by itself
  try {
    const c = cleanCode(new URLSearchParams(location.search).get('code') || '');
    if (c.length >= 1 && /^https?:$/.test(location.protocol)) {
      history.replaceState(null, '', location.pathname);
      showView('online');
      startRoom('join', dash(c));
    }
  } catch {}
  // opened from the "Glide host found" notification (or the host's QR): connect to the host straight away
  try {
    if (IS_WEB && new URLSearchParams(location.search).get('auto') && !room.ws) {
      history.replaceState(null, '', location.pathname);
      showView('online');
      probeHost(ORIGIN_WS).then((home) => {
        if (home) startRoom('enter', home, { saved: 'the host', auto: true });
        else toast('The host is not ready. Open Glide on the hosting phone.');
      });
    }
  } catch {}
  renderStaged();
  renderPeers();
  renderTransfers();
  renderSaved();
  paintHome();
  if (!room.ws) ensureStandby(); // always ready: stay reachable for saved devices
  autoFind().catch(() => {});
  applyNotif();
})();
