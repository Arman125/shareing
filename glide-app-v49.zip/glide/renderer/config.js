'use strict';
// Put your website address here ONCE, then rebuild the APK / EXE. The apps will use it by themselves.
// Example: window.GLIDE_SERVER = 'https://glide-xxxx.onrender.com';
// Leave empty to type the address inside the app (Online > Server address).
window.GLIDE_SERVER = '';
