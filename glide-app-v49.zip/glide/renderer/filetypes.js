'use strict';
// One place that decides which folder a received file goes into.
// Loaded by the pages (window.GlideTypes) and by the desktop app (require).
(function () {
  const MAP = {
    Video: ['mp4', 'mkv', 'mov', 'avi', 'webm', 'flv', 'wmv', 'm4v', '3gp', 'mpg', 'mpeg', 'ts'],
    Image: ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'heic', 'heif', 'svg', 'tif', 'tiff', 'raw', 'dng', 'ico'],
    APK: ['apk', 'xapk', 'apks', 'apkm', 'aab'],
    PDF: ['pdf'],
    Document: ['doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'rtf', 'odt', 'ods', 'odp', 'csv', 'md', 'epub', 'pages', 'numbers', 'key'],
    Audio: ['mp3', 'wav', 'flac', 'aac', 'm4a', 'ogg', 'opus', 'wma', 'amr'],
    Archive: ['zip', 'rar', '7z', 'tar', 'gz', 'bz2', 'xz', 'iso'],
  };
  const BY_EXT = {};
  for (const [folder, exts] of Object.entries(MAP)) for (const e of exts) BY_EXT[e] = folder;

  function folderOf(name) {
    const s = String(name || '');
    const dot = s.lastIndexOf('.');
    if (dot < 0 || dot === s.length - 1) return 'Other';
    return BY_EXT[s.slice(dot + 1).toLowerCase()] || 'Other';
  }

  const api = { folderOf, byExt: BY_EXT, folders: Object.keys(MAP).concat('Other') };
  if (typeof module === 'object' && module.exports) module.exports = api;
  else (typeof window !== 'undefined' ? window : globalThis).GlideTypes = api;
})();
