'use strict';
// Link animation (web page only). Shows "You" and every connected device as outline icons.
//
//  * HOST: the device that runs the server is drawn separately (own panel, bigger, with its profile picture =
//    the shared logo from logo.js). If this page IS the host, "You" gets the panel and the picture.
//  * CONNECTED: a connected device and its line get a soft, steady glow (no motion). A device that is still
//    connecting is dim with a blinking dashed line.
//  * TRANSFER: only the two devices involved animate: light runs around the outline, a ring shows the percent,
//    dots travel along the line towards the receiver. When it ends the ring turns green ("Done") or red ("Failed").
//
// Written for old browsers (about Chrome 70): no replaceChildren, no optional chaining, no CSS filter on SVG parts
// (glow = radial gradients and wide translucent strokes), every shape is a <path> so pathLength works everywhere.
(function () {
  const ONLY_WEB = true; // set to false to show it in the Windows / Android apps too
  const api = window.api || {};
  if (ONLY_WEB && api.platform !== 'web') return;
  const boxes = [document.getElementById('fx-wait'), document.getElementById('fx-live')].filter(Boolean);
  if (!boxes.length) return;
  boxes.forEach((b) => { b.hidden = false; });

  const NS = 'http://www.w3.org/2000/svg';
  const XL = 'http://www.w3.org/1999/xlink';
  const mk = (tag, attrs, text) => {
    const e = document.createElementNS(NS, tag);
    for (const k in attrs || {}) e.setAttribute(k, attrs[k]);
    if (text !== undefined) e.textContent = text; // textContent only: device names can never inject HTML
    return e;
  };
  const isPhone = /Android|iPhone|iPad|Mobile/i.test(navigator.userAgent);
  const short = (s, n) => { s = String(s || 'Device'); n = n || 15; return s.length > n ? `${s.slice(0, n - 1)}…` : s; };
  const norm = (s) => String(s || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  let uidN = 0;

  // ---- geometry helpers: everything is a <path> with pathLength=100, so the running light has the same speed on all shapes
  const circ = (cx, cy, r) => `M${cx} ${cy - r}A${r} ${r} 0 1 1 ${cx} ${cy + r}A${r} ${r} 0 1 1 ${cx} ${cy - r}Z`;
  const rrect = (x, y, w, h, r) =>
    `M${x + r} ${y}H${x + w - r}A${r} ${r} 0 0 1 ${x + w} ${y + r}V${y + h - r}A${r} ${r} 0 0 1 ${x + w - r} ${y + h}` +
    `H${x + r}A${r} ${r} 0 0 1 ${x} ${y + h - r}V${y + r}A${r} ${r} 0 0 1 ${x + r} ${y}Z`;
  function shapesOf(kind, R) {
    if (kind === 'pic') return [circ(0, 0, R - 5)];
    if (kind === 'host') return [rrect(-21, -22, 42, 18, 5), rrect(-21, 4, 42, 18, 5), 'M-13 -13H-12M-13 13H-12'];
    if (kind === 'pc') return [rrect(-27, -19, 54, 35, 5), 'M-10 23H10M0 16V23'];
    return [rrect(-15, -25, 30, 50, 7), 'M-5 -19H5M-6 19H6'];
  }
  function icon(kind, R) {
    const g = mk('g', { class: kind === 'pic' ? 'fx-icon pic' : 'fx-icon' });
    if (kind !== 'pic') { // neon bloom that follows the icon's own shape: 3 wide translucent strokes + a white inner halo (no CSS filter)
      const bl = mk('g', { class: 'fx-bloom' });
      shapesOf(kind, R).forEach((d) => ['fx-b1', 'fx-b2', 'fx-b3', 'fx-b4'].forEach((c) => bl.appendChild(mk('path', { d, class: c }))));
      g.appendChild(bl);
    }
    shapesOf(kind, R).forEach((d, i) => {
      g.appendChild(mk('path', { d, pathLength: 100, class: 'fx-line' }));
      ['fx-glow', 'fx-core'].forEach((c) => {
        const e = mk('path', { d, pathLength: 100, class: c });
        e.style.animationDelay = `${-i * 0.9}s`;
        g.appendChild(e);
      });
    });
    return g;
  }

  // One device. sp = { x, y, R, kind, label, tags, pic, uid, key, ids: { acc, rcv } }
  function makeNode(sp) {
    const R = sp.R;
    const g = mk('g', { transform: `translate(${sp.x} ${sp.y})` });
    g.tags = sp.tags;
    g.appendChild(mk('circle', { r: R + 26, class: 'fx-g1', fill: `url(#${sp.ids.acc})` })); // glow while connected / sending
    g.appendChild(mk('circle', { r: R + 26, class: 'fx-g2', fill: `url(#${sp.ids.rcv})` })); // glow while receiving
    g.appendChild(mk('circle', { r: R, class: 'fx-disc' }));
    if (sp.pic) { // profile picture, cut to a circle
      const rp = R - 5, cid = `fxc-${sp.uid}-${sp.key}`;
      const clip = mk('clipPath', { id: cid });
      clip.appendChild(mk('circle', { r: rp }));
      g.appendChild(clip);
      const im = mk('image', { x: -rp, y: -rp, width: rp * 2, height: rp * 2, preserveAspectRatio: 'xMidYMid slice', 'clip-path': `url(#${cid})` });
      im.setAttribute('href', sp.pic);
      im.setAttributeNS(XL, 'xlink:href', sp.pic);
      g.appendChild(im);
    }
    const ringD = circ(0, 0, R + 5);
    g.appendChild(mk('path', { d: ringD, class: 'fx-track' }));
    const ring = mk('path', { d: ringD, class: 'fx-ring', pathLength: 100 });
    ring.setAttribute('stroke-dasharray', '0 100');
    g.appendChild(ring);
    g.appendChild(icon(sp.pic ? 'pic' : sp.kind, R));
    const q = Math.round(R * 0.74);
    g.appendChild(mk('circle', { cx: q, cy: -q, r: 6, class: 'fx-dot' })); // green = connected, amber = connecting
    g.appendChild(mk('text', { y: R + 21, 'text-anchor': 'middle', class: 'fx-label' }, sp.label));
    const st = mk('text', { y: R + 36, 'text-anchor': 'middle', class: 'fx-status' }, '');
    g.appendChild(st);
    g.ring = ring; g.st = st;
    return g;
  }

  function gradient(id, color) {
    const gr = mk('radialGradient', { id, cx: 0.5, cy: 0.5, r: 0.5 });
    [[0.5, 0.5], [0.78, 0.17], [1, 0]].forEach((s) => gr.appendChild(mk('stop', { offset: s[0], 'stop-color': color, 'stop-opacity': s[1] })));
    return gr;
  }

  // view = { peers: [{ id, name, live, host }], iAmHost, pic }
  function build(box, view) {
    const uid = ++uidN;
    const peers = view.peers;
    const W = 360, mx = 62, px = 288;
    const RH = 46, RN = 41;                       // node radius: host / normal
    const rows = peers.map((p) => ({ p, h: p.host ? 172 : 136 }));
    let y = 6;
    rows.forEach((r) => { r.top = y; r.yc = y + r.h / 2; y += r.h; });
    const H = Math.max(view.iAmHost ? 190 : 160, y + 6);
    const my = H / 2;
    const svg = mk('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fx-svg', role: 'img', 'aria-label': 'Connected devices' });

    const defs = mk('defs');
    const ids = { acc: `fxa-${uid}`, rcv: `fxt-${uid}`, host: `fxh-${uid}` };
    defs.appendChild(gradient(ids.acc, '#7b6cf0'));
    defs.appendChild(gradient(ids.rcv, '#36a9bd'));
    defs.appendChild(gradient(ids.host, '#ff9d7a'));
    svg.appendChild(defs);

    // separate panels for the host
    const rMe = view.iAmHost ? RH : RN;
    if (view.iAmHost) {
      svg.appendChild(mk('rect', { x: 6, y: my - 90, width: 112, height: 180, rx: 26, class: 'fx-hostpanel' }));
      svg.appendChild(mk('text', { x: mx, y: my - 71, 'text-anchor': 'middle', class: 'fx-cap' }, 'YOU · HOST'));
    }
    rows.forEach((r) => {
      if (!r.p.host) return;
      svg.appendChild(mk('rect', { x: 220, y: r.top + 3, width: 136, height: r.h - 6, rx: 26, class: 'fx-hostpanel' }));
      svg.appendChild(mk('text', { x: px, y: r.top + 21, 'text-anchor': 'middle', class: 'fx-cap' }, 'HOST'));
    });

    box._links = {}; box._nodes = {};
    rows.forEach((r) => {
      const rp = r.p.host ? RH : RN;
      const d = `M${mx + rMe + 4} ${my} C ${mx + 112} ${my}, ${px - 112} ${r.yc}, ${px - rp - 4} ${r.yc}`;
      const g = mk('g', { class: 'fx-link', 'data-state': r.p.live ? 'idle' : 'connecting' });
      g.appendChild(mk('path', { d, class: 'fx-wireg' }));                 // glow under the line while connected
      g.appendChild(mk('path', { d, class: 'fx-wire', pathLength: 100 }));
      ['fwd', 'rev'].forEach((dir) => {
        g.appendChild(mk('path', { d, class: `fx-flowg ${dir}`, pathLength: 100 }));
        g.appendChild(mk('path', { d, class: `fx-trail ${dir}`, pathLength: 100 }));
        g.appendChild(mk('path', { d, class: `fx-flow ${dir}`, pathLength: 100 }));
      });
      svg.appendChild(g);
      box._links[r.p.id] = g;
    });

    // v45/v46 swarm: a bright teal arc on the right side between neighbouring devices. It is dashed while idle (when swarm
    // sharing is on) and lights up with running dots in BOTH directions while those devices pass pieces to each other.
    box._seg = [];
    for (let k = 0; k + 1 < rows.length; k++) {
      const a = rows[k], b = rows[k + 1];
      const ya = a.yc + (a.p.host ? RH : RN) * 0.55, yb = b.yc - (b.p.host ? RH : RN) * 0.55, xr = px + 30, bulge = px + 62;
      const d = `M${xr} ${ya} C ${bulge} ${ya}, ${bulge} ${yb}, ${xr} ${yb}`;
      const g = mk('g', { class: 'fx-link fx-swarm', 'data-state': 'idle' });
      g.appendChild(mk('path', { d, class: 'fx-wireg' }));
      g.appendChild(mk('path', { d, class: 'fx-wire', pathLength: 100 }));
      ['fwd', 'rev'].forEach((dir) => {
        g.appendChild(mk('path', { d, class: `fx-flowg ${dir}`, pathLength: 100 }));
        g.appendChild(mk('path', { d, class: `fx-trail ${dir}`, pathLength: 100 }));
        g.appendChild(mk('path', { d, class: `fx-flow ${dir}`, pathLength: 100 }));
      });
      const lab = mk('text', { x: bulge - 8, y: (ya + yb) / 2 + 4, 'text-anchor': 'middle', class: 'fx-swlabel' }, 'Swarm');
      g.appendChild(lab);
      svg.appendChild(g);
      box._seg.push(g);
    }
    const hostPic = view.pic || '';
    const meNode = makeNode({
      x: mx, y: my, R: rMe, kind: view.iAmHost ? 'host' : (isPhone ? 'phone' : 'pc'), label: 'You', tags: 'me' + (view.iAmHost ? ' host' : ''),
      pic: view.iAmHost ? hostPic : '', uid, key: 'me', ids: { acc: view.iAmHost ? ids.host : ids.acc, rcv: ids.rcv },
    });
    svg.appendChild(meNode);
    box._me = meNode;
    rows.forEach((r) => {
      const nd = makeNode({
        x: px, y: r.yc, R: r.p.host ? RH : RN, kind: r.p.host ? 'host' : 'phone', label: short(r.p.name, r.p.host ? 14 : 15), tags: r.p.host ? 'host' : '',
        pic: r.p.host ? hostPic : '', uid, key: `p${r.p.id}`, ids: { acc: r.p.host ? ids.host : ids.acc, rcv: ids.rcv },
      });
      svg.appendChild(nd);
      box._nodes[r.p.id] = nd;
    });
    if (!peers.length) svg.appendChild(mk('text', { x: px, y: my + 4, 'text-anchor': 'middle', class: 'fx-wait' }, 'Waiting…'));
    while (box.firstChild) box.removeChild(box.firstChild);
    box.appendChild(svg);
  }

  // what is happening with one device right now, from the transfers list
  function sum(list) {
    let done = 0, size = 0;
    list.forEach((t) => { done += t.done || 0; size += t.size || 0; });
    return size > 0 ? Math.min(100, Math.round((done / size) * 100)) : 0;
  }
  // state: 'live' | 'connecting' | '' (nothing to say). ended: '' | 'done' | 'failed'
  function paint(nd, info, ended, state) {
    if (!nd) return;
    const out = info.out.length > 0, inn = info.inn.length > 0;
    const act = out || inn;
    let cls = `fx-node ${nd.tags} ${state}${act ? ' act' : ''}${inn && !out ? ' rcv' : ''}`;
    let text = '', pct = 0;
    if (act) {
      pct = sum(out ? info.out : info.inn);
      if (out && inn) { text = 'Sending & receiving'; pct = sum(info.out.concat(info.inn)); }
      else text = `${out ? 'Sending' : 'Receiving'} ${pct}%`;
    } else if (info.waiting) text = 'Waiting for reply';
    else if (ended) { cls += ended === 'failed' ? ' bad' : ' fin'; text = ended === 'failed' ? 'Failed' : 'Done ✓'; pct = 100; }
    else if (state === 'live' && nd.tags.indexOf('me') < 0) text = 'Connected';
    else if (state === 'connecting') text = 'Connecting…';
    if (nd.getAttribute('class') !== cls) nd.setAttribute('class', cls);
    if (nd.st.textContent !== text) nd.st.textContent = text;
    nd.ring.setAttribute('stroke-dasharray', `${pct} 100`);
  }

  let last = {};          // peer id -> was busy at the previous check
  const endedAt = {};     // peer id -> { until, kind }
  function tick() {
    if (document.hidden) return;
    let peers = [];
    let iAmHost = false;
    try {
      const code = norm(room.code);
      iAmHost = (typeof amHost === 'function' && typeof hostIdOn === 'function') ? (hostIdOn() && amHost()) : false;
      peers = Array.from(room.peers.values()).map((p) => ({ id: p.id, name: p.name, live: !!p.live, host: !iAmHost && (typeof isHostPeer === 'function' ? isHostPeer(p) : false) }));
    } catch (e) { return; }
    peers.sort((a, b) => (b.host ? 1 : 0) - (a.host ? 1 : 0) || a.id - b.id); // host first, then by id
    const pic = String(window.GlideLogoData || '');
    const info = { me: { out: [], inn: [], waiting: false } };
    peers.forEach((p) => { info[p.id] = { out: [], inn: [], waiting: false }; });
    const lastResult = {};
    try {
      state.transfers.forEach((t) => {
        let p = null;
        if (t.pid !== undefined) p = peers.filter((q) => q.id === t.pid)[0];
        if (!p) p = peers.filter((q) => q.name === t.peer)[0];
        if (!p) return;
        const i = info[p.id];
        if (t.status === 'sending' || t.status === 'receiving') { (t.dir === 'out' ? i.out : i.inn).push(t); (t.dir === 'out' ? info.me.out : info.me.inn).push(t); }
        else if (t.status === 'waiting') { i.waiting = true; info.me.waiting = true; }
        else if (t.status === 'done' || t.status === 'failed' || t.status === 'declined') lastResult[p.id] = (lastResult[p.id] === 'failed' || t.status !== 'done') ? 'failed' : 'done';
      });
    } catch (e) { /* app.js not ready yet */ }

    const now = Date.now();
    peers.forEach((p) => {
      const busy = info[p.id].out.length + info[p.id].inn.length > 0;
      if (last[p.id] && !busy) endedAt[p.id] = { until: now + 3500, kind: lastResult[p.id] || 'done' };
      last[p.id] = busy;
    });
    const anyBusy = info.me.out.length + info.me.inn.length > 0;
    if (last.me && !anyBusy) endedAt.me = { until: now + 3500, kind: 'done' };
    last.me = anyBusy;
    const endOf = (id) => (endedAt[id] && endedAt[id].until > now ? endedAt[id].kind : '');
    const anyLive = peers.some((p) => p.live);

    // rebuild only when the set of devices (or the host picture) changes, never for plain progress
    const structure = `${iAmHost ? 'H' : 'v'}#${pic.length}:${pic.slice(-24)}#${peers.map((p) => `${p.id}:${p.name}:${p.host ? 1 : 0}`).join('|')}`;
    // which neighbour-lines carry swarm pieces right now
    const segOn = [];
    try {
      const pos = {}; peers.forEach((p, i) => { pos[p.id] = i; });
      swFlow.forEach((t, key) => {
        if (now - t > 2500) return;
        const ab = key.split('|'), ia = pos[Number(ab[0])], ib = pos[Number(ab[1])];
        if (ia === undefined || ib === undefined) return; // a line to this device itself is already animated
        for (let k = Math.min(ia, ib); k < Math.max(ia, ib); k++) segOn[k] = true;
      });
    } catch (e) { /* app.js not ready yet */ }
    boxes.forEach((box) => {
      if (box._sig !== structure) { build(box, { peers, iAmHost, pic }); box._sig = structure; }
      paint(box._me, info.me, endOf('me'), anyLive ? 'live' : '');
      let swOpt = false; try { swOpt = typeof swarmOn === 'function' && swarmOn(); } catch (e) { /* app.js not ready yet */ }
      (box._seg || []).forEach((g, k) => {
        const st = segOn[k] ? 'out in' : (swOpt && peers.length > 1 ? 'idle' : 'off');
        if (g.getAttribute('data-state') !== st) g.setAttribute('data-state', st);
      });
      peers.forEach((p) => {
        paint(box._nodes[p.id], info[p.id], endOf(p.id), p.live ? 'live' : 'connecting');
        const g = box._links[p.id];
        if (!g) return;
        const i = info[p.id];
        const st = !p.live ? 'connecting' : ((i.out.length ? 'out' : '') + (i.out.length && i.inn.length ? ' ' : '') + (i.inn.length ? 'in' : '')) || 'idle';
        if (g.getAttribute('data-state') !== st) g.setAttribute('data-state', st);
      });
    });
  }
  setInterval(tick, 300);
  tick();
})();
