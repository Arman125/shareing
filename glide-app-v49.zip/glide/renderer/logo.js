'use strict';
// Custom logo: tap the picture next to "Glide", pick a photo from the phone, move / zoom / rotate it, save.
// The host device keeps the picture (GET/POST /logo), so everybody who opens the host page sees it too.
(function () {
  const el = document.getElementById('logo');
  if (!el) return;
  const api = window.api || {};
  const KEY = 'glide.logo';
  const KEYPASS = 'glide.logokey';
  const OUT = 256;               // saved picture is 256 x 256
  const MAX_DATA = 600 * 1024;   // same limit as the server
  const say = (m) => { try { toast(m); } catch { /* toast lives in app.js */ } };
  const get = (k) => { try { return localStorage.getItem(k) || ''; } catch { return ''; } };
  const put = (k, v) => { try { v ? localStorage.setItem(k, v) : localStorage.removeItem(k); } catch { /* storage full or blocked */ } };

  // The page is served by the host itself in a browser. In the apps the host is this device on port 8080.
  const inBrowser = api.platform === 'web' && /^https?:$/.test(location.protocol);
  let hostPort = 8080;
  if (!inBrowser && api.serverInfo) api.serverInfo().then((i) => { if (i && i.port) hostPort = i.port; }).catch(() => {});
  const url = () => (inBrowser ? '/logo' : `http://127.0.0.1:${hostPort}/logo`);

  let canEdit = null; // null = not known yet, true / false = the host told us

  /* ---------- showing the logo ---------- */
  function show(dataUrl) {
    window.GlideLogoData = dataUrl || ''; // read by linkfx.js (host profile picture)
    el.classList.toggle('has', !!dataUrl);
    el.style.backgroundImage = dataUrl ? `url("${dataUrl}")` : '';
    let ic = document.querySelector('link[rel="icon"]');
    if (dataUrl) {
      if (!ic) { ic = document.createElement('link'); ic.rel = 'icon'; document.head.appendChild(ic); }
      ic.href = dataUrl;
    } else if (ic) ic.remove();
  }
  const toDataUrl = (blob) => new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(String(r.result));
    r.onerror = () => rej(r.error);
    r.readAsDataURL(blob);
  });

  // Ask the host for its logo. Returns { logo: dataUrl | '' } or null when the host cannot be reached.
  async function fetchHost() {
    try {
      const r = await fetch(url(), { cache: 'no-store' });
      if (r.headers.has('x-can-edit')) canEdit = r.headers.get('x-can-edit') === '1';
      if (r.status === 404) return { logo: '' };
      if (!r.ok) return null;
      return { logo: await toDataUrl(await r.blob()) };
    } catch { return null; }
  }

  async function post(body) {
    const key = get(KEYPASS);
    const r = await fetch(url(), { method: 'POST', body, headers: key ? { 'x-logo-key': key } : {} });
    let j = {};
    try { j = await r.json(); } catch { /* no body */ }
    return { status: r.status, j };
  }

  // Sends the new picture (or "reset") to the host. Says what happened.
  async function upload(body, removing) {
    try {
      let r = await post(body);
      if (r.status === 403 && r.j.needKey) { // a hosted site protected with a password (LOGO_KEY)
        const k = window.prompt('Password to change the logo:');
        if (!k) return false;
        put(KEYPASS, k);
        r = await post(body);
        if (r.status === 403) put(KEYPASS, '');
      }
      if (r.status === 200) {
        say(removing ? 'Logo removed.' : 'Logo saved. Everyone who opens the host page will see it.');
        return true;
      }
      if (r.status === 403) say('Only the host device can change the shared logo.');
      else if (r.status === 400 || r.status === 413) say('That picture could not be used. Try another one.');
      else say('Could not save the logo on the host.');
    } catch {
      say(inBrowser ? 'Could not reach the host.' : 'Saved on this device. Turn on Online > Host so others see it too.');
      return true; // kept locally
    }
    return false;
  }

  async function refresh() {
    const cached = get(KEY);
    if (cached) show(cached);
    const h = await fetchHost();
    if (!h) return; // host not reachable: keep what we have
    if (h.logo) { show(h.logo); put(KEY, h.logo); }
    else if (inBrowser || !cached) { show(''); put(KEY, ''); }
    else upload(cached, false).catch(() => {}); // the host lost its copy: send ours again
  }

  /* ---------- the editor ---------- */
  let S = 280; // preview size in CSS pixels (smaller on narrow screens)
  let root, cv, ctx, slider, saveBtn, pickBtn, rmBtn, hint;
  let img = null, iw = 0, ih = 0, zoom = 1, rot = 0, ox = 0, oy = 0;

  function build() {
    S = Math.max(180, Math.min(280, window.innerWidth - 120));
    root = document.createElement('div');
    root.className = 'scrim';
    root.hidden = true;
    root.innerHTML =
      '<div class="glass modal logo-modal" role="dialog" aria-modal="true" aria-labelledby="lg-title">' +
        '<h2 id="lg-title">Your logo</h2>' +
        '<div class="lg-stage" style="width:'+S+'px"><canvas id="lg-cv"></canvas><div class="lg-empty" id="lg-hint">Choose a photo from your phone</div></div>' +
        '<label class="lg-zoom"><span>Zoom</span><input type="range" id="lg-zoom" min="100" max="400" value="100" disabled></label>' +
        '<div class="row wrap lg-row">' +
          '<button class="btn" id="lg-pick">Choose photo</button>' +
          '<button class="btn" id="lg-rot" disabled>Rotate</button>' +
          '<button class="btn ghost" id="lg-rm" hidden>Remove</button>' +
        '</div>' +
        '<p class="lg-note">Drag to move. Pinch or use the slider to zoom.</p>' +
        '<div class="row end"><button class="btn ghost" id="lg-cancel">Cancel</button><button class="btn primary" id="lg-save" disabled>Save</button></div>' +
        '<input type="file" id="lg-file" accept="image/*" hidden>' +
      '</div>';
    document.body.appendChild(root);
    cv = root.querySelector('#lg-cv');
    const dpr = Math.min(window.devicePixelRatio || 1, 3);
    cv.width = Math.round(S * dpr); cv.height = Math.round(S * dpr);
    cv.style.width = cv.style.height = `${S}px`;
    ctx = cv.getContext('2d');
    slider = root.querySelector('#lg-zoom');
    saveBtn = root.querySelector('#lg-save');
    pickBtn = root.querySelector('#lg-pick');
    rmBtn = root.querySelector('#lg-rm');
    hint = root.querySelector('#lg-hint');
    const file = root.querySelector('#lg-file');

    pickBtn.onclick = () => file.click();
    hint.onclick = () => file.click();
    file.onchange = () => { if (file.files[0]) load(file.files[0]); file.value = ''; };
    root.querySelector('#lg-cancel').onclick = close;
    root.addEventListener('pointerdown', (e) => { if (e.target === root) close(); });
    document.addEventListener('keydown', (e) => { if (!root.hidden && e.key === 'Escape') close(); });
    slider.oninput = () => { zoom = slider.value / 100; clamp(); draw(); };
    root.querySelector('#lg-rot').onclick = () => { rot = (rot + 1) % 4; clamp(); draw(); };
    saveBtn.onclick = save;
    rmBtn.onclick = async () => {
      show(''); put(KEY, '');
      close();
      await upload('reset', true);
    };

    // drag with one finger / mouse, pinch with two
    const ptr = new Map();
    let lastDist = 0;
    cv.style.touchAction = 'none';
    cv.addEventListener('pointerdown', (e) => { if (!img) return; cv.setPointerCapture(e.pointerId); ptr.set(e.pointerId, { x: e.clientX, y: e.clientY }); lastDist = 0; });
    cv.addEventListener('pointermove', (e) => {
      const p = ptr.get(e.pointerId);
      if (!p || !img) return;
      if (ptr.size === 1) { ox += e.clientX - p.x; oy += e.clientY - p.y; }
      p.x = e.clientX; p.y = e.clientY;
      if (ptr.size === 2) {
        const [a, b] = [...ptr.values()];
        const d = Math.hypot(a.x - b.x, a.y - b.y);
        if (lastDist) { zoom = Math.min(4, Math.max(1, zoom * (d / lastDist))); slider.value = Math.round(zoom * 100); }
        lastDist = d;
      }
      clamp(); draw();
    });
    const up = (e) => { ptr.delete(e.pointerId); lastDist = 0; };
    cv.addEventListener('pointerup', up);
    cv.addEventListener('pointercancel', up);
    cv.addEventListener('wheel', (e) => {
      if (!img) return;
      e.preventDefault();
      zoom = Math.min(4, Math.max(1, zoom * Math.exp(-e.deltaY * 0.0015)));
      slider.value = Math.round(zoom * 100);
      clamp(); draw();
    }, { passive: false });
  }

  const base = () => S / Math.min(iw, ih); // the smallest size that still fills the square
  function clamp() {
    if (!img) return;
    const sw = rot % 2 ? ih : iw, sh = rot % 2 ? iw : ih;
    const mx = Math.max(0, (sw * base() * zoom - S) / 2), my = Math.max(0, (sh * base() * zoom - S) / 2);
    ox = Math.min(mx, Math.max(-mx, ox));
    oy = Math.min(my, Math.max(-my, oy));
  }
  function paint(c, size) {
    const k = size / S;
    c.clearRect(0, 0, size, size);
    if (!img) return;
    c.save();
    c.imageSmoothingQuality = 'high';
    c.translate(size / 2 + ox * k, size / 2 + oy * k);
    c.rotate(rot * Math.PI / 2);
    const sc = base() * zoom * k;
    c.scale(sc, sc);
    c.drawImage(img, -iw / 2, -ih / 2);
    c.restore();
  }
  function draw() {
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    paint(ctx, cv.width);
  }

  function load(file) {
    const u = URL.createObjectURL(file);
    const im = new Image();
    im.onload = () => {
      URL.revokeObjectURL(u);
      img = im; iw = im.naturalWidth; ih = im.naturalHeight;
      zoom = 1; rot = 0; ox = 0; oy = 0; slider.value = 100;
      slider.disabled = false; saveBtn.disabled = false;
      root.querySelector('#lg-rot').disabled = false;
      hint.hidden = true;
      draw();
    };
    im.onerror = () => { URL.revokeObjectURL(u); say('This file is not a picture the phone can open.'); };
    im.src = u;
  }

  async function save() {
    if (!img) return;
    saveBtn.disabled = true;
    const c = document.createElement('canvas');
    let size = OUT, data = '';
    for (; size >= 128; size = Math.round(size * 0.75)) {
      c.width = c.height = size;
      paint(c.getContext('2d'), size);
      data = c.toDataURL('image/png');
      if (data.length * 0.75 <= MAX_DATA) break;
    }
    show(data); put(KEY, data);
    close();
    await upload(data, false);
  }

  function open() {
    if (canEdit === false) return say('Only the host device can change the logo.');
    if (!root) build();
    img = null; iw = ih = 0; zoom = 1; rot = 0; ox = oy = 0;
    slider.value = 100; slider.disabled = true; saveBtn.disabled = true;
    root.querySelector('#lg-rot').disabled = true;
    hint.hidden = false;
    rmBtn.hidden = !el.classList.contains('has');
    draw();
    root.hidden = false;
  }
  function close() { if (root) root.hidden = true; }

  el.addEventListener('click', open);
  refresh();
  document.addEventListener('visibilitychange', () => { if (!document.hidden) refresh(); }); // others see a new logo when they come back to the page
})();
