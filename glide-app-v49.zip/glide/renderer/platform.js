'use strict';
// Platform adapter. On the desktop app, preload.js already provides window.api.
// On Android (Capacitor) and in a plain browser this file provides the same API
// using web features plus the small native "GlideSaver" plugin.
(function () {
  if (window.api) return;

  const cap = window.Capacitor;
  const native = !!(cap && cap.isNativePlatform && cap.isNativePlatform());
  const saver = native
    ? (cap.registerPlugin ? cap.registerPlugin('GlideSaver') : cap.Plugins && cap.Plugins.GlideSaver)
    : null;

  const nearby = native
    ? (cap.registerPlugin ? cap.registerPlugin('GlideNearby') : cap.Plugins && cap.Plugins.GlideNearby)
    : null;

  const host = native
    ? (cap.registerPlugin ? cap.registerPlugin('GlideHost') : cap.Plugins && cap.Plugins.GlideHost)
    : null;
  let hostOn = (function () { try { return localStorage.getItem('glide.host') !== '0'; } catch { return true; } })();
  if (host && hostOn) host.hostStart().catch(() => {}); // like the PC app: this device can host sessions, on by default

  // a browser without a chosen name is called after its device, so two devices can be told apart
  const webName = () => {
    const u = navigator.userAgent || '';
    return /iPhone/.test(u) ? 'iPhone' : /iPad/.test(u) ? 'iPad' : /Android/.test(u) ? 'Android phone'
      : /Windows/.test(u) ? 'Windows PC' : /Macintosh|Mac OS/.test(u) ? 'Mac' : /Linux/.test(u) ? 'Linux PC' : 'This browser';
  };
  const FLUSH = 2 * 1024 * 1024; // write received data to disk in 2 MB batches
  const files = new Map();       // key -> File (kept for sending)
  const writers = new Map();     // id -> { name, parts, bytes, sid }
  const noop = () => {};

  // ---- browser keep-alive (v48): a phone browser freezes the page when the screen turns off, which stops the file transfer.
  // Three things are done while a connection or transfer is active: the Screen Wake Lock (screen does not time out), a looping
  // inaudible sound (Chrome keeps a tab that plays audio running) and a Web Lock (a page holding one is not frozen).
  // This cannot be forced: pressing the power button on some phones/browsers (and iPhone Safari) still pauses the page.
  const WK = { want: false, lock: null, audio: null, rel: null, url: '' };
  function wkWav() {
    const n = 8000, b = new ArrayBuffer(44 + n * 2), v = new DataView(b);
    const w = (o, s) => { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };
    w(0, 'RIFF'); v.setUint32(4, 36 + n * 2, true); w(8, 'WAVEfmt '); v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
    v.setUint32(24, 8000, true); v.setUint32(28, 16000, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true); w(36, 'data'); v.setUint32(40, n * 2, true);
    for (let i = 0; i < n; i++) v.setInt16(44 + i * 2, i % 2 ? 2 : -2, true); // far below what can be heard
    return URL.createObjectURL(new Blob([b], { type: 'audio/wav' }));
  }
  function wkLock() {
    try {
      if (!WK.want || WK.lock || !navigator.wakeLock || document.hidden) return;
      navigator.wakeLock.request('screen').then((l) => { WK.lock = l; l.addEventListener('release', () => { if (WK.lock === l) WK.lock = null; }); }).catch(noop);
    } catch { /* not supported */ }
  }
  function wkAudio() {
    try {
      if (!WK.want) return;
      if (!WK.audio) { WK.url = wkWav(); const a = new Audio(WK.url); a.loop = true; a.volume = 0.05; a.setAttribute('playsinline', ''); WK.audio = a; }
      if (WK.audio.paused) WK.audio.play().catch(noop); // needs one tap on the page first; the listener below retries
      if (navigator.mediaSession && window.MediaMetadata) navigator.mediaSession.metadata = new MediaMetadata({ title: 'Glide is sharing files', artist: 'Keep this running' });
    } catch { /* not supported */ }
  }
  function wkWebLock() {
    try {
      if (!WK.want || WK.rel || !navigator.locks) return;
      navigator.locks.request('glide-busy', () => new Promise((res) => { WK.rel = res; if (!WK.want) { WK.rel = null; res(); } })).catch(noop);
    } catch { /* not supported */ }
  }
  function webKeep(on) {
    WK.want = on;
    if (on) { wkLock(); wkAudio(); wkWebLock(); return; }
    try { if (WK.lock) WK.lock.release().catch(noop); } catch { /* ignore */ }
    WK.lock = null;
    try { if (WK.audio) WK.audio.pause(); } catch { /* ignore */ }
    if (WK.rel) { const r = WK.rel; WK.rel = null; r(); }
  }
  document.addEventListener('visibilitychange', () => { if (!document.hidden) { wkLock(); wkAudio(); } });
  ['pointerdown', 'touchend', 'keydown'].forEach((ev) => document.addEventListener(ev, () => { if (WK.want) wkAudio(); }, { passive: true }));
  const uid = () => (crypto.randomUUID ? /*compat-ok*/ crypto.randomUUID() : String(Date.now()) + Math.random());

  const load = (k, d) => { try { return localStorage.getItem(k) || d; } catch { return d; } };
  const store = (k, v) => { try { localStorage.setItem(k, v); } catch {} };

  const uris = new Map();        // saved path -> content:// uri (Android share sheet)
  const shareFiles = new Map();  // saved name -> File (browser share sheet, last few only)
  const sharedHandlers = [];
  const folderOf = (n) => (window.GlideTypes ? window.GlideTypes.folderOf(n) : 'Other');
  function b64ToBuf(b64) {
    const bin = atob(b64);
    const u = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
    return u.buffer;
  }

  const meta = new Map(); // content:// uri -> { name, size } for files picked or shared in
  const nh = { peers: [], incoming: [], cancel: [], transfer: [] };

  // Android: other apps (Gallery, Files, Vivo Share, Quick Share) can hand files to Glide
  if (native && saver && saver.addListener) {
    saver.addListener('sharedFiles', (d) => {
      const out = ((d && d.files) || []).map((f) => ({ path: f.uri, name: f.name, size: f.size }));
      out.forEach((f) => meta.set(f.path, { name: f.name, size: f.size }));
      if (out.length) sharedHandlers.forEach((h) => h(out));
    });
  }

  // Android: nearby sharing on the same Wi-Fi (same protocol as the PC app, no server needed)
  if (native && nearby) {
    nearby.addListener('peers', (d) => nh.peers.forEach((f) => f((d && d.peers) || [])));
    nearby.addListener('incoming', (d) => nh.incoming.forEach((f) => f(d)));
    nearby.addListener('incomingCancel', (d) => nh.cancel.forEach((f) => f(d && d.id)));
    nearby.addListener('transfer', (d) => {
      if (d && d.uri && d.path) uris.set(d.path, d.uri);
      nh.transfer.forEach((f) => f(d));
    });
    nearby.start({
      name: load('glide.name', 'My phone'),
      types: (window.GlideTypes && window.GlideTypes.byExt) || {},
    }).catch(noop);
  }

  function blobToBase64(blob) {
    return new Promise((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => { const s = String(r.result); resolve(s.slice(s.indexOf(',') + 1)); };
      r.onerror = () => reject(r.error);
      r.readAsDataURL(blob);
    });
  }

  // Blob.arrayBuffer() does not exist before Chrome 76 (old Android browsers): FileReader works everywhere
  function blobToBuffer(blob) {
    if (blob.arrayBuffer) return blob.arrayBuffer(); // compat-ok: guarded
    return new Promise((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => resolve(r.result);
      r.onerror = () => reject(r.error || new Error('Could not read the file'));
      r.readAsArrayBuffer(blob);
    });
  }

  async function flush(w) {
    if (!native || !w.parts.length) return;
    const blob = new Blob(w.parts);
    w.parts = []; w.bytes = 0;
    await saver.write({ id: w.sid, data: await blobToBase64(blob) });
  }

function pickWeb() {
  return new Promise((resolve) => {
      const inp = document.createElement('input');
      inp.type = 'file';
      inp.multiple = true;
      inp.style.display = 'none';
      let done = false;
      const finish = (list) => { if (!done) { done = true; inp.remove(); resolve(list); } };
      inp.onchange = () => {
        const out = [];
        for (const f of inp.files) {
          const key = `${f.name}|${f.size}|${f.lastModified}`;
          files.set(key, f);
          out.push({ path: key, name: f.name, size: f.size });
        }
        finish(out);
      };
      inp.addEventListener('cancel', () => finish([]));
      document.body.appendChild(inp);
      inp.click();
    });
}

  window.api = {
    platform: native ? 'android' : 'web',

    info: async () => ({
      name: load('glide.name', native ? 'My phone' : webName()),
      saveDir: native ? 'Downloads/Glide' : 'your Downloads folder',
    }),
    setName: async (n) => {
      const v = String(n).trim().slice(0, 40) || (native ? 'My phone' : webName());
      store('glide.name', v);
      if (nearby) nearby.setName({ name: v }).catch(noop);
      return v;
    },

    pickFiles: async () => {
      if (native && nearby) {
        try {
          const r = await nearby.pick();
          return ((r && r.files) || []).map((f) => {
            meta.set(f.uri, { name: f.name, size: f.size });
            return { path: f.uri, name: f.name, size: f.size };
          });
        } catch (e) { /* native picker unavailable: fall back to the web picker below */ }
      }
      return pickWeb();
    },
    pathOf: () => '',
    statFile: async () => null, // drag-and-drop of local paths is desktop only

    // sending: read slices straight from the picked File (no copy, works for huge files)
    readChunk: (key, off, len) => {
      if (String(key).startsWith('content://')) return saver.readUri({ uri: key, offset: off, length: len }).then((r) => b64ToBuf(r.data));
      const f = files.get(key);
      if (!f) return Promise.reject(new Error('File is no longer available. Choose it again.'));
      return blobToBuffer(f.slice(off, off + len));
    },
    readClose: async (key) => {
      if (String(key).startsWith('content://')) { if (saver) saver.closeUri({ uri: key }).catch(noop); }
      else files.delete(key);
    },

    // receiving
    rtcOpen: async (name) => {
      const id = uid();
      const w = { name: String(name), parts: [], bytes: 0, sid: null };
      if (native) {
        const r = await saver.begin({ name: w.name, folder: folderOf(w.name) });
        w.sid = r.id;
        w.name = r.name || w.name;
      }
      writers.set(id, w);
      return id;
    },
    rtcWrite: async (id, data) => {
      const w = writers.get(id);
      if (!w) return;
      w.parts.push(data);
      w.bytes += data.byteLength;
      if (native && w.bytes >= FLUSH) await flush(w);
    },
    rtcAbort: async (id) => { // cancelled download: drop what was received (and delete the half file on Android)
      const w = writers.get(id);
      writers.delete(id);
      if (w && native && w.sid) { try { await saver.abort({ id: w.sid }); } catch {} }
    },
    rtcClose: async (id) => {
      const w = writers.get(id);
      if (!w) return null;
      writers.delete(id);
      if (native) {
        await flush(w);
        const r = await saver.finish({ id: w.sid });
        const p = r.path || `Downloads/Glide/${folderOf(w.name)}/${w.name}`;
        if (r.uri) uris.set(p, r.uri);
        return p;
      }
      // plain browser: hand the finished file to the download manager
      // (a website cannot choose folders; the browser decides where its Downloads go)
      const file = new File(w.parts, w.name);
      if (file.size <= 300 * 1024 * 1024) { // keep a few small ones so the share sheet (AirDrop etc.) can use them
        shareFiles.set(w.name, file);
        if (shareFiles.size > 3) shareFiles.delete(shareFiles.keys().next().value);
      }
      const url = URL.createObjectURL(file);
      const a = document.createElement('a');
      a.href = url; a.download = w.name;
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 60000);
      return w.name;
    },

    // Opens the phone's own share sheet: AirDrop on iPhone, Quick Share / Vivo Share / Bluetooth on Android
    shareFile: async (p) => {
      try {
        if (native) {
          const uri = uris.get(p);
          if (!uri) return toast('Cannot share this file.');
          return await saver.shareFile({ uri, name: p.split('/').pop() });
        }
        const f = shareFiles.get(p);
        if (f && navigator.canShare && navigator.canShare({ files: [f] })) return await navigator.share({ files: [f] });
        toast('Sharing is not supported by this browser. Open the file from your Downloads and share it from there.');
      } catch (e) { if (e && e.name !== 'AbortError') toast('Could not open the share sheet.'); }
    },
    onSharedFiles: (cb) => { sharedHandlers.push(cb); },

    showInFolder: (p) => { if (typeof toast === 'function') toast(`Saved to ${p}`); },
    openSaveFolder: () => { if (typeof toast === 'function') toast(native ? 'Received files are in Downloads/Glide' : 'Received files go to your Downloads folder'); },
    setBusy: (on) => {
      if (saver) saver.keepAwake({ on: !!on }).catch(noop);
      if (host && host.keepBusy) host.keepBusy({ on: !!on }).catch(noop); // Android app: CPU + Wi-Fi stay awake with the screen off
      if (!native) webKeep(!!on);                                          // browser: screen wake lock + silent audio + Web Lock
    },

    // nearby discovery and incoming LAN requests: Android app and desktop app only
    respond: native && nearby ? (id, ok) => { nearby.respond({ id, ok: !!ok }).catch(noop); } : noop,
    onPeers: native && nearby ? (cb) => { nh.peers.push(cb); } : noop,
    onIncoming: native && nearby ? (cb) => { nh.incoming.push(cb); } : noop,
    onIncomingCancel: native && nearby ? (cb) => { nh.cancel.push(cb); } : noop,
    onTransfer: native && nearby ? (cb) => { nh.transfer.push(cb); } : noop,
    lanSend: native && nearby
      ? async (peerId, key) => {
        const m = meta.get(key) || {};
        try { await nearby.send({ peerId, uri: key, name: m.name || 'file', size: m.size || 0 }); }
        catch { if (typeof toast === 'function') toast('Could not reach that device. Is Glide open on it, on the same Wi-Fi?'); }
      }
      : async () => {},
  };
  if (native && host) {
    if (host.keepStart) {
      window.api.keepService = (on, text) => (on ? host.keepStart({ text }) : host.keepStop()).catch(noop);
      window.api.notifyIncoming = (title, text) => host.notifyIncoming({ title, text }).catch(noop);
    if (host.bgStatus) { // v49: let the user allow background use (battery / autostart)
      window.api.bgStatus = async () => { try { return await host.bgStatus(); } catch { return {}; } };
      window.api.bgOpen = async (kind) => { try { await host.bgOpen({ kind }); } catch { /* ignore */ } };
    }
    }
    window.api.gateway = async () => { try { return (await host.gateway()).ip || ''; } catch { return ''; } };
    // same shape as the PC app, so the "Host sessions" box works unchanged on the phone
    window.api.serverInfo = async () => {
      try { return { ...(await host.hostInfo()), enabled: hostOn }; }
      catch { return { running: false, enabled: hostOn, port: 8080, error: 'Host is not available.', urls: [], webUrls: [] }; }
    };
    window.api.setNfc = async (on, url) => { try { return await host.nfcSet({ on: !!on, url: url || '' }); } catch { return { supported: false, nfcOn: false, active: false }; } };
    window.api.setHost = async (on) => {
      hostOn = !!on;
      store('glide.host', hostOn ? '1' : '0');
      try { return { ...(await (hostOn ? host.hostStart() : host.hostStop())), enabled: hostOn }; }
      catch { return window.api.serverInfo(); }
    };
  }
  if (native && nearby) {
    window.api.addPeer = (ip) => nearby.addPeer({ ip });
    window.api.myIps = async () => { try { return (await nearby.ips()).ips || []; } catch { return []; } };
  }
})();
