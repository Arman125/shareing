// Standalone Glide server: the website AND the signaling server on one port.
// Deploy this on Render / Fly.io / any VPS. Open the site, share the code or QR link.
const path = require('path');
const fs = require('fs');
const { start } = require('./signaling');

const PORT = Number(process.env.PORT) || 8080;
// the web pages live in ../renderer (repo) or ./renderer (Docker image)
const staticDir = [path.join(__dirname, '..', 'renderer'), path.join(__dirname, 'renderer')].find((d) => fs.existsSync(path.join(d, 'index.html')));

start(PORT, { staticDir })
  .then((s) => console.log(`Glide listening on port ${s.port}${staticDir ? ' (website + signaling)' : ' (signaling only)'}`))
  .catch((e) => { console.error(`Could not start on port ${PORT}: ${e.message}`); process.exit(1); });
