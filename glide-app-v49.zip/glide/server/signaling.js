// Glide signaling server core. Only introduces two people. Files never pass through it.
// Used by the desktop app (embedded) and by server.js (standalone).
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { WebSocketServer } = require('ws');

const ROOM_TTL = 15 * 60 * 1000;
const norm = (c) => String(c || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
const reply = (ws, o) => { if (ws.readyState === 1) ws.send(JSON.stringify(o)); };

const TYPES = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json',
  '.webmanifest': 'application/manifest+json',
};

// Optional TURN relay for people on strict networks (set TURN_URLS, TURN_USER, TURN_PASS).
// Served at /ice so the website can pick it up. Leave unset to use only free STUN.
function iceFromEnv() {
  const urls = String(process.env.TURN_URLS || '').split(',').map((s) => s.trim()).filter(Boolean);
  if (!urls.length) return [];
  return [{ urls, username: process.env.TURN_USER || '', credential: process.env.TURN_PASS || '' }];
}


// This machine's Wi-Fi / hotspot / LAN addresses as http:// URLs, so a page opened as
// "localhost" can show the address that other devices on the network must use.
function lanUrls(port) {
  const rank = (ip) => (/^192\.168\./.test(ip) ? 0 : /^(10|172\.(1[6-9]|2\d|3[01]))\./.test(ip) ? 1 : 2);
  const ips = [];
  for (const list of Object.values(os.networkInterfaces())) {
    for (const a of list || []) {
      if ((a.family === 'IPv4' || a.family === 4) && !a.internal && !a.address.startsWith('169.254.')) ips.push(a.address);
    }
  }
  return [...new Set(ips)].sort((a, b) => rank(a) - rank(b)).map((ip) => `http://${ip}:${port}`);
}
// /lan is only answered to this machine or to devices on a private network, never to the open internet
// (a hosted website would otherwise reveal its internal addresses).
const isPrivatePeer = (req) => {
  const a = String((req.socket && req.socket.remoteAddress) || '').replace(/^::ffff:/, '');
  return a === '::1' || /^(127\.|10\.|192\.168\.|169\.254\.|172\.(1[6-9]|2\d|3[01])\.)/.test(a) || /^f[cd]/i.test(a) || /^fe80:/i.test(a);
};
function sendLan(req, res) {
  const port = (req.socket && req.socket.localPort) || 0;
  res.writeHead(200, { 'content-type': 'application/json', 'cache-control': 'no-store' });
  res.end(JSON.stringify({ port, urls: isPrivatePeer(req) ? lanUrls(port) : [] }));
}

// ---- Shared logo: the host keeps one picture, everybody who opens the page sees it ----
const LOGO_MAX = 600 * 1024; // bytes of the PNG
let logoFile = '';
const ownAddrs = () => {
  const s = new Set(['127.0.0.1', '::1']);
  for (const list of Object.values(os.networkInterfaces())) for (const a of list || []) s.add(a.address);
  return s;
};
const peerAddr = (req) => String((req.socket && req.socket.remoteAddress) || '').replace(/^::ffff:/, '');
// the device that runs this server (its own app or its own browser) may change the logo; others only if LOGO_KEY is set and given
const isSelf = (req) => ownAddrs().has(peerAddr(req));
function originOk(req) {
  const o = req.headers.origin;
  if (!o || o === 'null') return true; // desktop app (file://) and plain requests
  try {
    const u = new URL(o);
    const host = String(req.headers.host || '').split(':')[0];
    return u.hostname === host || u.hostname === 'localhost' || u.hostname === '127.0.0.1';
  } catch { return false; }
}
function canEdit(req) { return isSelf(req) || !!process.env.LOGO_KEY; }
function logoHead(req, extra) {
  return Object.assign({
    'access-control-allow-origin': '*',
    'access-control-allow-headers': 'x-logo-key, content-type',
    'access-control-expose-headers': 'x-can-edit',
    'x-can-edit': canEdit(req) ? '1' : '0',
    'cache-control': 'no-store',
  }, extra || {});
}
function logoHandler(req, res) {
  if (req.method === 'OPTIONS') { res.writeHead(204, logoHead(req)); return res.end(); }
  if (req.method === 'GET' || req.method === 'HEAD') {
    fs.readFile(logoFile, (err, data) => {
      if (err || !data.length) { res.writeHead(404, logoHead(req, { 'content-type': 'text/plain' })); return res.end(req.method === 'HEAD' ? undefined : 'none'); }
      res.writeHead(200, logoHead(req, { 'content-type': 'image/png', 'content-length': data.length }));
      res.end(req.method === 'HEAD' ? undefined : data);
    });
    return;
  }
  if (req.method !== 'POST') { res.writeHead(405, logoHead(req)); return res.end(); }
  const json = (code, o) => { res.writeHead(code, logoHead(req, { 'content-type': 'application/json' })); res.end(JSON.stringify(o)); };
  const key = process.env.LOGO_KEY;
  const allowed = isSelf(req) || (key && req.headers['x-logo-key'] === key);
  if (!originOk(req)) return json(403, { error: 'origin' });
  if (!allowed) return json(403, key ? { error: 'key', needKey: true } : { error: 'host-only' });
  const parts = []; let n = 0; let dead = false;
  req.on('data', (c) => { n += c.length; if (n > LOGO_MAX * 1.5 + 100) { dead = true; json(413, { error: 'too-big' }); req.destroy(); } else parts.push(c); });
  req.on('end', () => {
    if (dead) return;
    const body = Buffer.concat(parts).toString('utf8').trim();
    if (body === 'reset') { try { fs.unlinkSync(logoFile); } catch {} return json(200, { ok: true }); }
    const m = /^data:image\/png;base64,([A-Za-z0-9+/=]+)$/.exec(body);
    const buf = m ? Buffer.from(m[1], 'base64') : null;
    if (!buf || buf.length < 8 || buf.length > LOGO_MAX || buf.readUInt32BE(0) !== 0x89504e47) return json(400, { error: 'bad-image' });
    try { fs.mkdirSync(path.dirname(logoFile), { recursive: true }); fs.writeFileSync(logoFile, buf); }
    catch { return json(500, { error: 'save-failed' }); }
    json(200, { ok: true });
  });
}

// Serves the web version of Glide (the same files the apps use) from staticDir.
function staticHandler(dir) {
  const root = path.resolve(dir);
  return (req, res) => {
    let p;
    try { p = decodeURIComponent(new URL(req.url, 'http://x').pathname); } catch { res.writeHead(400); return res.end(); }
    if (p === '/logo') return logoHandler(req, res);
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
    if (p === '/healthz') { res.writeHead(200, { 'content-type': 'text/plain' }); return res.end('ok'); }
    if (p === '/lan') return sendLan(req, res);
    if (p === '/ice') { res.writeHead(200, { 'content-type': 'application/json', 'cache-control': 'no-store' }); return res.end(JSON.stringify(iceFromEnv())); }
    if (p === '/' || p === '') p = '/index.html';
    const file = path.resolve(root, '.' + p);
    const type = TYPES[path.extname(file).toLowerCase()];
    if (!type || (file !== root && !file.startsWith(root + path.sep))) { res.writeHead(404); return res.end('Not found'); }
    fs.readFile(file, (err, data) => {
      if (err) { res.writeHead(404); return res.end('Not found'); }
      res.writeHead(200, { 'content-type': type, 'cache-control': 'no-cache' });
      res.end(req.method === 'HEAD' ? undefined : data);
    });
  };
}

// start(port, { staticDir }) resolves to { port, close() } once listening, rejects if the port can't be used.
function start(port, opts) {
  const staticDir = opts && opts.staticDir;
  logoFile = path.join((opts && opts.dataDir) || process.env.DATA_DIR || path.join(__dirname, 'data'), 'logo.png');
  return new Promise((resolve, reject) => {
    const rooms = new Map(); // code -> { sockets: [], timer }
    const httpServer = http.createServer(staticDir ? staticHandler(staticDir) : (req, res) => {
      if (req.url === '/healthz') { res.writeHead(200); return res.end('ok'); }
      if (String(req.url).split('?')[0] === '/lan') return sendLan(req, res);
      res.writeHead(426); res.end('Glide signaling server');
    });
    const wss = new WebSocketServer({ server: httpServer, maxPayload: 1024 * 1024 });

    const dropRoom = (code) => {
      const r = rooms.get(code);
      if (!r) return;
      clearTimeout(r.timer);
      rooms.delete(code);
    };

    const MAX_PEERS = Number(process.env.MAX_PEERS) || 20;
    const enter = (ws, type, rawCode) => {
      if (ws.code) return reply(ws, { type: 'error', message: 'Already in a session.' });
      const code = norm(rawCode);
      if (code.length < 1 || code.length > 12) return reply(ws, { type: 'error', message: 'Enter a code of 1 to 12 letters or numbers.' });
      let r = rooms.get(code);
      if (type === 'create' && r) return reply(ws, { type: 'error', message: 'That code is taken. Try again.' });
      if (type === 'join' && !r) return reply(ws, { type: 'error', message: 'Code not found. Check it and try again.' });
      if (!r) { // 'create' and 'enter' open a new room; only one-time codes expire while waiting
        r = { sockets: [], timer: null };
        if (type !== 'enter') r.timer = setTimeout(() => dropRoom(code), ROOM_TTL);
        rooms.set(code, r);
      }
      if (r.sockets.length >= MAX_PEERS) return reply(ws, { type: 'error', message: 'This code is full.' });
      let pid = 1;
      while (r.sockets.some((s) => s.pid === pid)) pid++;
      const others = r.sockets.slice();
      ws.pid = pid; ws.code = code;
      r.sockets.push(ws);
      if (r.sockets.length >= 2) { clearTimeout(r.timer); r.timer = null; }
      reply(ws, { type: 'joined', id: pid, peers: others.map((s) => s.pid) });
      others.forEach((s) => reply(s, { type: 'peer-joined', id: pid }));
    };

    wss.on('connection', (ws) => {
      ws.alive = true;
      ws.on('pong', () => (ws.alive = true));
      ws.on('error', () => {});

      ws.on('message', (raw, isBinary) => {
        // Relay mode: when a direct (WebRTC) link is impossible (e.g. the phone is the hotspot),
        // file data is passed on through this same connection. First byte = target id, replaced by the sender id.
        if (isBinary) {
          const buf = Array.isArray(raw) ? Buffer.concat(raw) : Buffer.from(raw);
          const rr = rooms.get(ws.code);
          if (!rr || buf.length < 1) return;
          const peer = rr.sockets.find((s) => s.pid === buf[0]);
          if (peer && peer.readyState === 1) { buf[0] = ws.pid; peer.send(buf, { binary: true }); }
          return;
        }
        let m;
        try { m = JSON.parse(raw.toString()); } catch { return; }

        if (m.type === 'create' || m.type === 'join' || m.type === 'enter') {
          enter(ws, m.type, m.code);
        } else if (m.type === 'announce') {
          ws.home = norm(m.code); // the device that runs this server says which code it waits in
          ws.hname = String(m.name || '').slice(0, 40);
        } else if (m.type === 'whois') {
          let home = '', name = '';
          wss.clients.forEach((c) => { if (c.home && c.readyState === 1) { home = c.home; name = c.hname || ''; } });
          reply(ws, { type: 'whois', home, name });
        } else if (m.type === 'signal') {
          const r = rooms.get(ws.code);
          const other = r && r.sockets.find((s) => s.pid === m.to && s !== ws);
          if (other) reply(other, { type: 'signal', from: ws.pid, data: m.data });
        }
      });

      ws.on('close', () => {
        const r = rooms.get(ws.code);
        if (!r) return;
        r.sockets = r.sockets.filter((s) => s !== ws);
        r.sockets.forEach((s) => reply(s, { type: 'peer-left', id: ws.pid }));
        if (!r.sockets.length) dropRoom(ws.code);
      });
    });

    const beat = setInterval(() => {
      wss.clients.forEach((ws) => {
        if (!ws.alive) return ws.terminate();
        ws.alive = false;
        ws.ping();
      });
    }, 30000);

    wss.on('error', () => {});
    httpServer.once('error', (err) => { clearInterval(beat); reject(err); });
    httpServer.listen(port, '0.0.0.0', () => {
      httpServer.on('error', () => {});
      resolve({
        port: httpServer.address().port,
        close() {
          clearInterval(beat);
          for (const r of rooms.values()) clearTimeout(r.timer);
          rooms.clear();
          wss.clients.forEach((c) => c.terminate());
          wss.close();
          httpServer.close();
        },
      });
    });
  });
}

module.exports = { start };
