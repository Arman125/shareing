// Dev check (not shipped). Run: node tools/check-compat.js
// Scans renderer/*.js for APIs that do not exist in old Android browsers (about Chrome 70). Exit 1 if any found.
const fs = require('fs'), path = require('path');
const dir = path.join(__dirname, '..', 'renderer');
const bad = [
  [/\?\.(?![0-9])/, 'optional chaining ?. (Chrome 80)'], [/\?\?/, 'nullish ?? (Chrome 80)'],
  [/\.arrayBuffer\(\)/, 'Blob.arrayBuffer() (Chrome 76): use blobToBuffer() in platform.js'],
  [/\.text\(\)\s*[;)\]]/, 'Blob/Response.text() on a Blob (Chrome 76) - ok only for fetch Response'],
  [/\.stream\(\)/, 'Blob.stream() (Chrome 76)'], [/\.at\(/, 'Array.at (Chrome 92)'],
  [/replaceAll\(/, 'replaceAll (Chrome 85)'], [/matchAll\(/, 'matchAll (Chrome 73)'],
  [/structuredClone/, 'structuredClone (Chrome 98)'], [/\.flat(Map)?\(/, 'flat/flatMap (Chrome 69-)'],
  [/replaceChildren/, 'replaceChildren (Chrome 86)'], [/randomUUID\(\)/, 'crypto.randomUUID (Chrome 92): must be guarded'],
  [/Object\.fromEntries/, 'Object.fromEntries (Chrome 73)'], [/AbortSignal\.timeout/, 'AbortSignal.timeout (Chrome 103)'],
];
let n = 0;
for (const f of fs.readdirSync(dir).filter((x) => x.endsWith('.js') && x !== 'qr.js')) {
  fs.readFileSync(path.join(dir, f), 'utf8').split('\n').forEach((line, i) => {
    if (/^\s*\/\//.test(line) || line.includes('compat-ok')) return; // 'compat-ok' marks a guarded use
    for (const [re, why] of bad) if (re.test(line)) { console.log(`${f}:${i + 1}  ${why}\n    ${line.trim().slice(0, 120)}`); n++; }
  });
}
console.log(n ? `\n${n} problem(s)` : 'compat OK');
process.exit(n ? 1 : 0);
