// Prints a function/handler index of the renderer files (name + line). Usage: node tools/make-index.js > /tmp/index.txt
// Paste the output into AI-GUIDE.md section 14 after you change code, so the next AI does not have to re-read the files.
const fs = require('fs'), path = require('path');
const dir = path.join(__dirname, '..', 'renderer');
['app.js', 'platform.js', 'linkfx.js', 'logo.js'].forEach((f) => {
  const lines = fs.readFileSync(path.join(dir, f), 'utf8').split('\n');
  console.log(`### renderer/${f} (${lines.length} lines)`);
  lines.forEach((l, i) => {
    let m = l.match(/^(?:async\s+)?function\s+([A-Za-z0-9_$]+)\s*\(/) || l.match(/^const\s+([A-Za-z0-9_$]+)\s*=\s*(?:async\s*)?(?:\([^)]*\)|[A-Za-z0-9_$]+)\s*=>/) || l.match(/^\$\('(#[A-Za-z0-9_-]+)'\)\.on[a-z]+\s*=/);
    if (m) console.log(`${i + 1}: ${m[1]}`);
  });
});
