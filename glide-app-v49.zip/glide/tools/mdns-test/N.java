package com.glide.share;
import java.net.*; import java.util.*;
public class N {
  public static void main(String[] a) throws Exception {
    System.out.println("ifaces: " + Collections.list(NetworkInterface.getNetworkInterfaces()).stream().map(n->n.getName()).toList());
    GlideMdns m = new GlideMdns(new android.content.Context()); m.start(); Thread.sleep(800);
    System.out.println("active=" + m.isActive());
    MulticastSocket c = new MulticastSocket(null); c.setReuseAddress(true); c.bind(new InetSocketAddress(5353)); c.setSoTimeout(2500);
    InetAddress g = InetAddress.getByName("224.0.0.251");
    for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) { try { if (ni.isUp() && ni.supportsMulticast() && !ni.isLoopback()) c.joinGroup(new InetSocketAddress(g,5353), ni); } catch (Exception e) {} }
    byte[] q = T.q("glide.local",1,1,false);
    c.send(new DatagramPacket(q,q.length,g,5353));
    try { for (int i=0;i<4;i++){ DatagramPacket p = new DatagramPacket(new byte[1500],1500); c.receive(p); byte[] d=p.getData(); if ((d[2]&0x80)!=0) { System.out.println("GOT ANSWER ip="+(d[p.getLength()-4]&255)+"."+(d[p.getLength()-3]&255)+"."+(d[p.getLength()-2]&255)+"."+(d[p.getLength()-1]&255)); break; } } } catch (SocketTimeoutException e) { System.out.println("no answer (inconclusive in this sandbox)"); }
    m.stop(); System.exit(0);
  }
}
