package com.glide.share;
import java.io.ByteArrayOutputStream;
public class T {
  static byte[] q(String name, int type, int cls, boolean pointer) throws Exception {
    ByteArrayOutputStream o = new ByteArrayOutputStream();
    o.write(0);o.write(0);o.write(0);o.write(0);o.write(0);o.write(1);o.write(0);o.write(0);o.write(0);o.write(0);o.write(0);o.write(0);
    for (String l : name.split("\\.")) { o.write(l.length()); o.write(l.getBytes()); }
    o.write(0); o.write(type>>8);o.write(type&255);o.write(cls>>8);o.write(cls&255);
    return o.toByteArray();
  }
  static int fails=0;
  static void check(String n, boolean ok){ System.out.println((ok?"PASS ":"FAIL ")+n); if(!ok)fails++; }
  public static void main(String[] a) throws Exception {
    byte[] ip = {(byte)192,(byte)168,43,1};
    byte[] r = GlideMdns.answer(q("glide.local",1,1,false), q("glide.local",1,1,false).length, ip, new boolean[1]);
    check("A query answered", r!=null && r.length==12+13+10+4 && r[r.length-4]==(byte)192 && r[r.length-1]==1);
    check("answer flags 0x8400 and 1 answer", r!=null && (r[2]&255)==0x84 && r[3]==0 && r[7]==1);
    byte[] qq=q("GLIDE.Local",255,0x8001,false); boolean[] u=new boolean[1];
    r = GlideMdns.answer(qq, qq.length, ip, u);
    check("case-insensitive, ANY, QU bit -> unicast flag", r!=null && u[0]);
    qq=q("other.local",1,1,false);
    check("other name ignored", GlideMdns.answer(qq, qq.length, ip, new boolean[1])==null);
    qq=q("glide.local",28,1,false);
    check("AAAA ignored", GlideMdns.answer(qq, qq.length, ip, new boolean[1])==null);
    byte[] resp = GlideMdns.answer(q("glide.local",1,1,false), 29, ip, null);
    check("a response packet is not answered", GlideMdns.answer(resp, resp.length, ip, null)==null);
    check("truncated packet ignored", GlideMdns.answer(new byte[5],5,ip,null)==null);
    byte[] bad = q("glide.local",1,1,false); 
    check("cut question ignored", GlideMdns.answer(bad, bad.length-3, ip, null)==null);
    System.exit(fails);
  }
}
