#!/bin/sh
# Compiles mobile/native/GlideMdns.java against tiny Android stubs and runs (1) logic tests (T) and (2) a real multicast round trip on this machine (N).
# Needs a JDK or a JRE with the jdk.compiler module (java -m jdk.compiler/com.sun.tools.javac.Main). Usage: sh tools/mdns-test/run.sh
set -e
D=$(cd "$(dirname "$0")" && pwd); R="$D/../.."; O=$(mktemp -d)
mkdir -p "$O/src/com/glide/share" && cp "$R/mobile/native/GlideMdns.java" "$D/T.java" "$D/N.java" "$O/src/com/glide/share/"
java -m jdk.compiler/com.sun.tools.javac.Main -d "$O/out" $(find "$D/stubs" -name '*.java') "$O"/src/com/glide/share/*.java
java -cp "$O/out" com.glide.share.T
timeout 20 java -cp "$O/out" com.glide.share.N
