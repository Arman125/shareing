// Dev test (not shipped in the app / APK / Docker image). See AI-GUIDE.md section 11.
// Run:  (cd renderer && python3 -m http.server 8123 &)  then  NODE_PATH=<dir containing playwright> node tools/test-fx-8-devices.js
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport: { width: 320, height: 700 }, deviceScaleFactor: 1.5, isMobile: true, hasTouch: true, reducedMotion: 'reduce' });
  const p = await ctx.newPage();
  const errs = []; p.on('pageerror', e => errs.push(String(e)));
  await p.goto('http://127.0.0.1:8123/index.html'); await p.waitForTimeout(500);
  await p.evaluate(() => {
    document.getElementById('on-live').hidden = false; document.getElementById('on-wait').hidden = true;
    room.code = 'HOME42'; room.standby = false;
    const names = ['<img src=x onerror=alert(1)>', 'Pixel', 'iPad', 'Mac', 'Linux PC', 'Tab S9', 'Laptop 2', 'Phone 8'];
    names.forEach((n, i) => room.peers.set(i + 1, { id: i + 1, name: n, home: i === 0 ? 'HOME42' : '', live: true, sel: true }));
    setTransfer({ id: 'x', name: 'a', size: 100, dir: 'out', peer: 'Pixel', pid: 2, status: 'sending', done: 50 });
  });
  await p.waitForTimeout(800);
  const r = await p.evaluate(() => ({
    sw: document.documentElement.scrollWidth, iw: innerWidth,
    imgTagsInSvg: document.querySelectorAll('#fx-live svg img').length,
    nameText: document.querySelector('#fx-live .fx-node.host .fx-label').textContent,
    anim: getComputedStyle(document.querySelector('#fx-live .fx-node.act .fx-core')).animationName,
    svgH: Math.round(document.querySelector('#fx-live svg').getBoundingClientRect().height),
  }));
  console.log(JSON.stringify(r), errs);
  await b.close();
})();
