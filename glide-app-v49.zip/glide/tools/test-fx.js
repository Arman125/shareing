// Dev test (not shipped in the app / APK / Docker image). See AI-GUIDE.md section 11.
// Run:  (cd renderer && python3 -m http.server 8123 &)  then  NODE_PATH=<dir containing playwright> node tools/test-fx.js
const { chromium } = require('playwright');
const scen = process.argv[2] || 'idle';
(async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport: { width: 360, height: 900 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  const p = await ctx.newPage();
  const errs = []; p.on('pageerror', e => errs.push(String(e))); p.on('console', m => { if (m.type()==='error' && !/404/.test(m.text())) errs.push(m.text()); });
  await p.goto('http://127.0.0.1:8123/index.html'); await p.waitForTimeout(500);
  await p.evaluate((scen) => {
    // a fake profile picture for the host
    const c = document.createElement('canvas'); c.width = c.height = 256; const x = c.getContext('2d');
    const g = x.createLinearGradient(0,0,256,256); g.addColorStop(0,'#ff8a5c'); g.addColorStop(1,'#7b6cf0'); x.fillStyle = g; x.fillRect(0,0,256,256);
    x.fillStyle = '#fff'; x.beginPath(); x.arc(128,100,46,0,7); x.fill(); x.fillRect(60,160,136,96);
    window.GlideLogoData = c.toDataURL('image/png');
    document.getElementById('on-live').hidden = false;
    document.getElementById('on-wait').hidden = true;
    const mk = (id, name, home, live) => ({ id, name, home, live, sel: true });
    if (scen === 'host') { hostRunning = true; room.url = 'ws://127.0.0.1:8080'; room.standby = true; room.code = 'HOME42'; room.peers.set(2, mk(2, 'Windows PC', '', true)); room.peers.set(3, mk(3, 'Android phone', '', true)); }
    else {
      room.standby = false; room.code = 'HOME42';
      room.peers.set(1, mk(1, 'Redmi Note 12', 'HOME-42', true));
      room.peers.set(2, mk(2, 'Windows PC', '', true));
      room.peers.set(3, mk(3, 'iPhone', '', false));
    }
    if (scen === 'xfer') {
      setTransfer({ id: 't1', name: 'a.mp4', size: 1000, dir: 'out', peer: 'Windows PC', pid: 2, status: 'sending', done: 420 });
      setTransfer({ id: 't2', name: 'b.mp4', size: 1000, dir: 'in', peer: 'Redmi Note 12', pid: 1, status: 'receiving', done: 700 });
    }
    if (scen === 'host') setTransfer({ id: 't3', name: 'c.mp4', size: 1000, dir: 'out', peer: 'Windows PC', pid: 2, status: 'sending', done: 300 });
  }, scen);
  await p.waitForTimeout(900);
  const info = await p.evaluate(() => ({ w: innerWidth, sw: document.documentElement.scrollWidth, nodes: [...document.querySelectorAll('#fx-live .fx-node')].map(n => n.getAttribute('class') + ' | ' + n.st.textContent), imgs: document.querySelectorAll('#fx-live image').length }));
  console.log(scen, JSON.stringify(info, null, 1)); console.log('errors', errs);
  const el = await p.$('#fx-live'); await el.screenshot({ path: `/tmp/fx-${scen}.png` });
  await b.close();
})();
