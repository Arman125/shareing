// Dev test (not shipped). See AI-GUIDE.md section 11.
// Run: (cd renderer && python3 -m http.server 8123 &)  then  NODE_PATH=<dir containing playwright> node tools/test-host-detect.js
// (the page is opened as glide.test, not localhost, because a page opened on localhost counts as "on the host itself")
// Checks that the HOST is recognised in a one-time-code room (no home-code match) via hello.host, and that the host device marks itself.
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--host-resolver-rules=MAP glide.test 127.0.0.1'] });
  const p = await (await b.newContext({ viewport: { width: 360, height: 900 }, isMobile: true })).newPage();
  const errs = []; p.on('pageerror', (e) => errs.push(String(e)));
  await p.goto('http://' + 'glide.test' + ':8123/index.html'); await p.waitForTimeout(500);
  const run = (scen) => p.evaluate((scen) => {
    document.getElementById('on-live').hidden = false; document.getElementById('on-wait').hidden = true;
    const mk = (id, name, home, live, isHost) => ({ id, name, home, live, sel: true, isHost });
    room.peers = new Map(); room.hostHome = ''; localStorage.removeItem('glide.hostid'); hostRunning = false; room.standby = false; room.url = 'ws://192.168.0.196:8080'; room.code = 'AB12CD';
    if (scen === 'visitor-code-room') { room.peers.set(1, mk(1, 'GOGO', 'HOMEX9', true, true)); room.peers.set(2, mk(2, 'Windows PC', 'HOMEY1', true, false)); }
    if (scen === 'old-host-home-room') { room.code = 'HOMEX9'; room.peers.set(1, mk(1, 'GOGO', 'HOMEX9', true, undefined)); room.peers.set(2, mk(2, 'PC', 'HOMEY1', true, false)); }
    if (scen === 'two-claim-whois') { room.hostHome = 'HOMEX9'; room.peers.set(1, mk(1, 'Android phone', 'HOMEZ7', true, true)); room.peers.set(2, mk(2, 'GOGO', 'HOMEX9', true, true)); }
    if (scen === 'two-claim-nowhois') { room.peers.set(1, mk(1, 'Android phone', 'HOMEZ7', true, true)); room.peers.set(2, mk(2, 'GOGO', 'HOMEX9', true, true)); }
    if (scen === 'screenshot-case') { room.code = 'HOMEZ7'; room.peers.set(1, mk(1, 'My phone', 'HOMEA1', true, true)); room.peers.set(2, mk(2, 'Android phone', 'HOMEZ7', true, false)); }
    if (scen === 'option-off') { localStorage.setItem('glide.hostid', '0'); room.peers.set(1, mk(1, 'GOGO', 'HOMEX9', true, true)); }
    if (scen === 'i-am-host') { hostRunning = true; room.url = 'ws://127.0.0.1:8080'; room.peers.set(1, mk(1, 'Windows PC', '', true, false)); }
    renderLivePeers();
    return new Promise((r) => setTimeout(() => r({
      amHost: amHost(),
      nodes: [...document.querySelectorAll('#fx-live .fx-node')].map((n) => n.getAttribute('class')),
      list: document.getElementById('live-peers').textContent.replace(/\s+/g, ' ').trim(),
    }), 800));
  }, scen);
  let bad = 0;
  const expect = (name, ok, info) => { console.log(ok ? 'PASS' : 'FAIL', name, ok ? '' : JSON.stringify(info)); if (!ok) bad++; };
  let r = await run('visitor-code-room');
  expect('one-time-code room: host node marked', r.nodes.some((c) => / host/.test(c) && !/ me/.test(c)) && /GOGO \(host\)/.test(r.list) && !/Windows PC \(host\)/.test(r.list), r);
  r = await run('old-host-home-room');
  expect('home room (older peers without flag): host found by home code', /GOGO \(host\)/.test(r.list), r);
  r = await run('i-am-host');
  expect('this device is host: amHost() true, "me" node has host tag', r.amHost === true && r.nodes.some((c) => / me/.test(c) && / host/.test(c)), r);
  r = await run('visitor-code-room');
  expect('plain visitor: amHost() false', r.amHost === false, r);
  await p.goto('http://127.0.0.1:8123/index.html'); await p.waitForTimeout(500); // a browser tab on localhost must NOT be the host
  r = await run('visitor-code-room');
  expect('browser tab on localhost: amHost() false (v34 bug: both devices showed HOST)', r.amHost === false && !r.nodes.some((c) => / me/.test(c) && / host/.test(c)), r);
  r = await run('two-claim-whois');
  expect('two devices claim host: the one the server announced wins (GOGO only)', /GOGO \(host\)/.test(r.list) && !/Android phone \(host\)/.test(r.list) && r.nodes.filter((c) => / host/.test(c) && !/ me/.test(c)).length === 1, r);
  r = await run('two-claim-nowhois');
  expect('two claim, no whois: only ONE host shown (lowest id)', (r.list.match(/\(host\)/g) || []).length === 1, r);
  r = await run('screenshot-case');
  expect('one device has the flag, another matches the room code: only ONE host (v37 showed two)', (r.list.match(/\(host\)/g) || []).length === 1 && /My phone \(host\)/.test(r.list) && r.nodes.filter((c) => / host/.test(c) && !/ me/.test(c)).length === 1, r);
  const vis = await p.evaluate(() => {
    showView('online');
    const seen = {};
    ['idle', 'waiting', 'live'].forEach((s) => { setRoomStatus(s); const el = document.getElementById('opt-card'); seen[s] = !!el.offsetParent && el.getBoundingClientRect().height > 20; });
    return seen;
  });
  expect('options card visible in every Online state (idle, waiting, connected)', vis.idle && vis.waiting && vis.live, vis);
  r = await run('option-off');
  expect('option "Recognise the host" off: nobody labelled host', !/\(host\)/.test(r.list) && !r.nodes.some((c) => / host/.test(c)), r);
  const auto = await p.evaluate(() => {
    localStorage.removeItem('glide.autoaccept'); state.incoming = [];
    let a = 0; askIncoming({ id: 'x', name: 'f.jpg', size: 1, from: 'GOGO', cb: () => { a = 1; } });
    const asked = state.incoming.length; state.incoming = []; document.getElementById('scrim').hidden = true;
    localStorage.setItem('glide.autoaccept', '1');
    let b = 0; askIncoming({ id: 'y', name: 'g.jpg', size: 1, from: 'GOGO', cb: (ok) => { b = ok ? 1 : 2; } });
    const queued = state.incoming.length; localStorage.removeItem('glide.autoaccept');
    return new Promise((res) => setTimeout(() => res({ asked, a, queued, b, modalHidden: document.getElementById('scrim').hidden }), 50));
  });
  expect('auto-accept OFF: question is asked, nothing accepted', auto.asked === 1 && auto.a === 0, auto);
  expect('auto-accept ON: accepted at once, no question, no modal', auto.queued === 0 && auto.b === 1 && auto.modalHidden === true, auto);
  console.log('page errors', errs); await b.close(); process.exit(bad || errs.length ? 1 : 0);
})();
