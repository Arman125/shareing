// Dev test (not shipped in the app / APK / Docker image). See AI-GUIDE.md section 11.
// Run:  (cd renderer && python3 -m http.server 8123 &)  then  NODE_PATH=<dir containing playwright> node tools/test-transfer-overflow.js
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport: { width: 360, height: 740 }, deviceScaleFactor: 1.75, isMobile: true, hasTouch: true,
    userAgent: 'Mozilla/5.0 (Linux; Android 9; Redmi) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.80 Mobile Safari/537.36' });
  const p = await ctx.newPage();
  await p.goto('http://127.0.0.1:8123/index.html'); await p.waitForTimeout(600);
  await p.evaluate(() => {
    const long = '03680af4707e_1_1774712282_392' + 'x'.repeat(40) + '.mp4';
    setTransfer({ id: 'a', name: long, size: 2097152, dir: 'in', peer: 'Android phone', pid: 2, status: 'done', done: 2097152, path: '/x/y', avg: 887000 });
    setTransfer({ id: 'b', name: long, size: 2097152, dir: 'in', peer: 'Android phone', pid: 2, status: 'receiving', done: 900000 });
    showView('transfers');
  });
  await p.waitForTimeout(400);
  const r = await p.evaluate(() => {
    const w = (s) => { const e = document.querySelector(s); return e ? Math.round(e.getBoundingClientRect().width) : null; };
    return { inner: innerWidth, card: w('#view-transfers .card') || w('.card'), tlist: w('#tlist'), t: w('.t'), tTop: w('.t-top'), meta: w('.t-meta'), app: w('.app'), body: w('body') };
  });
  console.log(JSON.stringify(r));
  await p.screenshot({ path: process.argv[2] || '/tmp/transfers.png' });
  await b.close();
})();
